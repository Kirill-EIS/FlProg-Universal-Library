#include "RT_HW_HD44780.h"
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//									Конструктор
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
RT_HW_HD44780:: RT_HW_HD44780(){
hive.set=0;
};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							Инициализация устройства
//-----------------Параметры корректируемые до вызова функции setID()------------------------------
// mode='N':	 Интерфейс (I,S,s,4,8);
// cols,rows :	 Кол-во колонок дисплея;
// periodReboot: Период внутреннего перезапуска в мин. Если =0, перезапуск не выполняется;
// pin[10]:		 i2c->adr,bus; SPI->cs,bus; SSPI->clk,miso,mosi,cs; bus4->RS,E,DB4-DB7; bus8->RS,E,DB0-DB7;
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void    RT_HW_HD44780:: setID(RT_HW_HD44780_DEVICE_ID *z){		//==Установка параметров ID устройства;	
if(z->custom!=0) {return;}												//--Выход, если устройство уже инициализировано;
z->debug=0;																//--Код состояния отладки. Используется внешними функциями;
z->dir=0;																//--Очистка номеров этапов управления устройством; 	
z->custom=1;															//--Предварительная установка флага успешной настройки:
z->num=RT_HW_Base.setFistFreeDevice(hive.set,RT_HW_HD44780_MAX_DEVICE);	//--Получение номера устройства
if(z->num==0) 		{z->custom=40; return;}								//--Выход, если все номера оказались заняты;
if(z->mode=='N')	{z->custom=41; return;}								//--Выход, если тип интерфейс не опеделен;			
ptr[z->num]=z;															//--Установка адреса указателя;
if(z->cols>RT_HW_HD44780_MAX_COLS){z->cols=RT_HW_HD44780_MAX_COLS;}		//--Нормализация кол-ва колонок;
if(z->rows>RT_HW_HD44780_MAX_ROWS){z->rows=RT_HW_HD44780_MAX_ROWS;} 	//--Нормализация кол-ва строк;
if((z->cols==40) && (z->rows==4)) {z->chip=2;} else {z->chip=1;}		//--Установка кол-ва чипов в дисплее (для дисплеев 40x4 два чипа);
z->extEN=1;																//--Внешний флаг разрешения работы устройства:
z->genState=2;															//--Генератор выключен; 
z->ledON=1;																//--Включение подсветки;			
//-------------------------------------------------------------------------------------------------
if(z->mode=='I') {		//==Инциализация для шины i2c;	
if(z->pin[0]==255) {z->custom=50; return;}													//--Выход, если не допустимый адрес устройства i2c;
RT_HW_Base.i2cBegin(255,255,0, z->pin[1]); 													//--Настройка   шины i2cX как Master (если уже настроена, действия не выполняются;
if(!RT_HW_Base.i2cCheckBusState(RT_HW_I2C_STATE_MASTER,z->pin[1]))	{z->custom=51; return;}}//--Выход, если шина i2cX не настроена; 	
//-------------------------------------------------------------------------------------------------
if(z->mode=='S') {		//==Инициализация для шины аппаратный SPI;
if(!RT_HW_Base.checkPinPGM(RT_HW_PGM_PIN_DOT_ID,z->pin[0])) 	   	{z->custom=55; return;}	//--Выход, если не допустимый номер пина cs устройства SPI;																
digitalWrite(z->pin[0],1); pinMode(z->pin[0],OUTPUT);										//--Настройка пина на выход с установкой в HIGH;
RT_HW_Base.spiBegin(255,255,255,0,z->pin[1]);												//--Настройка SPIX
if(!RT_HW_Base.spiCheckBusState(RT_HW_SPI_STATE_MASTER,z->pin[1]))	{z->custom=56; return;}	//--Выход, если шина SPIX не настроена;	
RT_HW_Base.spiSendByte(z->pin[0],z->pin[1],0);}												//--Очистка буфера;
//-------------------------------------------------------------------------------------------------
if(z->mode=='s') {		//==Инциализация для шины программный SPI (SSPI);
uint8_t buff=60;
for(uint8_t i=0;i<3;i++){if(!RT_HW_Base.checkPinPGM(RT_HW_PGM_PIN_DOT_ID,z->pin[i])){z->custom=buff+i; return;}	//--Выход, если не допустимый номер пина SSPI;																
                         else {digitalWrite(z->pin[i],LOW); pinMode(z->pin[i],OUTPUT);}}//--Настройка пинов;
digitalWrite(z->pin[2],HIGH); 															//--Установка пина cs;
RT_HW_Base.sspiSendByte(z->pin[0],z->pin[1],z->pin[2],0);
RT_HW_Base.consoleText("INIT SPI->"); RT_HW_Base.ConsoleArrV8('U',2,';',3,z->pin);

}								//--Очистка буфера SSPI;
//-------------------------------------------------------------------------------------------------
if(z->mode=='4') {		//==Инициализация для шины bus4;
uint8_t buff=70;
for(uint8_t i=0;i<6;i++){if(!RT_HW_Base.checkPinPGM(RT_HW_PGM_PIN_DOT_ID,z->pin[i])){z->custom=buff+i; return;}	//--Выход, если не допустимый номер пина SSPI;																
                         else {digitalWrite(z->pin[i],LOW); pinMode(z->pin[i],OUTPUT);}}//--Настройка пинов;
digitalWrite(z->pin[1],HIGH);} 															//--Установка пина E;
//-------------------------------------------------------------------------------------------------
if(z->mode=='8') {		//==Инциализация для шины bus8;
uint8_t buff=80;
for(uint8_t i=0;i<10;i++){if(!RT_HW_Base.checkPinPGM(RT_HW_PGM_PIN_DOT_ID,z->pin[i])){z->custom=buff+i; return;}	//--Выход, если не допустимый номер пина SSPI;																
                         else {digitalWrite(z->pin[i],LOW); pinMode(z->pin[i],OUTPUT);}}//--Настройка пинов;
digitalWrite(z->pin[1],HIGH);} 															//--Установка пина E;
//-------------------------------------------------------------------------------------------------
}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// 			Основной тактирующий генератор устройства [события(event) и меандр(tick)]
// Вход:  genState: отключение генератора 2->genState;
// Выход: genState: =0 тик=LOW; =1 тик=HIGH; =2 тик=LOW, флаг перезапуска для синхронизируемых устройств; 
//        event: событие 50мс; tick: меандр 50мс; mnt мендр 1мин; 
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void 	RT_HW_HD44780:: generator(RT_HW_HD44780_DEVICE_ID &z){z.event=0; //==Генератор устройства (меандры 50мс,1 сек);
if(RT_HW_Base.periodMs(z.genTime, RT_HW_HD44780_PERIOD_TICK)){z.event=1;			//--Проверка события =50мс и установка event;
	if(z.genState==2) {z.tick=z.mnt=0; z.runReboot=z.genCalcMin=z.genCntReboot=0; return;}		//--Если генератор выключен, сброс переменных и выход;
	z.tick=!z.tick; z.genState=(uint8_t)z.tick;										//--Генерация тика и изменения выхода генератора;	
	if(++z.genCalcMin>=1200) {z.genCalcMin=0; z.mnt=!z.mnt; 						//--Генерация mnt(минуты);
	  if(z.genPeriodReboot>0) {z.genCntReboot++;}  									//--Cчетчик перезагрузки;
	  if(z.genCntReboot>=z.genPeriodReboot){z.runReboot=1;
	  //RT_HW_Base.consoleText(F("Start reboot cnt=")); RT_HW_Base.ConsoleV32('U',0,'E',z.genCntReboot);	  
	  }}}}; 					//--Флаг перезагрузки;
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							Управление устройством extEN:1, agoEN:1, eN:1, extReset:1, agoReset:1, reset:1, busy:1;
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void 	RT_HW_HD44780:: direct(RT_HW_HD44780_DEVICE_ID &z){
generator(z);							//==Вызов тактирующего генератора (в каждом цикле) внешних устройств (блоков FLProg);
if(z.dir==0) {							//==Начало работы;	
	z.genState=2;							//--Остановка тактирующего генератора, блоки вывода переходят в режим сброс;
	if(z.custom!=1) {return;} 				//--Ожидание настройки ID;				
    if(!z.extEN)	{return;}				//--Ожидание разрешения работы;
	z.buff16=z.step=z.index=0; 				//--Подготовка регистров;
	z.busy=z.errLink=z.link=1; 				//--Подготовка регистров;
	if(z.mode=='I') {z.dir=1;} 				//--Если шина i2c, то переход на поиск устройства по адресу;
	           else {z.dir=2;} return;}		//  иначе сразу переход на инициализацию устройств;
if(z.dir==1) {if(RT_HW_Base.i2cFindAdr(z.timeDelay, z.buff16, z.pin[0], z.pin[1])){z.dir++;} return;}	//--Поиск устройства на шине i2c;
if(z.dir==2) {z.busy=0; z.step=z.index==0;	//--Подготовка регистров;
	   if(z.mode=='I') {if((z.rows==40) && (z.cols==4)){z.dir=3;} //--Переход на настройку для дисплеев 40x4;
	                   else                            {z.dir=4;}} //--Переход на настройку других дисплеев; 
  else if(z.mode=='S')  {z.dir=4;}	//--Для шины SPI;
  else if(z.mode=='s')  {z.dir=4;} 	//--Для шины SSPI;
  else if(z.mode=='4')  {z.dir=4;}  //--Для шины bus4;
  else if(z.mode=='8') 	{z.dir=5;}  //--Для шины bus8;
  else   				{z.dir=0;}} //--Не опознанный интерфейс; 
if(z.dir==3){if(init4004(z))    {z.dir=9;} return;}		//--Настройка Lcd c 4-x битовой шиной данных: размер дисплеев 40x4;
if(z.dir==4){if(initBUS4(z))    {z.dir=9;} return;}		//--Настройка Lcd c 4-x битовой шиной данных: кроме  дисплеев 40x4;
if(z.dir==5){if(initBUS8(z))    {z.dir=9;} return;}		//--Настройка Lcd c 8-ми битовой шиной данных;
if(z.dir==9){if(z.link){z.genState=4; z.busy=0; z.dir=10;} 	//--Если связи
	         else      {z.genState=2;           z.dir=0;}  return;}
if(z.dir==10){											//==Основной вывод;	
	if(!z.extEN){z.dir=0;     return;} 						//--Ожидание разрешения работы по событию;	
    if(!z.link) {z.dir=0; 	  return;}
	if(z.runReboot) {z.dir=0; return;}
    return;}
if(z.dir==11){											//==Ожидание завершения периода;
	z.dir=10; 
	return;}
}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//			Инициализация дисплев через 4-х битную шину данных (кроме дисплеев 40x4)
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
bool 	RT_HW_HD44780:: initBUS4    (RT_HW_HD44780_DEVICE_ID &z){
if(!deviceSend(z.num, pgm_read_byte(RT_HW_HD44780_INIT_BUS4+(z.index*3)),
				(char)pgm_read_byte(RT_HW_HD44780_INIT_BUS4+(z.index*3+1)), pgm_read_byte(RT_HW_HD44780_INIT_BUS4+(z.index*3+2))*100)) {return 0;}
			   if(++z.index<13){return 0;} 
z.index=0; return 1;}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//			Инициализация дисплев через 4-х битную шину данных (кроме дисплеев 40x4)
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
bool 	RT_HW_HD44780:: initBUS8    (RT_HW_HD44780_DEVICE_ID &z){
if(!deviceSend(z.num, pgm_read_byte(RT_HW_HD44780_INIT_BUS8+(z.index*3)),
		    (char)pgm_read_byte(RT_HW_HD44780_INIT_BUS8+(z.index*3+1)),
			      pgm_read_byte(RT_HW_HD44780_INIT_BUS8+(z.index*3+2))*100)) {return 0;}
			if(++z.index<13){return 0;} 
z.index=0; return 1;}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//			Инициализация дисплев через 4-х битную шину данных для дисплеев 40x4
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
bool 	RT_HW_HD44780:: init4004    (RT_HW_HD44780_DEVICE_ID &z){
if(z.step==0) {z.chip=1; z.index=0;  z.step++;}
if(z.step==1) {if(!deviceSend(z.num, pgm_read_byte(RT_HW_HD44780_INIT_BUS4+(z.index*3)),
				(char)pgm_read_byte(RT_HW_HD44780_INIT_BUS4+(z.index*3+1)), pgm_read_byte(RT_HW_HD44780_INIT_BUS4+(z.index*3+2))*100)) {return 0;}
			   if(++z.index<13){return 0;} 
			   z.step++;}
if(z.step==2) {if((z.cols==40) && (z.rows==4)) {z.chip=2;  z.timeDelay=millis(); z.index=0; z.step++; return 0;} else {z.step=5; return 0;}}
if(z.step==3) {if(RT_HW_Base.getPastMs(z.timeDelay) >= 1100) {z.step++;} return 0;}
if(z.step==4) {if(!deviceSend(z.num, pgm_read_byte(RT_HW_HD44780_INIT_BUS4+(z.index*3)),
				(char)pgm_read_byte(RT_HW_HD44780_INIT_BUS4+(z.index*3+1)), pgm_read_byte(RT_HW_HD44780_INIT_BUS4+(z.index*3+2))*100)) {return 0;}
			   if(++z.index<13){return 0;} 
			   z.timeDelay=millis(); z.step++;}
if(z.step==5) {if(RT_HW_Base.getPastMs(z.timeDelay) >= 100) {z.step++;} return 0;}
if(z.step==6) {z.chip=1; z.step=0; return 1;}	
return 1;};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 
//		Отправка тетрады/инстркуции/данных в устройство 
// 1.Входные формат: =T отправка тетрада; =I отправка инструкция(байт); =D отправка данных (байт);
// 2.time - время задержки после отправки команды (default=0). Обычно >0 при отправки инструкций;  
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 
bool  	RT_HW_HD44780:: deviceSend     (uint8_t num, uint8_t val, char code, uint16_t time){
if(!RT_HW_Base.checkBusyNumDevice(hive.set, num)) {return 0;} 	//--Проверка на наличие инициализированного указателя ID с номером num (важно для защиты от фатальных сбоев);
uint8_t buff; uint8_t arr[4]; uint8_t vEN=0;	 					//--Создание временных переменных;
//-------------------------------------------------------------------------------------------------
if(ptr[num]->stepSend==0) {		//==Предварительная обработка и выбор следующего этапа;
      if(code=='D') {ptr[num]->cmnd=1;} else {ptr[num]->cmnd=0;}
      if(ptr[num]->chip ==2){vEN=RT_HW_HD44780_BIT_RW;}  		//--Выбор номера бита EN для всех LCD, кроме LCD40x4  
	  else                  {vEN=RT_HW_HD44780_BIT_E;}	 		//--Выбор номера бита EN для LCD 40x4
	  if((code=='I') || (code=='D')) {ptr[num]->stepSend++;}	//--Выбор следующего этапа для инструкции или данных;  
 else if( code=='T')                 {ptr[num]->stepSend=2;} 	//--Выбор следующего этапа для тетрады;
 else                                {ptr[num]->stepSend=7;}}	//--Выбор этапа при ошибочном code;
//-------------------------------------------------------------------------------------------------
if(ptr[num]->stepSend==1) {		//==Начало подготовки данных для инструкции/команды; 
	buff=(val & 0xf0); 			
	bitWrite(buff,RT_HW_HD44780_BIT_ON, ptr[num]->ledON);	
	bitWrite(buff,RT_HW_HD44780_BIT_RS, ptr[num]->cmnd);	
	bitSet(  buff,vEN); arr[0] = buff; 
	bitClear(buff,vEN); arr[1] = buff;	
	ptr[num]->stepSend++;}
//-------------------------------------------------------------------------------------------------
if(ptr[num]->stepSend==2) {		//==Продолжение подготовки данных для инструкции/команды или тетрады; 
	buff=val<<4;	
	bitWrite(buff,RT_HW_HD44780_BIT_ON, ptr[num]->ledON);	
	bitWrite(buff,RT_HW_HD44780_BIT_RS, ptr[num]->cmnd);
	bitSet(buff,vEN);   arr[2] = buff;
	bitClear(buff,vEN); arr[3] = buff;	
	ptr[num]->stepSend++;}
//-------------------------------------------------------------------------------------------------
if(ptr[num]->stepSend==3) {		//==Отправка
	if(deviceTransfer(num, arr,code)){ptr[num]->stepSend=0; ptr[num]->link=0; return 1;} 
	ptr[num]->stepSend=7;}
if(ptr[num]->stepSend==7)	{if(time==0){ptr[num]->stepSend=0; return 1;} ptr[num]->timeDelay=micros();  ptr[num]->stepSend++; return 0;}
if(ptr[num]->stepSend==8)	{if(RT_HW_Base.getPastMcs(ptr[num]->timeDelay)>=time) {ptr[num]->stepSend=0; return 1;}   return 0;}	
//-------------------------------------------------------------------------------------------------
return 0;}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							Отправка байта на физическое устройство (i2x,SPI,SSPI,bus4,bus8)
// Возвращает код ошибки обмена-> =0 не обнаружено; 
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
uint8_t	RT_HW_HD44780:: deviceTransfer (uint8_t num, const uint8_t *arr, char code){	
//-------------------------------------------------------------------------------------------------
if(ptr[num]->mode=='I') {
	if(code=='T'){return RT_HW_Base.i2cSendBytes(&arr[2],2,ptr[num]->pin[0],ptr[num]->pin[1]);}	
	else         {return RT_HW_Base.i2cSendBytes(&arr[0],4,ptr[num]->pin[0],ptr[num]->pin[1]);}}
//-------------------------------------------------------------------------------------------------
if(ptr[num]->mode=='S') {
	if(code!='T'){RT_HW_Base.spiSendByte(ptr[num]->pin[0],ptr[num]->pin[1], arr[0]);
	              RT_HW_Base.spiSendByte(ptr[num]->pin[0],ptr[num]->pin[1], arr[1]);}
	              RT_HW_Base.spiSendByte(ptr[num]->pin[0],ptr[num]->pin[1], arr[2]);
                  RT_HW_Base.spiSendByte(ptr[num]->pin[0],ptr[num]->pin[1], arr[3]);	return 0;}

//	if(code=='T'){for(uint8_t i=2; i<4; i++) {RT_HW_Base.spiSendByte(ptr[num]->pin[0],ptr[num]->pin[1], arr[i]);}}
//	else		 {for(uint8_t i=0; i<4; i++) {RT_HW_Base.spiSendByte(ptr[num]->pin[0],ptr[num]->pin[1], arr[i]);}}	return 0;}
//-------------------------------------------------------------------------------------------------
if(ptr[num]->mode=='s') { 
	if(code!='T'){RT_HW_Base.sspiSendByte(ptr[num]->pin[0],ptr[num]->pin[1],ptr[num]->pin[2], arr[0]);
	              RT_HW_Base.sspiSendByte(ptr[num]->pin[0],ptr[num]->pin[1],ptr[num]->pin[2], arr[1]);}
	              RT_HW_Base.sspiSendByte(ptr[num]->pin[0],ptr[num]->pin[1],ptr[num]->pin[2], arr[2]);
                  RT_HW_Base.sspiSendByte(ptr[num]->pin[0],ptr[num]->pin[1],ptr[num]->pin[2], arr[3]);	  return 0;}  
//-------------------------------------------------------------------------------------------------
if(ptr[num]->mode=='4') {	
uint8_t buff; 
RT_HW_PIN_DIR_ID idRS,idE,idDB4,idDB5,idDB6,idDB7; 
RT_HW_PIN_DIR_SET_ID(idRS,  ptr[num]->pin[0]);
RT_HW_PIN_DIR_SET_ID(idE,   ptr[num]->pin[1]);
RT_HW_PIN_DIR_SET_ID(idDB4, ptr[num]->pin[2]);
RT_HW_PIN_DIR_SET_ID(idDB5, ptr[num]->pin[3]);
RT_HW_PIN_DIR_SET_ID(idDB6, ptr[num]->pin[4]);
RT_HW_PIN_DIR_SET_ID(idDB7, ptr[num]->pin[5]);
	RT_HW_PIN_DIR_WRITE(idRS,ptr[num]->cmnd);
	if(code!='T'){
	buff=arr[0];
	RT_HW_PIN_DIR_WRITE(idDB4, bitRead(buff,4));
	RT_HW_PIN_DIR_WRITE(idDB5, bitRead(buff,5));
	RT_HW_PIN_DIR_WRITE(idDB6, bitRead(buff,6));	
	RT_HW_PIN_DIR_WRITE(idDB7, bitRead(buff,7));	
	RT_HW_PIN_DIR_WRITE_HIGH(idE); RT_HW_PIN_DIR_WRITE_LOW(idE); 
	}	
	buff=arr[2];
	RT_HW_PIN_DIR_WRITE(idDB4, bitRead(buff,4));
	RT_HW_PIN_DIR_WRITE(idDB5, bitRead(buff,5));
	RT_HW_PIN_DIR_WRITE(idDB6, bitRead(buff,6));	
	RT_HW_PIN_DIR_WRITE(idDB7, bitRead(buff,7));	
	RT_HW_PIN_DIR_WRITE_HIGH(idE); RT_HW_PIN_DIR_WRITE_LOW(idE); 
	return 0;}
//-------------------------------------------------------------------------------------------------
if(ptr[num]->mode=='8') {
uint8_t buff=((arr[2]&0xf0)>>4) | (arr[0]&0xf0);
RT_HW_PIN_DIR_ID idPin;		
RT_HW_PIN_DIR_SET_ID(idPin,  ptr[num]->pin[0]); RT_HW_PIN_DIR_WRITE(idPin,ptr[num]->cmnd);	
for(uint8_t i=0;i<8;i++) {RT_HW_PIN_DIR_SET_ID(idPin,ptr[num]->pin[2+i]); RT_HW_PIN_DIR_WRITE(idPin,bitRead(buff,i));}
RT_HW_PIN_DIR_SET_ID(idPin,ptr[num]->pin[1]); RT_HW_PIN_DIR_WRITE_HIGH(idPin); RT_HW_PIN_DIR_WRITE_LOW(idPin);
return 0;}
//---------------------------------------------------------------------------------------------------
return 1;}
//-------1.4. Функции  настройки и управления блоками вывода---------------------------------------
void	RT_HW_HD44780:: lcdGenerator   (RT_HW_HD44780_GENLCD_ID &id, uint8_t Gen, bool EN, bool Blink){					//==Генератор для вывода параметров;		 
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 
//	2.1. Генератор переменных управления для запуска функций  вывода параметров в устройство
//  Вход: 1) id.periodOut,periodBlink - период обновления переменных и мерцания;	
//		  2) Gen,EN,Blink - внешний меандр 50 мс, разрешение выводаБ разрешение мерцания; 
//  Выход 1) id.out (0/1) запуск вывода поля; id.clear запуск очистки поля; q.dir: =0 вывод запрещен; =1 -разрешен (первичный или периодический вывод); =2 -разрешена очистка;
// 		  2) id.fresh  -  вывод (при id.out=1). Дополнительно устанавливается внешней функцией. Сбрасывается блоков вывода поля и при перезапуске.
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 
//======================Обработка состояния "Перезапуск" блока управления дисплеем=================
if(Gen==2)   {id.fresh=1; id.blink=id.clear=id.out=0; id.cntEN=3; return;} 
//======================Управление при EN=1 =======================================================
if(EN){ if(id.cntEN<3) 	   {id.cntEN++; return;}
		//--------------Фиксация изменения входных переменных EN,Blink-----------------------------
		if(EN   !=id.agoEN) {id.agoEN=EN;    id.fresh=id.clear=id.out=0; id.upEN=1;}
		if(Blink!=id.agoBL) {id.agoBL=Blink;                             id.cntBlink=1; id.upBL=1;}		
		//--------------Периодическое управление (вывод,мерцание, стирание)------------------------
		if(Gen!=id.agoGen)  {id.agoGen=Gen;	//++
				  //----Восстановления поля после перехода EN 0->1---------------------------------
							if(id.upEN) {if(id.cntEN==3) {id.cntEN++; return;} 
										 if(id.cntEN==4) {id.cntEN++; id.fresh=id.out=1; return;}
										 if(id.cntEN==5) {id.cntEN++; id.fresh=id.out=1; id.cntOut=id.cntBlink=1; id.upEN=id.upBL=0; return;}}
				  //----Мерцание полем-------------------------------------------------------------
							if(Blink){if(id.upBL) {id.fresh=id.out=1; id.blink=id.upBL=0; return;}
							          if(++id.cntBlink>id.periodBlink) {id.cntBlink=1; id.blink=!id.blink;
											if(!id.blink) {id.fresh=id.out=1;} else {id.clear=1;}return;}} 	
				  //----Вывод переменных-----------------------------------------------------------															  
							if(++id.cntOut>=id.periodOut) {id.cntOut=0; id.out=1; return;} 
							}  //--if(Gen!=id.agoGen)
	 }	//--if(EN)
//======================Управление при EN=0 =======================================================
else  {if(EN!=id.agoEN)  {id.agoEN=EN; id.cntOut=id.cntBlink=id.cntEN=0; id.clear=1;}}
};	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void 	RT_HW_HD44780:: lcdSetParamID  (RT_HW_HD44780_PARAM_ID  &id, int8_t num,										//==Настройка параметров устройства;
	uint8_t col, uint8_t row, uint8_t len, uint16_t periodOut, uint16_t periodBlink, uint8_t codeSign){
  if(id.dir)							{return;}
  if(!RT_HW_Base.checkBusyNumDevice(hive.set,num)) {return;}						//--Проверка доступности номера устройства;
  id.num=num;															//--Установка номера устройства;
  if(col>(ptr[num]->cols)) {id.col=ptr[num]->cols;} else {id.col=col;}	//--Сохранение номера колонки с ограничением диапазона;
  if(row>(ptr[num]->rows)) {id.row=ptr[num]->rows;} else {id.row=row;}	//--Сохранение номера строки  с ограничением диапазона;
  uint8_t buff=ptr[num]->cols-id.col+1; 								//--Вычисляем максимальную длину допустимого поля;
  if((len==0) || (len>buff)){id.len=buff;}			else {id.len=len;}	//--Установка длины поля;
  id.event.periodOut  =timeToTick(periodOut);  							//--Настройка параметров
  id.event.periodBlink=timeToTick(periodBlink);  						//			      генератора;
  id.codeSign=codeSign;													//--Сохранение кода набора мигающих символов;
  id.dir=1;																//--Установка состояния готовности ID;
};	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++														
void 	RT_HW_HD44780:: lcdSendChar    (RT_HW_HD44780_PARAM_ID  &id, bool EN, bool Blink, char mode,char Val, bool val){//==Вывод символа (F,B,C);
if(id.dir==0) {return;}														//++Ожидание настройки ID; 
	lcdGenerator(id.event,ptr[id.num]->genState,EN,Blink);					//==Вызов генератора;
	if(!ptr[id.num]->link) 			  {id.dir=1; return;}					//==Выход, если потеряна связь;
if(id.dir==1) {if(id.event.out)  {id.event.modeOut=1; id.dir=2;}			//++Переход, если вывод параметра;
			   if(id.event.clear){id.event.modeOut=0; id.dir=2;}			//--Переход, если очистка поля; 
								  if(id.dir==1) {return;}}					//--Выход,если нет ни вывода, ни очистки;
if(id.dir==2) {if( ptr[id.num]->busy) 		    {return;} 					//++Ожидание особождения вывода;
			   if((ptr[id.num]->cols==40) && (ptr[id.num]->rows==4) && (id.row>2)) {ptr[id.num]->chip=2;} 	//--Выбор номера чипа (для LCD 40x4);
			   else                                                                {ptr[id.num]->chip=1;} 	
			   ptr[id.num]->busy=1;    id.dir++; return;}					//--Захват вывода;
if(id.dir==3) {id.event.out=id.event.clear=0;								//--Вывод, очистка поля или просто выход;
			   if(!id.event.modeOut)  {id.dir++; return;}					//--Переход, если команда очистки;	
			   if(mode=='F') {id.event.blink=!id.event.blink; id.buff=getSignBool(id.codeSign,id.event.blink); id.event.fresh=1;}	//--Если мерцание;	
			   if(mode=='B') {id.buff=getSignBool(id.codeSign,val);        if(val!=id.agoBool){id.agoBool=val; id.event.fresh=1;}}	//--Если вывод bool;
			   if(mode=='C') {    										   if(Val!=id.buff)    {id.buff=Val;   id.event.fresh=1;}}	//--Если вывод char;	
			   if(id.event.fresh==0) {id.dir=20; return;} 					//--Выход если нет изменения выводимого символа; 	
			   id.dir++;}													//--Переход на установку курсора;	
if(id.dir==4) {if(!deviceSend(id.num, pointCursor(id.col,id.row,ptr[id.num]->chip),'I',50)) {return;}			//--Установка курсора; 
			   if(!id.event.modeOut) {id.dir++;} else {id.dir=6;}
			   return;}							//--Переход на out или clear;
if(id.dir==5) {if(deviceSend(id.num,RT_HW_HD44780_BLANK,'D'))          {id.dir=20;} return;} 		//--Очистка поля;	
if(id.dir==6) {if(deviceSend(id.num,                   id.buff,'D'))   {id.dir=20;} return;} 		//--Вывод символа;   
if(id.dir==20){ptr[id.num]->busy=0;if(id.event.fresh){id.event.fresh=0;}id.dir=1;   return;}	//++Завершение;			   
};	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void    RT_HW_HD44780:: lcdSendVal     (RT_HW_HD44780_PARAM_ID  &id, RT_HW_HD44780_VAL_ID &iv, bool EN, bool Blink, char mode, char alig, int32_t val, char suff, const char *head) {
//RT_HW_Base.consoleBegin(); 
//RT_HW_Base.ConsoleV8x4('U',3,',',4,id.len,iv.head,iv.depth,iv.flagSuff); 
//RT_HW_Base.ConsoleV8x4('U',3,'E',2,iv.len,id.buff);	
if(id.dir==0) {return;}														//++Ожидание настройки ID; 
	lcdGenerator(id.event,ptr[id.num]->genState,EN,Blink);					//==Вызов генератора;
	if(!ptr[id.num]->link)           {id.dir=1;  return;}					//==Выход, если потеряна связь;
if(id.dir==1) {if(id.event.out)  {id.event.modeOut=1; id.dir=2;}			//++Переход, если вывод параметра;
			   if(id.event.clear){id.event.modeOut=0; id.dir=2;}			//--Переход,если очистка поля; 
								   if(id.dir==1){return;}} 					//--Выход,если нет ни вывода, ни очистки;
if(id.dir==2) {if(ptr[id.num]->busy) 			{return;} 					//++Ожидание особождения вывода;
			   if((ptr[id.num]->cols==40) && (ptr[id.num]->rows==4) && (id.row>2)) {ptr[id.num]->chip=2;} 	//--Выбор номера чипа (для LCD 40x4);
			   else                                                                {ptr[id.num]->chip=1;} 				   
			   ptr[id.num]->busy=1;   			   
			   id.dir++;  return;}					//--Захват вывода;
if(id.dir==3) {id.event.out=id.event.clear=0;								//--Вывод, очистка поля или просто выход;
			   if(!id.event.modeOut) {id.dir++;  return;}					//--Переход, если команда очистки;					
			   if(id.event.fresh==0) {id.dir=20; return;} 					//--Выход если нет изменения переменной (fresh устанавливает внешняя функция); 			   
			   iv.indexHead=0; iv.flagHead=0; 								//--Очистка индекса и флага для вывода заголовка;
			   id.buff=getCharLcdPGM(head,iv.indexHead);					//--Чтение первого символа;
			   if(id.buff==RT_HW_HD44780_BREAK_CHAR){iv.head=0;}  			//--Если первый символ блокирующий символ (~), то длина заголовка =0, 
							else {iv.head=getLenPGM(head,id.len);}			//    иначе длина заголовка равна длине head;
			   if(iv.head>id.len) {iv.head=id.len;}							//--Нормализация длины заголовка до размера поля;			   
			   //--Определение дополнительных параметров переменных------------
			   if((mode=='X') ||( mode=='Z')){iv.minus=iv.depth=iv.pnt=iv.point=iv.end=0;}	//--Если текст PROGMEM или линейный индикатор
			   else {setVarID(iv,mode,val);}								//--Подготовка вывода переменной в стуктуре iv;			   			   
			   //--Нормализация длины полей------------------------------------
			   if(suff==RT_HW_HD44780_BREAK_CHAR){iv.flagSuff=iv.end =0;}  else {iv.flagSuff=iv.end=1;} //--Получение длины суффикса;
			   if(getLenMess(iv)>id.len) {iv.end=0;}
			   do{if((getLenMess(iv)<=id.len) ||(iv.point==0)){break;} iv.point--;} while(1);
			   if(getLenMess(iv)>id.len) {iv.pnt=0;}
			   do{if((getLenMess(iv)<=id.len) ||(iv.head==0)) {break;} iv.head--;}  while(1);			   
			   do{if((getLenMess(iv)<=id.len) ||(iv.depth==0)){break;} iv.depth--;} while(1);
			   if(getLenMess(iv)>id.len) {iv.minus=0;}
			   //--Обработка для линейного индикатора в%-----------------------
			   if(mode=='Z') {if(val>100) {id.buff=100;} else {id.buff=val;} if(val<0) {id.buff=0;}
			   iv.end=0; iv.depth=id.len-iv.head; 
			   iv.len=round(iv.depth*id.buff/(float)100); }
			   //--Очистка регистров-------------------------------------------
			   id.dir++;}	
if(id.dir==4) {if(!deviceSend(id.num, pointCursor(id.col,id.row, ptr[id.num]->chip),'I',50)) {return;}		//==Установка курсора; 
			   iv.index=0; if(!id.event.modeOut) {id.dir++;} else {id.dir=6;}}			//--Переход на out или clear;
if(id.dir==5) {if(iv.index>=id.len){id.dir=20; return;}										//++Очистка поля (и завершение после очистки);  
			   if(!deviceSend(id.num,RT_HW_HD44780_BLANK,'D')){return;} 					//--Посимвольная очистка поля;
			   iv.index++; return;}															//--Увеличение индекса;	
if(id.dir==6) {if(iv.index>=getLenBegin(id.len,getLenMess(iv),alig)){ 						//++Вывод передних заполнителей; 
									iv.index=iv.indexHead=iv.flagHead=0; id.dir++; return;} 				//
			   if(deviceSend(id.num,RT_HW_HD44780_BLANK,'D')){iv.index++;} return;} 		//--Посимвольный вывод заполнителей;	
if(id.dir==7) {if(iv.index>=iv.head) {iv.index=0; id.dir++; return;} 						//++Вывод заголовка;
			   if(!iv.flagHead){iv.flagHead=1;id.buff=getCharLcdPGM(head,iv.indexHead);}	//--
			   if(!deviceSend(id.num,id.buff,'D')) {return;}
			   iv.flagHead=0; iv.index++; return;};											//--Увеличение индекса;	
if(id.dir==8) {if(iv.index>=iv.minus){iv.index=0; id.dir++; return;} 						//++Вывод знака '-' (если требуется);
			   if(!deviceSend(id.num,'-','D')) {return;}									//--Вывод '-';
			   iv.index++; return;}															//--Увеличение индекса;	
if(id.dir==9) {if(iv.index>=iv.depth){iv.index=0; id.dir++; return;}						//--Вывод значения до точки;  
			   if((mode=='B') || (mode=='b')) {bool v=0; 
					if(getCharVal(iv.val,1,mode,iv.len,iv.index+1)=='1') {v=1;} id.buff=getSignBool(id.codeSign,v);}
			   else if(mode=='Z'){if((iv.index+1)<=iv.len)    {id.buff=getSignBool(id.codeSign,1);}
					                    else {if(iv.flagSuff) {iv.flagSuff=0; id.buff=suff;} 
								                          else{id.buff=getSignBool(id.codeSign,0);}}}
			   else {id.buff=getCharVal(iv.val,1,mode,iv.len,iv.index+1);}
			   if(!deviceSend(id.num,id.buff,'D',0)) {return;}	
			   iv.index++;  return;} 
if(id.dir==10){if(iv.index>=iv.pnt)  {iv.index=0; id.dir++; return;}						//++Вывод точки.  
			   if(!deviceSend(id.num,'.','D')) {return;}
			   iv.index++; return;}			
if(id.dir==11){if(iv.index>=iv.point){iv.index=0; id.dir++; return;}						//++Вывод числа после точки.  					
			   if(!deviceSend(id.num,getCharVal(iv.val,1,mode,iv.len,iv.index+1+iv.depth),'D',0)) {return;} 
			   iv.index++; return;}	
if(id.dir==12){if(iv.index>=iv.end)  {iv.index=0; id.dir++; return;}						//++Вывод суффикса;		  
			   if(!deviceSend(id.num,suff,'D')) {return;}
			   iv.index++; return;}	
if(id.dir==13){if(iv.index>=getLenEnd(id.len,getLenMess(iv),alig)){iv.index=0; id.dir=20; return;} //++Вывод задних заполнителей; 
				if(!deviceSend(id.num,RT_HW_HD44780_BLANK,'D')) {return;} 			  
			    iv.index++; return;}	
if(id.dir==20){ptr[id.num]->busy=0;if(id.event.fresh){id.event.fresh=0;} id.dir=1; return;}	//++Завершение;
};	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
void    RT_HW_HD44780:: lcdSendStr     (RT_HW_HD44780_PARAM_ID  &id, RT_HW_HD44780_STR_ID &iv, bool EN, bool Blink, char mode, char alig, String str) {
if(id.dir==0) {return;}														//++Ожидание настройки ID; 
	lcdGenerator(id.event,ptr[id.num]->genState,EN,Blink);					//==Вызов генератора;
	if(!ptr[id.num]->link)                           {id.dir=1;  return;}	//==Выход, если потеряна связь;
if(id.dir==1) {if(id.event.out)  {id.event.modeOut=1; id.dir=2;}			//++Переход, если вывод параметра;
			   if(id.event.clear){id.event.modeOut=0; id.dir=2;}			//--Переход,если очистка поля; 
                                                   if(id.dir==1){return;}}	//--Выход,если нет ни вывода, ни очистки;
if(id.dir==2) {if(ptr[id.num]->busy)                            {return;}	//++Ожидание особождения вывода;
			   if((ptr[id.num]->cols==40) && (ptr[id.num]->rows==4) && (id.row>2)) {ptr[id.num]->chip=2;} 	//--Выбор номера чипа (для LCD 40x4);
			   else                                                                {ptr[id.num]->chip=1;} 		
			   ptr[id.num]->busy=1;                   id.dir++;  return;}	//--Захват вывода;
if(id.dir==3) {id.event.out=id.event.clear=0;								//--Вывод, очистка поля или просто выход;
			   if(!id.event.modeOut)                 {id.dir++;  return;}	//--Переход, если команда очистки;					
			   if(iv.agoStr!=str) {iv.agoStr=str;     id.event.fresh=1;}		//--Проверка изменения строковой переменной;			   
			   if(id.event.fresh==0) 				 {id.dir=20; return;} 	//--Выход если нет изменения входной строки;  		
			   iv.indexHead=0; iv.flagHead=0; 								//--Очистка индекса и флага для вывода заголовка;			   
			   id.buff=getCharLcdSTR(str,iv.indexHead);						//--Чтение первого символа;
			   if(id.buff==RT_HW_HD44780_BREAK_CHAR){iv.lenStr=0;}  			//--Если первый символ блокирующий символ (~), то длина заголовка =0, 
							else {iv.lenStr=getLenSTR(str,id.len);}			//    иначе длина заголовка равна длине head;
			   if(iv.lenStr>id.len) {iv.lenStr=id.len;}							//--Нормализация длины заголовка до размера поля;	
			   id.dir++;}													//--Переход на установку курсора;	
if(id.dir==4) {if(!deviceSend(id.num, pointCursor(id.col,id.row,ptr[id.num]->chip),'I',50)) {return;}	//--Установка курсора; 	   
			   iv.index=0; if(!id.event.modeOut) {id.dir++;} else {id.dir=6;}}			//--Переход на out или clear;
if(id.dir==5) {if(iv.index>=id.len){id.dir=20; return;}						//--Очистка поля (и переход на завершение после очистки);  
			   if(!deviceSend(id.num,RT_HW_HD44780_BLANK,'D'))  {return;}	//--Посимвольная очистка поля;
			   iv.index++; return;}											//--Увеличение индекса;	
if(id.dir==6) {if(iv.index>=getLenBegin(id.len,iv.lenStr,alig)){ 				//++Вывод передних заполнителей; 				
						    iv.index=iv.indexHead=iv.flagHead=0; id.dir++; return;} 
			   if(!deviceSend(id.num,RT_HW_HD44780_BLANK,'D')) {return;}//--Посимвольный вывод заполнителей;
			   iv.index++; return;} 									//--Увеличение индекса;		
if(id.dir==7) {if(iv.index>=iv.lenStr) {iv.index=0;      id.dir++; return;} 	//--Вывод заголовка;
			   if(!iv.flagHead) {iv.flagHead=1; id.buff=getCharLcdSTR(str,iv.indexHead);}
			   if(!deviceSend(id.num,id.buff,'D')) {return;}
			   iv.flagHead=0; iv.index++; return;};										//--Увеличение индекса;	
if(id.dir==8) {if(iv.index>=getLenEnd(id.len,iv.lenStr,alig))  {iv.index=0; id.dir=20; return;} //--Вывод задних заполнителей; 
			   if(!deviceSend(id.num,RT_HW_HD44780_BLANK,'D')) {return;} 			  
			   iv.index++; return;}	
if(id.dir==20){ptr[id.num]->busy=0; if(id.event.fresh) {id.event.fresh=0;} id.dir=1; return;}//++Завершение;
};	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
//=================================================================================================	
RT_HW_HD44780 RT_HW_hd44780; //--Создание объекта LCD типа HD44780
//=================================================================================================
