//*************************************************************************************************
//							1.Контроллер типа STM32F103C
//*************************************************************************************************
#if !defined(RT_HW_BOARD_SELECT) && (defined(RT_HW_BOARD_M_GENERIC_STM32F103C) ||\
									 defined(RT_HW_BOARD_D_BLUEPILL_F103C8)    || defined(RT_HW_BOARD_D_BLUEPILL_F103CB) ||\
									 defined(RT_HW_BOARD_D_BLACKPILL_F103C8)   || defined(RT_HW_BOARD_D_BLACKPILL_F103CB)||\
									 defined(RT_HW_BOARD_D_GENERIC_F103CBTX))
//---------------------------------------------------------------------------------------------------
#if                                  defined(RT_HW_BOARD_M_GENERIC_STM32F103C) 
#define        RT_HW_BOARD_SELECT	            "BOARD (M) GENERIC STM32F103C"
#define  RT_HW_STM32_ENABLE_DEFINE_PIN_F103CX		//--Разрешение #define текстовых определений пинов  
//----------------------------------------------------------------------------------------------------
#elif                                defined(RT_HW_BOARD_D_BLUEPILL_F103C8)   || defined(RT_HW_BOARD_D_BLUEPILL_F103CB)
#define        RT_HW_BOARD_SELECT	            "BOARD (D) BLUEPILL F103C8(B)"
//----------------------------------------------------------------------------------------------------
#elif                                defined(RT_HW_BOARD_D_BLACKPILL_F103C8)  || defined(RT_HW_BOARD_D_BLACKPILL_F103CB)
#define        RT_HW_BOARD_SELECT	            "BOARD (D) BLACKPILL F103C8(B)"
//----------------------------------------------------------------------------------------------------
#elif 		                         defined(RT_HW_BOARD_D_GENERIC_F103CBTX)
#define        RT_HW_BOARD_SELECT	            "BOARD (D) GENERIC F103CBTX"
//----------------------------------------------------------------------------------------------------
#else
#define        RT_HW_BOARD_SELECT	            "BOARD (X) F103C"	
#endif
//------------------------------------------------------------------------------------------------
#define RT_HW_BOARD_MEMORY 	  "FLASH=128Kb; RAM=20Kb;"						//--Параметры памяти;
#define RT_HW_PERMIT_UART0
#define RT_HW_PERMIT_UART1
#define RT_HW_PERMIT_UART2
#define RT_HW_PERMIT_UART3
#define RT_HW_PERMIT_CAN
#define RT_HW_PERMIT_I2C0
#define RT_HW_PERMIT_I2C1
#define RT_HW_PERMIT_SPI0
#define RT_HW_PERMIT_SPI1	
#define RT_HW_PERMIT_ENABLE_PIN_JTAG						        		//--Разрешение использования пинов JTAG(PA15,PB3,PB4);
//------Системные пины-----------------------------------------------------------------------------
enum   {RT_HW_BOARD_CONTROL=PB5, RT_HW_BOARD_LED=PC13, RT_HW_BOARD_BUTTON=PA0}; //--Пины контроль,led,кнопка;
//-----Параметры контроллера общие-----------------------------------------------------------------	
enum   {RT_HW_PIN_QNT_MAX=35,	RT_HW_FCPU=72, RT_HW_VCC=3300};
//-----Параметры UART------------------------------------------------------------------------------	
enum   {RT_HW_UART0_RX=PA12, RT_HW_UART0_TX=PA11,  //--USB
		RT_HW_UART1_RX=PA10, RT_HW_UART1_TX=PA9,  
		RT_HW_UART2_RX=PA3,  RT_HW_UART2_TX=PA2, 
		RT_HW_UART3_RX=PB11, RT_HW_UART3_TX=PB10};
//-----Параметры CAN------------------------------------------------------------------------------	
enum   {RT_HW_CAN_RX=PB8,    RT_HW_CAN_TX=PB9};	
//-----Параметры I2C------------------------------------------------------------------------------	
enum   {RT_HW_I2C0_SDA=PB7,  RT_HW_I2C0_SCL=PB6,  RT_HW_I2C0_MODE_FM=RT_HW_I2C_MODE_FM,
        RT_HW_I2C1_SDA=PB11, RT_HW_I2C1_SCL=PB10, RT_HW_I2C1_MODE_FM=RT_HW_I2C_MODE_FM}; 
//-----Параметры SPI------------------------------------------------------------------------------	
enum   {RT_HW_SPI0_SCK=PA5,  RT_HW_SPI0_MISO=PA6,  RT_HW_SPI0_MOSI=PA7,  RT_HW_SPI0_SS=PA4,  
        RT_HW_SPI1_SCK=PB13, RT_HW_SPI1_MISO=PB14, RT_HW_SPI1_MOSI=PB15, RT_HW_SPI1_SS=PB12};
//-----Системные параметры-------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_SYS_PAR[]  	={12,			   	RT_HW_PGM_END};  //--SYS->depth;
const uint8_t PROGMEM RT_HW_PGM_SYS_ADC[]  	={12,16,20,			RT_HW_PGM_END};  //--ADC->depth,drift,null;
const uint8_t PROGMEM RT_HW_PGM_SYS_TCH[]  	={  				RT_HW_PGM_END};  //--TCH->depth,drift,null; 
const uint8_t PROGMEM RT_HW_PGM_SYS_PWM[]  	={16,10,			RT_HW_PGM_END};  //--PWM->depth,freq; 
const uint8_t PROGMEM RT_HW_PGM_SYS_DAC[]  	={					RT_HW_PGM_END};  //--DAC->depth; 
//-----Системные пины и параметры коммуникаций------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_SYS_PIN[]  	={RT_HW_BOARD_CONTROL, RT_HW_BOARD_LED, RT_HW_BOARD_BUTTON, RT_HW_PGM_END}; //--Пины->control,led; 
const uint8_t PROGMEM RT_HW_PGM_PIN_I2C[] 	={RT_HW_I2C0_SDA, RT_HW_I2C0_SCL,                           RT_HW_PGM_END}; 
const uint8_t PROGMEM RT_HW_PGM_PIN_SPI[] 	={RT_HW_SPI0_SCK, RT_HW_SPI0_MISO, RT_HW_SPI0_MOSI, RT_HW_SPI0_SS,
											  RT_HW_SPI1_SCK, RT_HW_SPI1_MISO, RT_HW_SPI1_MOSI, RT_HW_SPI1_SS,	RT_HW_PGM_END}; 
const uint8_t PROGMEM RT_HW_PGM_PIN_UHS[] 	={RT_HW_UART0_RX, RT_HW_UART0_TX, 
										      RT_HW_UART1_RX, RT_HW_UART1_TX, 
										      RT_HW_UART2_RX, RT_HW_UART2_TX, 
										      RT_HW_UART3_RX, RT_HW_UART3_TX,           RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_USS[] 	={				 							RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_CAN[] 	={RT_HW_CAN_RX,   RT_HW_CAN_TX,				RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_BTH[] 	={				 							RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_ETH[] 	={											RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_WFI[] 	={											RT_HW_PGM_END};
//-----Доступные пины контроллера------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_ALL[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PA8,PA9,PA10,PA11,PA12,PA13,PA14,PA15,
											  PB0,PB1,PB2,PB3,PB4,PB5,PB6,PB7,PB8,PB9,PB10,PB11,PB12,PB13,PB14,PB15,
										      255,255,255,255,255,255,255,255,255,255, 255, 255, 255,PC13,PC14,PC15, RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DIN[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PA8,PA9,PA10,PA11,PA12, 255, 255,PA15,
										      PB0,PB1,255,PB3,PB4,PB5,PB6,PB7,PB8,PB9,PB10,PB11,PB12,PB13,PB14,PB15, RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_ADC[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PA8,PB0,PB1,		  					 RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_TCH[] 	={						 												 RT_HW_PGM_END};									
const uint8_t PROGMEM RT_HW_PGM_PIN_DOT[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PA8,PA9,PA10,PA11,PA12, 255, 255,PA15,
										      PB0,PB1,255,PB3,PB4,PB5,PB6,PB7,PB8,PB9,PB10,PB11,PB12,PB13,PB14,PB15,
										      255,255,255,255,255,255,255,255,255,255, 255, 255, 255,PC13,PC14,PC15,RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_PWM[] 	={PA0,PA1,PA2,PA3,PA6,PA7,PA8,PA9,PA10,PB0,PB1,PB6,PB7,PB8,PB9,			RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DAC[] 	={																		RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_INT[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PA8,PA9,PA10,PA11,PA12,PA13, 255, 255,
										      PB0,PB1,255,PB3,PB4,PB5,PB6,PB7,PB8,PB9,PB10,PB11,PB12,PB13,PB14,PB15,RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_N5V[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PB0,PB1,PB5,PC13,PC14,PC15,			RT_HW_PGM_END};	
//-----Тестовые пины и адреса------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_DBG[]  	={						RT_HW_PGM_END};	// debug1,debug2,debug3;	
const uint8_t PROGMEM RT_HW_PGM_PIN_OUT[] 	={PB1,255,PB10,			RT_HW_PGM_END};	// PWM0, PWM1, led,dev;
const uint8_t PROGMEM RT_HW_PGM_PIN_INP[] 	={PA1,255, PA0,			RT_HW_PGM_END};	// A0,   A1, btn1,btn2;
const uint8_t PROGMEM RT_HW_PGM_PIN_DCT[] 	={         				RT_HW_PGM_END};	// DAC0,DAC1,TCH0;
const uint8_t PROGMEM RT_HW_PGM_PIN_DEV[] 	={PB8, PB9, PA8, 	    RT_HW_PGM_END};	// DS1820,DHT22,HC-SR04
const uint8_t PROGMEM RT_HW_PGM_PIN_CSS[] 	={PB12,PB13,PB14,PB15,	RT_HW_PGM_END};	// CS SPI:595,LCD,NRF,DEVl 	
const uint8_t PROGMEM RT_HW_PGM_PIN_LC6[]  	={						RT_HW_PGM_END};	// Пины для подключения LCD по 4-х битной шине;
const uint8_t PROGMEM RT_HW_PGM_PIN_TFT[]  	={						RT_HW_PGM_END};	// Пины(дополнительные[]  TFT дисплея(SPI);
const uint8_t PROGMEM RT_HW_PGM_PIN_SSP[]  	={PA15,255,PB3,PB4,		RT_HW_PGM_END};	// Пины программного SPI: clk,miso,mosi,cs;	
const uint8_t PROGMEM RT_HW_PGM_ADR_I2C[]  	={63,62,32,33,			RT_HW_PGM_END};	// lcd1,lcd2,mcp1,mcp2;								   
//-------------------------------------------------------------------------------------------------
#endif
//*************************************************************************************************
//							2.Контроллер типа STM32F103R
//*************************************************************************************************
#if !defined(RT_HW_BOARD_SELECT) && (defined(RT_HW_BOARD_M_GENERIC_STM32F103R) ||\
                                     defined(RT_HW_BOARD_D_GENERIC_F103RETx)) 
//-------------------------------------------------------------------------------------------------
#if                                  defined(RT_HW_BOARD_M_GENERIC_STM32F103R) 
#define        RT_HW_BOARD_SELECT	            "BOARD (M) GENERIC STM32F103R"
#define  RT_HW_STM32_ENABLE_DEFINE_PIN_F103RX		//--Разрешение #define текстовых определений пинов  
//-------------------------------------------------------------------------------------------------
#elif                                defined(RT_HW_BOARD_D_GENERIC_F103RETx
#define        RT_HW_BOARD_SELECT	            "BOARD (D) GENERIC F103RETX"
//-------------------------------------------------------------------------------------------------
#else
#define        RT_HW_BOARD_SELECT	            "BOARD (X) F103R"	
#endif
//-------------------------------------------------------------------------------------------------
#define RT_HW_BOARD_MEMORY 	  "FLASH=512b; RAM=128Kb;"						//--Параметры памяти;
#define RT_HW_PERMIT_UART0
#define RT_HW_PERMIT_UART1
#define RT_HW_PERMIT_UART2
#define RT_HW_PERMIT_UART3
//#define RT_HW_PERMIT_UART4
//#define RT_HW_PERMIT_UART5
#define RT_HW_PERMIT_CAN
#define RT_HW_PERMIT_I2C0
#define RT_HW_PERMIT_I2C1
#define RT_HW_PERMIT_SPI0
#define RT_HW_PERMIT_SPI1
#define RT_HW_PERMIT_DAC													//--Разрешение работы с DAC;	
//------Системные пины-----------------------------------------------------------------------------
enum   {RT_HW_BOARD_CONTROL=PB5,RT_HW_BOARD_LED=PC13,RT_HW_BOARD_BUTTON=PA0};//--Пины контроль,led,кнопка;
//------Параметры контроллера общие----------------------------------------------------------------	
enum   {RT_HW_PIN_QNT_MAX=49,	 RT_HW_FCPU=72, 	   RT_HW_VCC=3300}; 
//-----Параметры UART------------------------------------------------------------------------------	
enum   {RT_HW_UART0_RX=PA12, RT_HW_UART0_TX=PA11,
		RT_HW_UART1_RX=PA10, RT_HW_UART1_TX=PA9,  RT_HW_UART2_RX=PA3, RT_HW_UART2_TX=PA2, 
		RT_HW_UART3_RX=PB11, RT_HW_UART3_TX=PB10, RT_HW_UART4_RX=PC11,RT_HW_UART4_TX=PC10,
        RT_HW_UART5_RX=PD2,  RT_HW_UART5_TX=PC12};
//-----Параметры CAN------------------------------------------------------------------------------	
enum   {RT_HW_CAN_RX=255,    RT_HW_CAN_TX=255};	
//-----Параметры I2C------------------------------------------------------------------------------	
enum   {RT_HW_I2C0_SDA=PB9,  RT_HW_I2C0_SCL=PB9,  RT_HW_I2C0_MODE_FM=RT_HW_I2C_MODE_FM,
        RT_HW_I2C1_SDA=PB11, RT_HW_I2C1_SCL=PB10, RT_HW_I2C1_MODE_FM=RT_HW_I2C_MODE_FM}; 
//-----Параметры SPI------------------------------------------------------------------------------	
enum   {RT_HW_SPI0_SCK=PA5,  RT_HW_SPI0_MISO=PA6,  RT_HW_SPI0_MOSI=PA7,  RT_HW_SPI0_SS=PA4,  
        RT_HW_SPI1_SCK=PB13, RT_HW_SPI1_MISO=PB14, RT_HW_SPI1_MOSI=PB15, RT_HW_SPI1_SS=PB12};
//-----Системные параметры-------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_SYS_PAR[]  	={12,			   	RT_HW_PGM_END};  //--SYS->depth;
const uint8_t PROGMEM RT_HW_PGM_SYS_ADC[]  	={12,4,3,			RT_HW_PGM_END};  //--ADC->depth,drift,null;
const uint8_t PROGMEM RT_HW_PGM_SYS_TCH[]  	={  				RT_HW_PGM_END};  //--TCH->depth,drift,null; 
const uint8_t PROGMEM RT_HW_PGM_SYS_PWM[] 	={16,10,			RT_HW_PGM_END};  //--PWM->depth,freq; 
const uint8_t PROGMEM RT_HW_PGM_SYS_DAC[] 	={					RT_HW_PGM_END};  //--DAC->depth; 
//-----Системные пины и параметры коммуникаций------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_SYS_PIN[]  	={RT_HW_BOARD_CONTROL, RT_HW_BOARD_LED, RT_HW_BOARD_BUTTON, RT_HW_PGM_END};  //--Пины->control,led; 
const uint8_t PROGMEM RT_HW_PGM_PIN_I2C[] 	={RT_HW_I2C0_SDA, RT_HW_I2C0_SCL, 
                                              RT_HW_I2C1_SDA, RT_HW_I2C1_SCL,           RT_HW_PGM_END};  
const uint8_t PROGMEM RT_HW_PGM_PIN_SPI[] 	={RT_HW_SPI0_SCK, RT_HW_SPI0_MISO, RT_HW_SPI0_MOSI, RT_HW_SPI0_SS,
											  RT_HW_SPI1_SCK, RT_HW_SPI1_MISO, RT_HW_SPI1_MOSI, RT_HW_SPI1_SS,	RT_HW_PGM_END}; 
const uint8_t PROGMEM RT_HW_PGM_PIN_UHS[] 	={RT_HW_UART0_RX, RT_HW_UART0_TX, 
											  RT_HW_UART1_RX, RT_HW_UART1_TX, 
											  RT_HW_UART2_RX, RT_HW_UART2_TX, 
											  RT_HW_UART3_RX, RT_HW_UART3_TX, 
											  RT_HW_UART4_RX, RT_HW_UART4_TX,
											  RT_HW_UART5_RX, RT_HW_UART5_TX,           RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_USS[] 	={				 							RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_CAN[] 	={RT_HW_CAN_RX,   RT_HW_CAN_TX, 			RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_BTH[] 	={				 							RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_ETH[] 	={											RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_WFI[] 	={											RT_HW_PGM_END};
//-----Доступные пины контроллера------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_ALL[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PA8,PA9,PA10,PA11,PA12,PA13,PA14,PA15,
											  PB0,PB1,PB2,PB3,PB4,PB5,PB6,PB7,PB8,PB9,PB10,PB11,PB12,PB13,PB14,PB15,
											  PC0,PC1,PC2,PC3,PC4,PC5,PC6,PC7,PC8,PC9,PC10,PC11,PC12,PC13,PC14,PC15,
										          PD2,											 					RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DIN[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PA8,PA9,PA10,PA11,PA12,255,255,PA15,
											  PB0,PB1,255,PB3,PB4,PB5,PB6,PB7,PB8,PB9,PB10,PB11,PB12,PB13,PB14,PB15,
										      PC0,PC1,PC2,PC3,PC4,PC5,PC6,PC7,PC8,PC9,PC10,PC11,PC12,PC13,PC14,PC15,
										      255,255,PD2,											 				RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_ADC[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PA8,PB0,PB1,PC0,PC1,PC2,PC3,PC4,PC5,  RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_TCH[] 	={						 												RT_HW_PGM_END};									
const uint8_t PROGMEM RT_HW_PGM_PIN_DOT[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PA8,PA9,PA10,PA11,PA12, 255, 255,PA15,
										      PB0,PB1,255,PB3,PB4,PB5,PB6,PB7,PB8,PB9,PB10,PB11,PB12,PB13,PB14,PB15,
										      PC0,PC1,PC2,PC3,PC4,PC5,PC6,PC7,PC8,PC9,PC10,PC11,PC12,PC13,PC14,PC15,
										      255,255,PD2,											 				RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_PWM[] 	={PA0,PA1,PA2,PA3,PA6,PA7,PA8,PA9,PA10,PB0,PB1,PB6,PB7,PB8,PB9,			RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DAC[] 	={PA3,PA4,																RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_INT[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PA8,PA9,PA10,PA11,PA12,PA13, 255, 255,
										      PB0,PB1,255,PB3,PB4,PB5,PB6,PB7,PB8,PB9,PB10,PB11,PB12,PB13,PB14,PB15,RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_N5V[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PB0,PB1,PB5,PC4,PC5,PB0,PB1,PB5,
										      PC13,PC14,PC15,														RT_HW_PGM_END};	
//-----Тестовые пины и адреса------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_DBG[]  	={						RT_HW_PGM_END};	// debug1,debug2,debug3;	
const uint8_t PROGMEM RT_HW_PGM_PIN_OUT[] 	={PB0,255, PA4,			RT_HW_PGM_END};	// PWM0, PWM1, led,dev;
const uint8_t PROGMEM RT_HW_PGM_PIN_INP[] 	={PA1,255, PA0,			RT_HW_PGM_END};	// A0,   A1, btn1,btn2;
const uint8_t PROGMEM RT_HW_PGM_PIN_DCT[] 	={         				RT_HW_PGM_END};	// DAC0,DAC1,TCH0;
const uint8_t PROGMEM RT_HW_PGM_PIN_DEV[] 	={PB8, PB9, PA8, 	    RT_HW_PGM_END};	// DS1820,DHT22,HC-SR04
const uint8_t PROGMEM RT_HW_PGM_PIN_CSS[] 	={PB12,PB13,PB14,PB15,	RT_HW_PGM_END};	// CS SPI:595,LCD,NRF,DEVl 	
const uint8_t PROGMEM RT_HW_PGM_PIN_LC6[]  	={						RT_HW_PGM_END};	// Пины для подключения LCD по 4-х битной шине;
const uint8_t PROGMEM RT_HW_PGM_PIN_TFT[]  	={						RT_HW_PGM_END};	// Пины(дополнительные[]  TFT дисплея(SPI[] ;
const uint8_t PROGMEM RT_HW_PGM_PIN_SSP[]  	={						RT_HW_PGM_END};	// Пины программного SPI;	
const uint8_t PROGMEM RT_HW_PGM_ADR_I2C[]  	={63,62,32,33,			RT_HW_PGM_END};	// lcd1,lcd2,mcp1,mcp2;		
//-------------------------------------------------------------------------------------------------
#endif

//*************************************************************************************************
//							3.Контроллер типа STM32F103V
//*************************************************************************************************
#if !defined(RT_HW_BOARD_SELECT) &&  (defined(RT_HW_BOARD_M_GENERIC_STM32F103V) || defined(RT_HW_BOARD_D_Generic_F103VETx)) 
//-------------------------------------------------------------------------------------------------
#if                                  defined(RT_HW_BOARD_M_GENERIC_STM32F103V) 
#define        RT_HW_BOARD_SELECT	            "BOARD (M) GENERIC STM32F103V"
#define  RT_HW_STM32_ENABLE_DEFINE_PIN_F103RX		//--Разрешение #define текстовых определений пинов  
//-------------------------------------------------------------------------------------------------
#elif                                defined(RT_HW_BOARD_D_GENERIC_F103VETx
#define        RT_HW_BOARD_SELECT	            "BOARD (D) GENERIC F103VETX"
//-------------------------------------------------------------------------------------------------
#else
#define        RT_HW_BOARD_SELECT	            "BOARD (X) F103V"	
#endif
//-------------------------------------------------------------------------------------------------
#define RT_HW_BOARD_MEMORY 	  "FLASH=512b; RAM=128Kb;"						//--Параметры памяти;
#define RT_HW_PERMIT_UART0
#define RT_HW_PERMIT_UART1
#define RT_HW_PERMIT_UART2
#define RT_HW_PERMIT_UART3
//#define RT_HW_PERMIT_UART4
//#define RT_HW_PERMIT_UART5
#define RT_HW_PERMIT_CAN
#define RT_HW_PERMIT_I2C0
#define RT_HW_PERMIT_I2C1
#define RT_HW_PERMIT_SPI0
#define RT_HW_PERMIT_SPI1	
#define RT_HW_PERMIT_DAC													//--Разрешение работы с DAC;
//------Системные пины-----------------------------------------------------------------------------
enum  {RT_HW_BOARD_CONTROL=PC2,RT_HW_BOARD_LED=PB12,RT_HW_BOARD_BUTTON=PA0};//--Пины контроль,led,кнопка;
//------Параметры контроллера общие----------------------------------------------------------------	
enum{RT_HW_PIN_QNT_MAX=80,	RT_HW_FCPU=72, 		RT_HW_VCC=3300};
//-----Параметры UART------------------------------------------------------------------------------	
enum   {RT_HW_UART0_RX=PA12, RT_HW_UART0_TX=PA11,
		RT_HW_UART1_RX=PA10, RT_HW_UART1_TX=PA9,  RT_HW_UART2_RX=PA3, RT_HW_UART2_TX=PA2, 
		RT_HW_UART3_RX=PB11, RT_HW_UART3_TX=PB10, RT_HW_UART4_RX=PC11,RT_HW_UART4_TX=PC10,
        RT_HW_UART5_RX=PD2,  RT_HW_UART5_TX=PC12};
//-----Параметры CAN------------------------------------------------------------------------------	
enum   {RT_HW_CAN_RX=PD0,    RT_HW_CAN_TX=PD1};	
//-----Параметры I2C------------------------------------------------------------------------------	
enum   {RT_HW_I2C0_SDA=PB9,  RT_HW_I2C0_SCL=PB9,  RT_HW_I2C0_MODE_FM=RT_HW_I2C_MODE_FM,
        RT_HW_I2C1_SDA=PB11, RT_HW_I2C1_SCL=PB10, RT_HW_I2C1_MODE_FM=RT_HW_I2C_MODE_FM}; 
//-----Параметры SPI------------------------------------------------------------------------------	
enum   {RT_HW_SPI0_SCK=PA5,  RT_HW_SPI0_MISO=PA6,  RT_HW_SPI0_MOSI=PA7,  RT_HW_SPI0_SS=PA4,  
        RT_HW_SPI1_SCK=PB13, RT_HW_SPI1_MISO=PB14, RT_HW_SPI1_MOSI=PB15, RT_HW_SPI1_SS=PB12};
//-----Системные параметры-------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_SYS_PAR[]  ={12,			   	RT_HW_PGM_END};  //--SYS->depth;
const uint8_t PROGMEM RT_HW_PGM_SYS_ADC[]  ={12,4,3,			RT_HW_PGM_END};  //--ADC->depth,drift,null;
const uint8_t PROGMEM RT_HW_PGM_SYS_TCH[]  ={  				RT_HW_PGM_END};  //--TCH->depth,drift,null; 
const uint8_t PROGMEM RT_HW_PGM_SYS_PWM[]  ={16,10,			RT_HW_PGM_END};  //--PWM->depth,freq; 
const uint8_t PROGMEM RT_HW_PGM_SYS_DAC[]  ={					RT_HW_PGM_END};  //--DAC->depth; 
//-----Системные пины и параметры коммуникаций------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_SYS_PIN[]  	={RT_HW_BOARD_CONTROL, RT_HW_BOARD_LED, RT_HW_BOARD_BUTTON,        RT_HW_PGM_END};  //--Пины->control,led; 
const uint8_t PROGMEM RT_HW_PGM_PIN_I2C[] 	={RT_HW_I2C0_SDA, RT_HW_I2C0_SCL, 
                                              RT_HW_I2C1_SDA, RT_HW_I2C1_SCL,  RT_HW_PGM_END}; //--adr,SDA,SCL,mode; 
const uint8_t PROGMEM RT_HW_PGM_PIN_SPI[] 	={RT_HW_SPI0_SCK, RT_HW_SPI0_MISO, RT_HW_SPI0_MOSI, RT_HW_SPI0_SS,
											  RT_HW_SPI1_SCK, RT_HW_SPI1_MISO, RT_HW_SPI1_MOSI, RT_HW_SPI1_SS,	RT_HW_PGM_END}; 
const uint8_t PROGMEM RT_HW_PGM_PIN_UHS[] 	={RT_HW_UART0_RX, RT_HW_UART0_TX, 
											  RT_HW_UART1_RX, RT_HW_UART1_TX, 
											  RT_HW_UART2_RX, RT_HW_UART2_TX, 
											  RT_HW_UART3_RX, RT_HW_UART3_TX, 
											  RT_HW_UART4_RX, RT_HW_UART4_TX,
											  RT_HW_UART5_RX, RT_HW_UART5_TX,           RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_USS[] 	={				 							RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_CAN[] 	={RT_HW_CAN_RX,   RT_HW_CAN_TX, 			RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_BTH[] 	={				 							RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_ETH[] 	={											RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_WFI[] 	={											RT_HW_PGM_END};
//-----Доступные пины контроллера------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_ALL[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PA8,PA9,PA10,PA11,PA12,PA13,PA14,PA15,
										      PB0,PB1,PB2,PB3,PB4,PB5,PB6,PB7,PB8,PB9,PB10,PB11,PB12,PB13,PB14,PB15,
										      PC0,PC1,PC2,PC3,PC4,PC5,PC6,PC7,PC8,PC9,PC10,PC11,PC12,PC13,PC14,PC15,
										      PD0,PD1,PD2,PD3,PD4,PD5,PD6,PD7,PD8,PD9,PD10,PD11,PD12,PD13,PD14,PD15,
										      PE0,PE1,PE2,PE3,PE4,PE5,PE6,PE7,PE8,PE9,PE10,PE11,PE12,PE13,PE14,PE15,RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DIN[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PA8,PA9,PA10,PA11,PA12, 255, 255,PA15,
										      PB0,PB1,255,PB3,PB4,PB5,PB6,PB7,PB8,PB9,PB10,PB11,PB12,PB13,PB14,PB15,
											  PC0,PC1,PC2,PC3,PC4,PC5,PC6,PC7,PC8,PC9,PC10,PC11,PC12,PC13,PC14,PC15,
											  PD0,PD1,PD2,PD3,PD4,PD5,PD6,PD7,PD8,PD9,PD10,PD11,PD12,PD13,PD14,PD15,
										      PE0,PE1,PE2,PE3,PE4,PE5,PE6,PE7,PE8,PE9,PE10,PE11,PE12,PE13,PE14,PE15,RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_ADC[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PA8,PB0,PB1,PC0,PC1,PC2,PC3,PC4,PC5,  RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_TCH[] 	={						 												RT_HW_PGM_END};									
const uint8_t PROGMEM RT_HW_PGM_PIN_DOT[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PA8,PA9,PA10,PA11,PA12, 255, 255,PA15,
											  PB0,PB1,255,PB3,PB4,PB5,PB6,PB7,PB8,PB9,PB10,PB11,PB12,PB13,PB14,PB15,
											  PC0,PC1,PC2,PC3,PC4,PC5,PC6,PC7,PC8,PC9,PC10,PC11,PC12,PC13,PC14,PC15,
											  PD0,PD1,PD2,PD3,PD4,PD5,PD6,PD7,PD8,PD9,PD10,PD11,PD12,PD13,PD14,PD15,
											  PE0,PE1,PE2,PE3,PE4,PE5,PE6,PE7,PE8,PE9,PE10,PE11,PE12,PE13,PE14,PE15,RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_PWM[] 	={PA0,PA1,PA2,PA3,PA6,PA7,PA8,PA9,PA10,PB0,PB1,PB6,PB7,PB8,PB9,			RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DAC[] 	={PA3,PA4,																RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_INT[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PA8,PA9,PA10,PA11,PA12, 255, 255,PA15,
											  PB0,PB1,255,PB3,PB4,PB5,PB6,PB7,PB8,PB9,PB10,PB11,PB12,PB13,PB14,PB15,
											  PC0,PC1,PC2,PC3,PC4,PC5,PC6,PC7,PC8,PC9,PC10,PC11,PC12,PC13,PC14,PC15,
											  PD0,PD1,PD2,PD3,PD4,PD5,PD6,PD7,PD8,PD9,PD10,PD11,PD12,PD13,PD14,PD15,
											  PE0,PE1,PE2,PE3,PE4,PE5,PE6,PE7,PE8,PE9,PE10,PE11,PE12,PE13,PE14,PE15,RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_N5V[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PB0,PB1,PB5,PC4,PC5,PB0,PB1,PB5,
											  PC13,PC14,PC15,														RT_HW_PGM_END};	
//-----Тестовые пины и адреса------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_DBG[]  	={						RT_HW_PGM_END};	// debug1,debug2,debug3;	
const uint8_t PROGMEM RT_HW_PGM_PIN_OUT[] 	={PB0, 255,PA4,			RT_HW_PGM_END};	// PWM0, PWM1, led,dev;
const uint8_t PROGMEM RT_HW_PGM_PIN_INP[] 	={PA1,255, PA0,			RT_HW_PGM_END};	// A0,   A1, btn1,btn2;
const uint8_t PROGMEM RT_HW_PGM_PIN_DCT[] 	={         				RT_HW_PGM_END};	// DAC0,DAC1,TCH0;
const uint8_t PROGMEM RT_HW_PGM_PIN_DEV[] 	={PB8, PB9, PA8, 	    RT_HW_PGM_END};	// DS1820,DHT22,HC-SR04
const uint8_t PROGMEM RT_HW_PGM_PIN_CSS[] 	={PB12,PB13,PB14,PB15,	RT_HW_PGM_END};	// CS SPI:595,LCD,NRF,DEVl 	
const uint8_t PROGMEM RT_HW_PGM_PIN_LC6[]  	={						RT_HW_PGM_END};	// Пины для подключения LCD по 4-х битной шине;
const uint8_t PROGMEM RT_HW_PGM_PIN_TFT[]  	={						RT_HW_PGM_END};	// Пины(дополнительные[]  TFT дисплея(SPI[] ;
const uint8_t PROGMEM RT_HW_PGM_PIN_SSP[]  	={						RT_HW_PGM_END};	// Пины программного SPI;	
const uint8_t PROGMEM RT_HW_PGM_ADR_I2C[]  	={63,62,32,33,			RT_HW_PGM_END};	// lcd1,lcd2,mcp1,mcp2;		
//-------------------------------------------------------------------------------------------------
#endif
