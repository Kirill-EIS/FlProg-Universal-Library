 #include "RT_HW_BASE.h"
//=================================================================================================
//							ФУНКЦИИ ДЛЯ РАБОТЫ С CRC
//=================================================================================================
uint8_t  RT_HW_BASE:: crc8       (const uint8_t* addr,  uint8_t len){											//==Расчет CRC8 (Dallas Semiconductor 8 bit CRC);
uint8_t crc = 0;
while (len--) {crc = *addr++ ^ crc;  crc = pgm_read_byte(RT_HW_PGM_TABLE_CRC8_2X16 + (crc & 0x0f)) ^ pgm_read_byte(RT_HW_PGM_TABLE_CRC8_2X16 + 16 + ((crc >> 4) & 0x0f));}
return crc;}
uint16_t RT_HW_BASE:: crc16      (const uint8_t* input, uint16_t len, uint16_t crc){								//==Расчет CRC16;
  static const uint8_t oddparity[16] ={ 0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0 };
  for (uint16_t i=0; i<len; i++) {uint16_t cdata = input[i]; cdata = (cdata ^ crc) & 0xff; crc >>= 8;
                                  if (oddparity[cdata & 0x0F] ^ oddparity[cdata >> 4]) {crc ^= 0xC001;}
								  cdata <<= 6; crc ^= cdata; cdata <<= 1; crc ^= cdata; }
return crc;}
bool     RT_HW_BASE:: check_crc16(const uint8_t* input, uint16_t len, const uint8_t* inverted_crc, uint16_t crc){//==Расчет CRC16;
 crc = ~crc16(input, len, crc); return (crc & 0xFF) == inverted_crc[0] && (crc >> 8) == inverted_crc[1];}

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++