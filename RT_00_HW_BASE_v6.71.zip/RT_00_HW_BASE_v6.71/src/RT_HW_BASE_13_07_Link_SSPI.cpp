 #include "RT_HW_BASE.h"

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//								Отправка байта SSPI
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void RT_HW_BASE:: sspiSendByte(uint8_t clk, uint8_t mosi, uint8_t cs, uint8_t val, uint8_t bitOrder){			//==Отправка байта  SSPI; 
RT_HW_PIN_DIR_ID idCLK, idMOSI, idCS; 
RT_HW_PIN_DIR_SET_ID(idCLK,clk);
RT_HW_PIN_DIR_SET_ID(idMOSI,mosi);
RT_HW_PIN_DIR_SET_ID(idCS,cs);
RT_HW_PIN_DIR_WRITE_LOW(idCS);
if(bitOrder == MSBFIRST) {
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,7)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,6)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);	
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,5)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,4)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,3)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,2)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,1)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);
    RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,0)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);}
else         			{
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,0)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,1)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);	
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,2)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,3)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,4)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,5)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,6)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);
    RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,7)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);}	
RT_HW_PIN_DIR_WRITE_HIGH(idCS);
RT_HW_PIN_DIR_WRITE_LOW(idMOSI);
};

uint8_t RT_HW_BASE:: sspiTransfer(uint8_t clk, uint8_t miso, uint8_t mosi, uint8_t cs, uint8_t val, uint8_t bitOrder){			//==Отправка байта  SSPI; 
RT_HW_PIN_DIR_ID idCLK, idMISO, idMOSI; 
RT_HW_PIN_DIR_SET_ID(idCLK,clk);
RT_HW_PIN_DIR_SET_ID(idMISO,miso);
RT_HW_PIN_DIR_SET_ID(idMOSI,mosi);
//RT_HW_PIN_DIR_SET_ID(idCS,cs);
if(bitOrder == MSBFIRST) {
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,7)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,6)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);	
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,5)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,4)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,3)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,2)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,1)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);
    RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,0)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);}
else         			{
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,0)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,1)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);	
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,2)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,3)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,4)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,5)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);
	RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,6)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);
    RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,7)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);}	
return 0;};

/*
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//								Проверка и настройка пинов SSPI
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
uint8_t RT_HW_BASE:: sspiSetPinFull(RT_HW_STRUCT_SSPI &id, uint8_t clk, uint8_t miso, uint8_t mosi, uint8_t cs){	//==Настройка пинов SSPI на двухсторонний обмен;

uint8_t v=0;	
	 if(!RT_HW_Base.checkPinPGM(RT_HW_PGM_PIN_DOT_ID,clk )){bitSet(v,3);}		//--Проверка пина  clk на дискретный вывод;
	 if(!RT_HW_Base.checkPinPGM(RT_HW_PGM_PIN_DIN_ID,miso)){bitSet(v,2);}		//--Проверка пина miso на дискретный  ввод;
	 if(!RT_HW_Base.checkPinPGM(RT_HW_PGM_PIN_DOT_ID,mosi)){bitSet(v,1);}		//--Проверка пина mosi на дискретный  ввод;  	 
	 if(!RT_HW_Base.checkPinPGM(RT_HW_PGM_PIN_DOT_ID,cs))  {bitSet(v,0);}		//--Проверка пина   cs на дискретный вывод; 		
	 if(v) {return v;}															//--Выход, если функционально не доступный пин;
	 RT_HW_PIN_DIR_SET_ID(id.cs,cs);     RT_HW_PIN_DIR_WRITE_HIGH(id.cs);   RT_HW_PIN_DIR_MODE_OUTPUT(id.cs); 	//--Настройка cs на вывод; 	
	 RT_HW_PIN_DIR_SET_ID(id.clk,clk);   RT_HW_PIN_DIR_WRITE_LOW(id.clk);   RT_HW_PIN_DIR_MODE_OUTPUT(id.clk); 	//--Настройка clk 	на вывод; 	
	 RT_HW_PIN_DIR_SET_ID(id.miso,miso);   								  	RT_HW_PIN_DIR_MODE_INPUT(id.miso);	//--Настройка miso 	на ввод; 	
	 RT_HW_PIN_DIR_SET_ID(id.mosi,mosi); RT_HW_PIN_DIR_WRITE_LOW(id.mosi);  RT_HW_PIN_DIR_MODE_OUTPUT(id.mosi);	//--Настройка mosi 	на вывод; 
return 0;}
uint8_t RT_HW_BASE:: sspiSetPinOutput(RT_HW_STRUCT_SSPI &id, uint8_t clk, uint8_t mosi, uint8_t cs){				//==Настройка пинов SSPI на операции вывода;
	uint8_t v=0;																								//--Инициализация временной переменной;
	if(!RT_HW_Base.checkPinPGM(RT_HW_PGM_PIN_DOT_ID,clk )){bitSet(v,3);}										//--Проверка пина  clk на дискретный вывод;
	if(!RT_HW_Base.checkPinPGM(RT_HW_PGM_PIN_DOT_ID,mosi)){bitSet(v,1);}										//--Проверка пина mosi на дискретный  ввод;  	 
	if(!RT_HW_Base.checkPinPGM(RT_HW_PGM_PIN_DOT_ID,cs))  {bitSet(v,0);}										//--Проверка пина   cs на дискретный вывод; 		
	id.checkPin=v;	
	if(id.checkPin) {bitSet(id.checkPin,7); return id.checkPin;}								//--Выход, если функционально не доступный пин;
	RT_HW_PIN_DIR_SET_ID(id.cs,cs);     RT_HW_PIN_DIR_WRITE_HIGH(id.cs);   RT_HW_PIN_DIR_MODE_OUTPUT(id.cs); 	//--Настройка cs на вывод; 	
	RT_HW_PIN_DIR_SET_ID(id.clk,clk);   RT_HW_PIN_DIR_WRITE_LOW(id.clk);   RT_HW_PIN_DIR_MODE_OUTPUT(id.clk); 	//--Настройка clk 	на вывод; 		
	RT_HW_PIN_DIR_SET_ID(id.mosi,mosi); RT_HW_PIN_DIR_WRITE_LOW(id.mosi);  RT_HW_PIN_DIR_MODE_OUTPUT(id.mosi);	//--Настройка mosi 	на вывод; 
return 0;}
uint8_t RT_HW_BASE:: sspiSetPinInput(RT_HW_STRUCT_SSPI &id, uint8_t clk, uint8_t miso, uint8_t cs){					//==Настройка пинов SSPI на операции ввода;
uint8_t v=0;	
	 if(!RT_HW_Base.checkPinPGM(RT_HW_PGM_PIN_DOT_ID,clk )){bitSet(v,3);}		//--Проверка пина  clk на дискретный вывод;
	 if(!RT_HW_Base.checkPinPGM(RT_HW_PGM_PIN_DIN_ID,miso)){bitSet(v,2);}		//--Проверка пина miso на дискретный  ввод;	 
	 if(!RT_HW_Base.checkPinPGM(RT_HW_PGM_PIN_DOT_ID,cs))  {bitSet(v,0);}		//--Проверка пина   cs на дискретный вывод; 		
	 if(v) {return v;}															//--Выход, если функционально не доступный пин;
	 RT_HW_PIN_DIR_SET_ID(id.cs,cs);     RT_HW_PIN_DIR_WRITE_HIGH(id.cs);   RT_HW_PIN_DIR_MODE_OUTPUT(id.cs); 	//--Настройка cs на вывод; 	
	 RT_HW_PIN_DIR_SET_ID(id.clk,clk);   RT_HW_PIN_DIR_WRITE_LOW(id.clk);   RT_HW_PIN_DIR_MODE_OUTPUT(id.clk); 	//--Настройка clk 	на вывод; 	
	 RT_HW_PIN_DIR_SET_ID(id.miso,miso);   								  	RT_HW_PIN_DIR_MODE_INPUT(id.miso);	//--Настройка miso 	на ввод; 	
return 0;}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//								Инициализация обмена
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void    RT_HW_BASE:: sspiBeginTransaction(RT_HW_STRUCT_SSPI &id, uint8_t bitOrder, uint8_t dataMode, uint8_t interruptMode){	//==Настройка параметров обмена;
id.bitOrder=bitOrder;
id.dataMode=dataMode;
id.interruptMode=interruptMode;
};
void    RT_HW_BASE:: sspiEndTransaction(RT_HW_STRUCT_SSPI &id){																	//==Восстановление параметров обмена;
id.bitOrder=     RT_HW_SPI_BIT_ORDER;
id.dataMode=     RT_HW_SPI_DATA_MODE;
id.interruptMode=RT_HW_SPI_INTERRUPT_MODE;
};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//								Отправка байта SSPI
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void RT_HW_BASE:: sspiSendByte(uint8_t &clk, uint8_t &mosi, uint8_t &cs, uint8_t &val, uint8_t &bitOrder){			//==Отправка байта  SSPI; 
RT_HW_PIN_DIR_ID idCLK, idMOSI, idCS; 
RT_HW_PIN_DIR_SET_ID(idCLK,clk);
RT_HW_PIN_DIR_SET_ID(idMOSI,mosi);
RT_HW_PIN_DIR_SET_ID(idCS,cs);
RT_HW_PIN_DIR_WRITE_LOW(idCS);
for (uint8_t i=0; i<8; i++){
	if(bitOrder == MSBFIRST) {RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,7-i)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);}	//--Отправка байта LSBFIRST;
    else                     {RT_HW_PIN_DIR_WRITE(idMOSI, bitRead(val,  i)); RT_HW_PIN_DIR_WRITE_HIGH(idCLK); RT_HW_PIN_DIR_WRITE_LOW(idCLK);}}	//--Отправка байта HSBFIRST;
RT_HW_PIN_DIR_WRITE_LOW(idMOSI);
RT_HW_PIN_DIR_WRITE_HIGH(idCS);};




//void RT_HW_BASE:: sspiSendByte(uint8_t clk, uint8_t mosi, uint8_t val, uint8_t bitOrder){
//for (uint8_t i=0; i<8; i++){
//	if(bitOrder == LSBFIRST) {    digitalWrite(mosi, bitRead(val,7-i));  digitalWrite(clk,1);          digitalWrite(clk,0);}				//--Отправка байта LSBFIRST;
//    else  				     {    digitalWrite(mosi, bitRead(val,  i));  digitalWrite(clk,1);          digitalWrite(clk,0);}}				//--Отправка байта LSBFIRST;
//digitalWrite(mosi,0);}; 																													//--Приводим в исходное состояние пин mosi;



//---------------------------3.ОТПРАВКА БАЙТОВ------------------------------------------------------
void RT_HW_BASE:: sspiSendByte(RT_HW_STRUCT_SSPI &id, uint8_t val){			//==Отправка байта  SSPI; 
for (uint8_t i=0; i<8; i++){
	if(id.bitOrder == MSBFIRST) {RT_HW_PIN_DIR_WRITE(id.mosi, bitRead(val,7-i)); RT_HW_PIN_DIR_WRITE_HIGH(id.clk); RT_HW_PIN_DIR_WRITE_LOW(id.clk);}	//--Отправка байта LSBFIRST;
    else                        {RT_HW_PIN_DIR_WRITE(id.mosi, bitRead(val,  i)); RT_HW_PIN_DIR_WRITE_HIGH(id.clk); RT_HW_PIN_DIR_WRITE_LOW(id.clk);}}	//--Отправка байта HSBFIRST;
RT_HW_PIN_DIR_WRITE_LOW(id.mosi);}; 																												//--Приводим в исходное состояние пин mosi;



void RT_HW_BASE:: sspiSendBytes(RT_HW_PIN_DIR_ID &clk, RT_HW_PIN_DIR_ID &miso, RT_HW_PIN_DIR_ID &mosi, RT_HW_PIN_DIR_ID &cs, char mode, uint8_t val){
uint8_t v; 
if(mode=='F') {v=val;} else {v=255-val;}			//--Установка выводимой переменной в зависимости от режима;
RT_HW_PIN_DIR_WRITE_LOW(cs);					//--Разрешаем доступ к устройству:
for (uint8_t i=0; i<8; i++){RT_HW_PIN_DIR_WRITE(mosi, bitRead(val,7-i)); RT_HW_PIN_DIR_WRITE_HIGH(clk); RT_HW_PIN_DIR_WRITE_LOW(clk);}	//--Отправка байта;
RT_HW_PIN_DIR_WRITE_HIGH(mosi); 				//--Приводим в исходное состояние пин mosi;
RT_HW_PIN_DIR_WRITE_HIGH(cs); 					//--Защелкиваем переданный байт в устройстве;
};

void RT_HW_BASE:: sspiSendByte(uint8_t clk, uint8_t miso, uint8_t mosi, uint8_t cs, char mode, uint8_t val){
uint8_t v; 
if(mode=='F') {v=val;} else {v=255-val;}			//--Установка выводимой переменной в зависимости от режима;
digitalWrite(cs,0);									//--Разрешаем доступ к устройству:
for (uint8_t i=0; i<8; i++){digitalWrite(mosi, bitRead(val,7-i)); digitalWrite(mosi,1); digitalWrite(mosi,1);}	//--Отправка байта;
digitalWrite(mosi,1); 								//--Приводим в исходное состояние пин mosi;
digitalWrite(cs,1); 								//--Защелкиваем переданный байт в устройстве;
};
*/
//-----------------------------------------------------------------------
/*
uint8_t shiftIn(uint8_t dataPin, uint8_t clockPin, uint8_t bitOrder) {
	uint8_t value = 0;
	uint8_t i;

	for (i = 0; i < 8; ++i) {
		digitalWrite(clockPin, HIGH);
		if (bitOrder == LSBFIRST)
			value |= digitalRead(dataPin) << i;
		else
			value |= digitalRead(dataPin) << (7 - i);
		digitalWrite(clockPin, LOW);
	}
	return value;
}
//-----------------------------------
void shiftOut(uint8_t dataPin, uint8_t clockPin, uint8_t bitOrder, uint8_t val)
{
	uint8_t i;

	for (i = 0; i < 8; i++)  {
		if (bitOrder == LSBFIRST) {
			digitalWrite(dataPin, val & 1);
			val >>= 1;
		} else {	
			digitalWrite(dataPin, (val & 128) != 0);
			val <<= 1;
		}
			
		digitalWrite(clockPin, HIGH);
		digitalWrite(clockPin, LOW);		
	}
}
*/
//-----------------------------------------


/*
void RT_HW_MAX6675::readRawData(RT_HW_MAX6675_ID &id){id.rawData=0;
if(id.modeInterface) {SPI.beginTransaction(SPISettings(4000000, MSBFIRST, SPI_MODE0)); //up to 4MHz, read MSB first, SPI mode 0, see note
					  digitalWrite(id.cs,0);  id.rawData = SPI.transfer16(0x0000);  digitalWrite(id.cs,1); SPI.endTransaction(); } 
                else {digitalWrite(id.cs,0);                        
					  if(RT_HW_MAX6675_ENABLE_BLOCK_INTERRUPT) {noInterrupts();}         //--Запрет прерываний
					  for (int8_t i=16; i>0; i--){digitalWrite(id.sck,1); id.rawData = (id.rawData<< 1)| digitalRead(id.so); digitalWrite(id.sck,0);}
					  if(RT_HW_MAX6675_ENABLE_BLOCK_INTERRUPT) {interrupts();}                                
					   digitalWrite(id.cs,1);}	}
*/
//---------------------------3.ФУНКЦИИ ИНИЦИАЛИЗАЦИИ И НАСТРОЙКИ ШИН I2C-------------------------------------
//void    RT_HW_BASE:: sspiBegin(uint8_t sck, uint8_t miso, uint8_t mosi, uint8_t ss, uint8_t bus){//==Инициализация шины SPI;
//}       //++++++END spiBegin()
//uint8_t RT_HW_BASE:: spiSendByte (uint8_t val, uint8_t bus){								//==Отправка байта в SPI; 
//return 1;}	
//uint8_t RT_HW_BASE:: spiSendBytes(const uint8_t *arr,uint8_t qnt, uint8_t cs, uint8_t bus){	//==Отправка байтов в SPI;	 
//return 1;}	