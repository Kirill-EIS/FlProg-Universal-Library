#include "RT_HW_BASE.h"
//=================================================================================================
//							СЧЕТЧИКИ
//=================================================================================================
void 	RT_HW_BASE:: counterReset(RT_HW_COUNTER_ID &id){						//==Сброс счетчика"------------
id.begin=0; id.step=1; id.top=100; id.bottom=0; id.direct=0; id.cnt=id.begin; id.reset=0;}
void 	RT_HW_BASE:: counterS    (RT_HW_COUNTER_ID &id, bool EN) {				//==Счетчик "Пила"-------------
if(EN){ int32_t val=id.cnt;
if( id.step>=0){if(id.cnt==id.top)   {id.cnt=id.bottom; return;} val+=id.step; if(val>id.top)    {val=id.top;}     id.cnt=(int16_t)val; return;}
else           {if(id.cnt==id.bottom){id.cnt=id.top;    return;} val+=id.step; if(val<id.bottom) {val=id.bottom;}  id.cnt=(int16_t)val; return;}}};
void 	RT_HW_BASE:: counterT    (RT_HW_COUNTER_ID &id, bool EN) {				//==Счетчик "Треугольник"------
if(EN){ int32_t val=id.cnt;
if(id.step>=0){if(id.cnt==id.top){id.direct=1;} if(id.cnt==id.bottom) {id.direct=0;}
			   if(id.direct==0)  {val+=id.step; if(val>id.top)   {val=id.top;}    id.cnt=(int16_t)val; return;}
			   if(id.direct==1)  {val-=id.step; if(val<id.bottom){val=id.bottom;} id.cnt=(int16_t)val; return;}}
if( id.step<0){if(id.cnt==id.top){id.direct=0;} if(id.cnt==id.bottom) {id.direct=1;}
			   if(id.direct==0)  {val+=id.step; if(val<id.bottom)  {val=id.bottom;} id.cnt=(int16_t)val; return;}
			   if(id.direct==1)  {val-=id.step; if(val>id.top)     {val=id.top;}    id.cnt=(int16_t)val; return;}}}};	
void 	RT_HW_BASE:: counterL    (RT_HW_COUNTER_ID &id, bool EN) {				//==Счетчик "Предел"-----------
if(EN){ int32_t val=id.cnt;
if(id.step>=0) {if(id.cnt== 32767) {return;}  val=id.cnt; val+=id.step; if(val>= 32767) {val= 32767;} id.cnt=(int16_t)val; return;}
else           {if(id.cnt==-32768) {return;}  val=id.cnt; val+=id.step; if(val<=-32768) {val=-32768;} id.cnt=(int16_t)val; return;}}};
void 	RT_HW_BASE:: counterR    (RT_HW_COUNTER_ID &id, bool ENP, bool ENM){	//==Счетчик "Реверс+"----------
if(ENP){ int32_t val=id.cnt;
if(id.step>=0) {val+=id.step; if(val>id.top)    {val=id.top;}     id.cnt=(int16_t)val; return;}
else           {val+=id.step; if(val<id.bottom) {val=id.bottom;}  id.cnt=(int16_t)val; return;}};
if(ENM){ int32_t val=id.cnt;
if(id.step>=0) {val-=id.step; if(val<id.bottom) {val=id.bottom;}  id.cnt=(int16_t)val; return;}
else           {val-=id.step; if(val>id.top)    {val=id.top;}     id.cnt=(int16_t)val; return;}}};
// if((v>0) && (v<=8))  {dc=0; bitSet(dc,(v-1));} else dc=0;  //--8-разрядный дешифратор
//=================================================================================================
//							ГЕНЕРАТОРЫ
//=================================================================================================
bool 	RT_HW_BASE:: generatorChangeEN(uint8_t &ago, uint8_t EN, char mode){											//==Генератор событий по изменению EN [mode::F,C,B];
if(mode=='F') {if(ago!=EN) {ago=EN; if( EN) {return 1;}}}	//--Выделение заднего фронта;	
if(mode=='C') {if(ago!=EN) {ago=EN;          return 1;}}	//--Выделение изменения сигнала;	
if(mode=='B') {if(ago!=EN) {ago=EN; if(!EN) {return 1;}}}	//--Выделение переднего фронта;	
if(mode=='H') {ago=EN; 						 return ago;}
if(mode=='D') {ago=1; 						 return ago;}
if(mode=='N') {ago=0;						 return ago;}
return 0;};
bool    RT_HW_BASE:: generatorEvent(RT_HW_GENERATOR_EVENT_ID &id, uint8_t EN, uint16_t period){	 						//==Генератор событий (возвращает+id.event), меандров(id.meander);
id.event=0;
if(id.dir==0) {id.time=millis(); id.event=id.meander=1; id.dir++;}
if(id.dir==1) {if(EN) {id.dir++;} else {id.event=id.meander=0; id.time=millis();}}
if(id.dir==2) {if(periodMs(id.time,period)) {id.event=1; if(EN) {id.meander=!id.meander;} else {id.meander=0;} id.dir=1;}} 
return id.event;};    
bool    RT_HW_BASE:: generatorPulse(RT_HW_GENERATOR_PULSE_ID &id, uint8_t EN, uint16_t timeON, uint16_t timeOFF){		//==Генератор событий;
if(id.dir==0) {if(EN) {id.dir=3;} else {return 0;}}
if(id.dir==1) {if(millis()>=id.time) {id.time+=timeOFF; id.dir=2; return 0;} else {return 1;}}
if(id.dir==2) {if(millis()>=id.time) {id.dir=3;}}
if(id.dir>=3) {if(EN) {id.time=RT_HW_MILLIS+timeON; 		id.dir=1; return 1;}
			   else 								       {id.dir=0; return 0;}}		 return 0;};		
bool    RT_HW_BASE:: generatorPWM  (RT_HW_GENERATOR_PWM_ID   &id, uint8_t EN, uint16_t period, uint8_t wprc){ 			//==Генератор PWM;
if(id.dir==0) {if(!EN) {return 0;}  if(wprc==0) {return 0;} if(wprc>=100) {return 1;} 
            id.timeFULL=id.timeON=millis(); id.timeFULL+=period; id.timeON+=(period*wprc/100); id.dir++; return 1;}
if(id.dir==1) {if(millis()< id.timeON)   {return 1;}                                           id.dir++; return 0;}
if(id.dir>=2) {if(millis()>=id.timeFULL) {id.dir=0;}                                                     return 0;}
return 0;};
bool	RT_HW_BASE:: generatorFront(RT_HW_GENERATOR_FRONT_ID &id, uint8_t EN, char mode, uint8_t divide, uint8_t val){	//==Генератор передних фронтов [mode::F,C,B];
id.event=0;
if(EN){if(generatorChangeEN(id.ago, val,mode)) {
if(++id.cnt > divide) {id.cnt=1; id.event=1; if(id.meander) {id.meander=0;} else {id.meander=1;}}}}
				 else {id.event=id.meander=0;}
return id.event; 	
};
bool    RT_HW_BASE:: generatorGroup(RT_HW_GENERATOR_GROUP_ID &id, uint8_t EN, uint16_t period, uint8_t qnt, uint16_t periodFULL){	//==Генератор пачки или пачек(periodFLL>0) импульсов;
if(id.dir==0) {id.ago=0; id.dir++;}
if(id.dir==1) {id.meander=id.cnt=0;
			   if(periodFULL==0) {id.dir=2;} else   {id.time=RT_HW_MILLIS; id.dir=3;}}
if(id.dir==2) {if(generatorChangeEN(id.ago,EN,'F')) {id.time=RT_HW_MILLIS; id.dir=4;}} //--Обработка задержки
if(id.dir==3) {if(getPastMs(id.time)>periodFULL)    {id.dir=4;}} //     по времени при EN=1;
if(id.dir==4) {if(id.cnt>=qnt) {id.dir=1; id.meander=0;} else {id.dir++;}}
if(id.dir==5) {id.time=RT_HW_MILLIS; id.meander=1; id.dir++;}
if(id.dir==6) {if(getPastMs(id.time)>=period) {id.meander=0; id.time=RT_HW_MILLIS; id.dir++; }}
if(id.dir==7) {if(getPastMs(id.time)>=period) {++id.cnt; id.dir=4;}}
return id.meander;};
uint8_t RT_HW_BASE:: generatorTask (RT_HW_GENERATOR_TASK_ID  &id, uint8_t EN, uint16_t period, uint8_t qnt){ 			//==Генератор периодичеких задач; 
// id.event-номер задачи как событие, id.cnt-последний номер задачи; возвращает id.event;
if(EN){
if(periodMs(id.time,period)) {
if(++id.cnt > qnt) {id.cnt=1;} id.event=id.cnt; } else {id.event=0;};}
else {id.event=id.cnt=0;}
return id.event;}
uint8_t RT_HW_BASE:: generatorTask (uint8_t &cnt, uint8_t EN, uint8_t qnt){ 											//==Генератор номеров задач задач по входу EN; 
if(EN){if(++cnt > qnt) {cnt=1;} return cnt;} else {return 0;}}

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
