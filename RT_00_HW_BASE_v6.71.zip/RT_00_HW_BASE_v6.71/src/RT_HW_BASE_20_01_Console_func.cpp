#include "RT_HW_BASE.h"	
//=================================================================================================
//						БАЗОВЫЕ ФУНКЦИИ РАБОТЫ С КОНСОЛЬ
//=================================================================================================
void RT_HW_BASE::   consoleBegin(int8_t numUart, bool permit) {	//==Настройка консоли (numUart=номер UART, permit=Разрешение запуска). Выход: console.ok, console.head;
if(console.dir==3) {return;}									//--Пустой вход для консоли;
if(console.dir==0) {console.ok=console.head=0; if(!permit){return;}	//--Сброс state, ожидание внешнего сигнала запуска;	
  console.numUart=uint8_t(numUart);								//--Сохранение номера UART под консоль:
  if(!uartCheckNum(console.numUart)){console.dir=3; return;}; 	//--Выход, если недоступный номер UART;	
  if(console.speed==0){if(console.numUart==9){console.speed=RT_HW_UART_SPEED_SS;}	//--Установка
                                         else{console.speed=RT_HW_UART_SPEED_HS;}} //      скорости UART;
  uartBegin (console.numUart,console.speed);					//--Инициализация UART;							
  console.dir++; }												//--Переход на следующий этап;
if(console.dir==1) {if(!uartSerial(console.numUart)) {return;} 	//--Ожидание готовности консоли
					console.ok=console.head=1;					//--Установка состояния "Вывод заголовков";
					//consoleBlank(10); consoleCR();				//--Очистка экрана (код очистки Arduino IDE найти не удалось);	
					console.dir++; return;}  												
if(console.dir==2) {console.head=0; console.dir++;}};			//--Сброс флага "Вывод заголовка"; 
void RT_HW_BASE::   consoleWrite(uint8_t val){					//==Вывод байта;
	if(RT_HW_Base.console.ok){uartWrite(console.numUart,val);}};		
void RT_HW_BASE::   consolePrint(String  str){					//==Вывод строки;
	if(RT_HW_Base.console.ok){uartPrint(console.numUart,str);}};
void RT_HW_BASE::   consoleCR(){								//==Перевод строки;
	consoleWrite('\n');};
void RT_HW_BASE::   consoleLine (uint8_t n,char v){				//==Вывод линии c CR;
	for(int i=0; i<n; i++){consoleWrite(v);} consoleCR();};
void RT_HW_BASE::   consoleSuff (char suff){					//==Вывод суффикса [suff=G(пробел),L(=CR),E(';'+CR),S(=';'),V(=','),~(ничего),или любой другой символ];
if(suff=='~'){											return;} 
if(suff=='V')					{consoleWrite(',');  	return;} 
if(suff=='S')					{consoleWrite(';');  	return;} 
if(suff=='G')					{consoleWrite(' ');  	return;} 
if(suff=='L')					{consoleWrite('\n'); 	return;} 				
if(suff=='E'){consoleWrite(';'); consoleWrite('\n'); 	return;} 
consoleWrite(suff);};
void RT_HW_BASE::   consoleBlank(uint8_t n,char v,char suff){	//==Вывод заполнителей с суффиксом;
	if(v=='G') {v=' ';}	for(int i=0; i<n; i++){consoleWrite(v);} consoleSuff(suff);};	

//=================================================================================================
//						ФУНКЦИИ ДЛЯ УПРАВЛЕНИЯ ИЗ FLProg
//struct RT_HW_STRUCT_CONSOLE_OUT{uint32_t timeBegin; uint8_t dir=0; char mode='A'; uint8_t agoEN:1, block:1, first:1, period:1, change:1, permit:1, run:1;}; 
//id.mode::F-однократный вывод при EN=0->1; A-вывод в каждом цикле(EN=1), C-вывод по изменениям входных переменных;
//		   P-периодический вывод с периодом=period; T-периодический вывод с периодом=period, если есть изменения входных переменных;
//
//=================================================================================================
void RT_HW_BASE::   consoleCheckOut(RT_HW_STRUCT_CONSOLE_OUT &id, bool EN, uint16_t period){ //==Управления из FLprog[id.mode=F,A,P,C,T; 
if(id.dir==0) {id.agoEN=id.run=0; id.first=1; consoleBegin(); if(console.ok) {id.dir=1;} else {return;}}
if(!EN){id.dir=1;} 
if(id.dir==1) {id.change=0; 
			   if(id.agoEN!=EN) {id.agoEN=EN; if(EN) {id.first=1;}}
			   if(EN){
			   if( id.mode=='F') 					 {if(id.first) {id.dir=5;}}
			   if((id.mode=='A') ||	(id.mode=='C'))	    		   {id.dir=5;} //--Вывод в каждом цикле или по изменениям;
			   if((id.mode=='P') || (id.mode=='T'))  {if(id.first) {id.dir=5;}  else{id.timeBegin=millis(); id.dir=2;}} return;}}
if(id.dir==2) {if(periodMs(id.timeBegin, period)) {id.dir=5;} return;}			   
if(id.dir==5) {if((id.mode=='C') || (id.mode=='T')) 						{id.dir= 6;}  else {id.first=0; id.dir=10;  return;}}
if(id.dir==6) {if(id.change || id.first)             {id.change=id.first=0;  id.dir=10;}  else {id.dir=1;}              return;}
}
//=================================================================================================
//						БАЗОВЫЙ ВЫВОД НА КОНСОЛЬ ПЕРЕМЕННЫХ С СУФФИКСОМ
//=================================================================================================
void RT_HW_BASE:: consoleBool  (bool v,char sign0,char sign1,char suff){//==Вывод bool;
								if(v){consoleWrite(sign1);}	else{consoleWrite(sign0);} consoleSuff(suff);};
void RT_HW_BASE:: consoleChar  (char     v, char suff) {			//==Вывод символа;
	consoleWrite(v);    consoleSuff(suff);};			
void RT_HW_BASE:: consoleInt8  (int8_t   v, char suff) {			//==Вывод int8_t;
	consolePrint(String(v)); consoleSuff(suff);};
void RT_HW_BASE:: consoleInt16 (int16_t  v, char suff) {			//==Вывод int16_t;
	consolePrint(String(v)); consoleSuff(suff);};
void RT_HW_BASE:: consoleInt32 (int32_t  v, char suff) {			//==Вывод int32_t;
	consolePrint(String(v)); consoleSuff(suff);};
void RT_HW_BASE:: consoleUint8 (uint8_t  v, char suff) {			//==Вывод uint8_t;
	consolePrint(String(v)); consoleSuff(suff);};
void RT_HW_BASE:: consoleUint16(uint16_t v, char suff) {			//==Вывод uint16_;
	consolePrint(String(v)); consoleSuff(suff);};
void RT_HW_BASE:: consoleUint32(uint32_t v, char suff) {			//==Вывод uint32_t;
	consolePrint(String(v)); consoleSuff(suff);};	
void RT_HW_BASE:: consoleText  (String   v, char suff) {			//==Вывод String;
	consolePrint(v); 		 consoleSuff(suff);};
void RT_HW_BASE:: consoleFloat (float   v,char mode, char suff){	//==Вывод float;
if(mode=='0') {consolePrint(String(v,0));} 
if(mode=='1') {consolePrint(String(v,1));} 
if(mode=='2') {consolePrint(String(v,2));} 
if(mode=='3') {consolePrint(String(v,3));} 	
if(mode=='4') {consolePrint(String(v,4));} 
if(mode=='5') {consolePrint(String(v,5));} 
consoleSuff(suff);};
	
//=================================================================================================
//								ФОРМАТИРОВАННЫЙ ВЫВОД ПЕРЕМЕННЫХ
//=================================================================================================
bool RT_HW_BASE:: ConsoleBegin() {													//==Настройка консоли: init,если только console.ok=0; флаг console.head неизменный; Возвращает console.ok;
	if(!console.ok) {consoleBegin();} return console.ok;};
void RT_HW_BASE:: ConsoleLine    (uint8_t n,char v){								//==Вывод горизонтальной линии + CR;
consoleBegin();	
consoleLine(n,v);};
void RT_HW_BASE:: ConsoleBool    (char mode, uint8_t sz, char suff, bool    val){	//==Вывод bool [mode::'1'-'10'];
if(sz==0){sz=1;}
consoleBlank((sz-1),' '); consoleChar(getSignBool(mode, val)); consoleSuff(suff);};
void RT_HW_BASE:: ConsoleChar    (char mode, uint8_t sz, char suff, char    val){	//==Вывод char [mode::O,F];
if(mode=='O') {consoleChar(val,suff);}
if(mode=='F') {if(sz==0){sz=1;} consoleBlank((sz-1),' '); consoleChar(val,suff); return;}};
void RT_HW_BASE:: ConsoleV8      (char mode, uint8_t sz, char suff, uint8_t val){	//==Вывод v8   [mode::O,I,U,H,B,*,T,D,C];
String str; uint8_t len;
if(mode=='O') {									//--Нeформатированный вывод int8_t;	
 consolePrint(String((int8_t)val));} 
if(mode=='I') {									//--Вывод в int8_t последних (до sz значащих знаков) цифр с добавлением пробелов до длины sz;
 if(sz==0){sz=4;} if(sz>5){sz=5;} int8_t vI=(int8_t)val; str=String(vI); 
 len=str.length(); if(len>sz){str=str.substring(len-sz,len); len=sz;} consoleBlank((sz-len),' '); consolePrint(str);} 
if(mode=='U') {									//--Вывод в uint8_t последних (до sz значащих знаков) цифр с добавлением пробелов до длины sz;
 if(sz==0){sz=3;} if(sz>5){sz=5;} str=String(val); 
	len=str.length(); if(len>sz){str=str.substring(len-sz,len); len=sz;} consoleBlank((sz-len),' '); consolePrint(str);} 
if(mode=='H') {									//--Вывод в HEX последних (до sz значащих знаков) цифр с добавлением '0' до длины sz;
 if(sz<4){sz=4;}; str=String('0')+String('x'); if(val<= 0xF) {str+=String('0');}
 str+=String(val,HEX); consoleBlank((sz-4),' '); consolePrint(str);} 	
if(mode=='B') {									//--Вывод в BIN последних (до sz значащих знаков) с добавлением '0' впереди до 8-ми знаков, далее с добавлением пробелов;
 if(sz<9){sz=9;}  consoleBlank((sz-9),' '); 
 for(uint8_t i=0; i<8; i++) {consoleBool(bitRead(val,7-i),'0','1'); if(i==3) {consoleChar(' ');}}}		
if(mode=='*') {									//--Аналогично как 'B'->вместо '0' выводится '-', вместо '1' выводится '+'; 
 if(sz<9){sz=9;} consoleBlank((sz-9),' ');
 for(uint8_t i=0; i<8; i++) {consoleBool(bitRead(val,i),'-','+'); if(i==3) {consoleChar(' ');}}}				
if(mode=='T') {									//--Вывод в формате времени последних (до sz значащих знаков) с добавлением ' ' до длины sz;
  if(sz<2) {sz=2;} if(val>99) {val=99;} 
  if(val<10) {str=String('0')+String((uint8_t)val);} else {str=String((uint8_t)val);} consoleBlank((sz-2),' ');  consolePrint(str);}	
if(mode=='D') {									//--Вывод с добавление впереди пробела до 2-х знаков;
 if(val<10){consoleChar(' ');} consolePrint(String((int8_t)val));}				
if(mode=='C') {									//--Вывод одного символа;
if(sz<1) {sz=1;} consoleBlank((sz-1),' '); consoleChar(char(val));;} 		
consoleSuff(suff);};							//--Вывод суффикса;	
void RT_HW_BASE:: ConsoleV16     (char mode, uint8_t sz, char suff, int16_t val){	//==Вывод v16  [mode::O,I,U,H,B,0,1,2,3,4];
uint8_t len; String str;	
//------Простой вывод числа------------------------------------------------------------------------
if(mode=='O') {consolePrint(String(val));}
//------Вывод в INT-формате последних (до sz значащих знаков) с добавлением ' ' до длины sz-------
if(mode=='I') {	if(sz==0){sz=6;} 			str=String(val); 
				len=str.length(); if(len>sz){str=str.substring(len-sz,len); len=sz;}	                      
				consoleBlank((sz-len),' '); consolePrint(str);} 
 //------Вывод в UINT-формате последних (до sz значащих знаков) с добавлением ' ' до длины sz-------
if(mode=='U') {	if(sz==0){sz=5;} 			str=String((uint16_t)val); 
				len=str.length(); if(len>sz){str=str.substring(len-sz,len); len=sz;}	                      
				consoleBlank((sz-len),' '); consolePrint(str);} 
 //------Вывод в HEX-формате последних (до sz значащих знаков) с добавлением '0' до длины sz-------
if(mode=='H') {	if(sz<6){sz=6;}  uint16_t vH=(uint32_t)val&0xFFFF;
				str=String('0')+String('x');
				len=4-String(vH,HEX).length();
				for(uint8_t i=0; i<len;i++){str+=String('0');}
				str+=String(vH,HEX);
				consoleBlank((sz-6),' '); consolePrint(str);} 			
//------Вывод в BIN-формате. Вывод 16-ти младших битов----------------------------------------------
if(mode=='B') {	if(sz<17){sz=17;}  uint16_t vB=(uint32_t)val&0xFFFF;
				str=String('B');
				len=16-String(vB,BIN).length();
				for(uint8_t i=0; i<len;i++){str+=String('0');}
				str+=String(vB,BIN);
				consoleBlank((sz-17),' '); consolePrint(str);} 			
//------Вывод в формате с точкой-------------------------------------------------------------------
if((mode=='0') || (mode=='1') || (mode=='2') || (mode=='3') || (mode=='4')){float vF=(float)val;
				if(sz<3){sz=7;} 
				if(mode=='0') {str=String(vF,1);} 
				if(mode=='1') {str=String(vF/10,1);} 									
				if(mode=='2') {str=String(vF/100,2);}
				if(mode=='3') {str=String(vF/1000,3);} 									
				if(mode=='4') {str=String(vF/10000,4);}
				len=str.length(); if(len>sz){str=str.substring(len-sz,len); len=sz;}	                     
				consoleBlank((sz-len),' ');  consolePrint(str);}				
//-------Завершение вывода-------------------------------------------------------------------------
consoleSuff(suff);};
void RT_HW_BASE:: ConsoleV32     (char mode, uint8_t sz, char suff, int32_t val){	//==Вывод v32  [mode::O,I,U,H,0,1,2,3,4];
uint8_t len; String str;	
if(mode=='O') {									//--Нeформатированный вывод int32_t;
	consolePrint(String(val));}
if(mode=='I') {									//--Вывод в int32_t  последних (до sz значащих знаков) цифр с добавлением пробелов до длины sz;
	if(sz==0){sz=9;} str=String(val); 
	len=str.length(); if(len>sz){str=str.substring(len-sz,len); len=sz;}	                      
	consoleBlank((sz-len),' '); consolePrint(str);} 
if(mode=='U') {									//--Вывод в uint32_t последних (до sz значащих знаков) цифр с добавлением пробелов до длины sz;
	if(sz==0){sz=8;} str=String((uint32_t)val); 
	len=str.length(); if(len>sz){str=str.substring(len-sz,len); len=sz;}	                      
	consoleBlank((sz-len),' '); consolePrint(str);} 
if(mode=='H') {									//--Вывод в HEX последних (до sz значащих знаков) цифр с добавлением '0' до длины sz;
	if(sz<8){sz=10;}  uint32_t vH=(uint32_t)val;
	str=String('0')+String('x');
	len=8-String(vH,HEX).length();
	for(uint8_t i=0; i<len;i++){str+=String('0');}
	str+=String(vH,HEX);
	consoleBlank((sz-10),' '); consolePrint(str);} 					
if((mode=='0') || (mode=='1') || (mode=='2') || (mode=='3') || (mode=='4')){	//--Вывод в формате с точкой;
	float vF=(float)val; 
	if(sz<3){sz=10;} 
	if(mode=='0') {str=String(vF,1);} 
	if(mode=='1') {str=String(vF/10,1);} 									
	if(mode=='2') {str=String(vF/100,2);}
	if(mode=='3') {str=String(vF/1000,3);} 									
	if(mode=='4') {str=String(vF/10000,4);}
	len=str.length(); if(len>sz){str=str.substring(len-sz,len); len=sz;}	                     
	consoleBlank((sz-len),' ');  consolePrint(str);}								
consoleSuff(suff);};							//--Вывод суффикса;	
void RT_HW_BASE:: ConsoleFloat   (char mode, uint8_t sz, char suff, float   val){	//==Вывод float[mode::O,0,1,2,3,4]; 
//--Вывод float. Форматы(char)->,O,0,1,2,3,4; 
uint8_t len; String str;
if(mode=='O') {consoleFloat(val, '2');}
if((mode=='0') || (mode=='1') || (mode=='2') || (mode=='3') || (mode=='4') || (mode=='5')){
	if(mode=='0') {str=String(val,0); if(sz==0){sz= 5;}} 	
	if(mode=='1') {str=String(val,1); if(sz==0){sz= 7;}} 									
	if(mode=='2') {str=String(val,2); if(sz==0){sz= 8;}}
	if(mode=='3') {str=String(val,3); if(sz==0){sz= 9;}} 									
	if(mode=='4') {str=String(val,4); if(sz==0){sz=10;}}
	if(mode=='5') {str=String(val,5); if(sz==0){sz=11;}}
	}
	else	{str=String(val,2);}
len=str.length(); if(len>sz){str=str.substring(len-sz,len); len=sz;}	                     
consoleBlank((sz-len),' ');  consolePrint(str);					
//-------Завершение вывода-------------------------------------------------------------------------
consoleSuff(suff);};		//--Форматированный вывод суффикса;
void RT_HW_BASE:: ConsoleString  (char mode, uint8_t sz, char suff, String text, char blank){   //==Вывод текста [mode::L,C,R,N] с блокирующим символом; Допускается формат String(F("Text"));
if(sz==0) {sz=160; mode='N';} //--Вывод как есть без форматирования;
uint8_t lenText=0; uint8_t lenBuff=0; char buff;                 
const char * data=text.c_str();	
for(uint8_t i=0; i<=160; i++){	//--Получение длины текста lenText и буфера lenBuff String (utf-8, блокирующий символ RT_HW_BREAK_CHAR='~');
	buff=data[i]; lenBuff=i; 
	if((buff=='\0') || (buff==RT_HW_BREAK_CHAR) || (lenText>=sz)) {break;}
	if(((uint8_t)buff)<0xC0) {lenText++;}};
consoleBlank(getLenBegin(sz,lenText,mode),blank);							//--Вывод заполнителей спереди;
for(uint8_t i=0; i<lenBuff; i++){consoleWrite(data[i]);}			//--Вывод текста длиной lenBuff;
consoleBlank(getLenEnd(sz,lenText,mode),blank);							//--Вывод заполнителей сзади; 
consoleSuff(suff);};
void RT_HW_BASE:: ConsoleText    (char mode, uint8_t sz, char suff, char blank, String text){ //==Вывод текста [mode::L,C,R,N] с блокирующим символом; Допускается формат String(F("Text"));
if(sz==0) {sz=160; mode='N';} //--Вывод как есть без форматирования;
uint8_t lenText=0; uint8_t lenBuff=0; char buff;                 
const char * data=text.c_str();	
for(uint8_t i=0; i<=160; i++){	//--Получение длины текста lenText и буфера lenBuff String (utf-8, блокирующий символ RT_HW_BREAK_CHAR='~');
	buff=data[i]; lenBuff=i; 
	if((buff=='\0') || (buff==RT_HW_BREAK_CHAR) || (lenText>=sz)) {break;}
	if(((uint8_t)buff)<0xC0) {lenText++;}};
consoleBlank(getLenBegin(sz,lenText,mode),blank);						//--Вывод заполнителей спереди;
for(uint8_t i=0; i<lenBuff; i++){consoleWrite(data[i]);}				//--Вывод текста длиной lenBuff;
consoleBlank(getLenEnd(sz,lenText,mode),blank);							//--Вывод заполнителей сзади; 
consoleSuff(suff);};
void RT_HW_BASE:: ConsoleTextPGM (char mode, uint8_t sz, char suff, char blank, const char *textPGM){ //==Вывод текста [mode::L,C,R,N] с блок.символом;Допускается формат String(F("Text"));
uint8_t lenText=0; uint8_t lenBuff=0; char buff; 
for(uint8_t i=0; i<=160; i++){	//--Получение длины текста lenText и буфера lenBuff String (utf-8, блокирующий символ RT_HW_BREAK_CHAR='~');
	buff=pgm_read_byte(textPGM+i); lenBuff=i;
    if((buff=='\0') || (buff==RT_HW_BREAK_CHAR) || (lenText>=sz)) {break;}
	if(((uint8_t)buff)<0xC0) {lenText++;}};
consoleBlank(getLenBegin(sz,lenText,mode),blank);									//--Вывод заполнителей спереди;
for(uint8_t i=0; i<lenBuff; i++){buff=pgm_read_byte(textPGM+i); consoleWrite(buff);}//--Вывод текста длиной lenBuff;
consoleBlank(getLenEnd(sz,lenText,mode),blank);										//--Вывод заполнителей сзади; 
consoleSuff(suff);};																//--Вывод суффикса;
void RT_HW_BASE:: ConsolePin     (char mode, uint8_t sz, char suff, uint8_t val){	//==Вывод пина mode::T,A;
String str;
if(sz<RT_HW_PIN_TXT_LEN) {sz=RT_HW_PIN_TXT_LEN;} 
#if defined(RT_HW_CORE_M_STM32F1) || defined(RT_HW_CORE_M_STM32F4) || defined(RT_HW_CORE_D_STM32)	
if(mode=='T') {              ConsoleString('L',4,'~',getNamePin(val));}
if(mode=='D') {if(val<254)  {ConsoleV8('U',3,'~',val);}           else {ConsoleString('C',3,'~',String(F("*")));} }
if(mode=='A') {if(val<254)  {ConsoleString('L',4,'[',getNamePin(val)); ConsoleV8('U',3,']',val);}
			   else         {ConsoleString('C',9,'~',String(F(" ** [ * ]")));}}
#elif defined(RT_HW_CORE_ESP8266)
if(mode=='T') {              ConsoleString('L',2,'~',getNamePin(val));}
if(mode=='D') {if(val==255) {ConsoleString('C',2,'~',String(F("*")));}  else {ConsoleV8('U',2,'~',val);}}
if(mode=='A') {ConsoleString('L',4,'[',getNamePin(val)); 
			   if(val==255) {ConsoleString('C',2,'~',String(F("*")));}  else {ConsoleV8('U',2,']',val);}}
#else
if((mode=='T')||(mode=='D')||(mode=='A')) { 
			   if(val==255) {ConsoleString('C',2,'~',String(F("*")));}  else {ConsoleV8('U',2,'~',val);}}

//ConsoleString('L',sz,'~',val);}              
#endif		  
consoleSuff(suff);};							//--Вывод суффикса;	
void RT_HW_BASE:: ConsoleAdrI2C  (char mode, uint8_t sz, char suff, uint8_t val){				//==Вывод адреса i2c mode::H,D,A;
int8_t vAdr=(int8_t)val; if(vAdr<0) {vAdr=-1;}
if(mode=='D') {ConsoleV8('D',0,'~',vAdr);}
if(mode=='H') {if(vAdr<0){consoleText(String(F("####")));}    else {ConsoleV8('H',0,'~',vAdr);}}
if(mode=='A') {if(vAdr<0){consoleText(String(F("####/-1")));} else {ConsoleV8('O',0,'/',vAdr); ConsoleV8('H',0,'~',vAdr);}}
consoleSuff(suff);};
//=================================================================================================
//								ФОРМАТИРОВАННЫЙ ВЫВОД МАССИВОВ
//=================================================================================================
void  RT_HW_BASE:: ConsoleArrBool    (char mode, uint8_t sz, char suff, uint8_t qnt, uint16_t val){	//==Вывод v8   [mode::O,I,U,H,B,*,T,D,C];
uint8_t m; uint8_t k=qnt; if(k==0) {k=1;} if(k>10) {k=10;}  m=k;
char sign0='0'; char sign1='1'; 
if(mode=='A') {sign0='-'; sign1='+'; }
if(mode=='B') {sign0='_'; sign1='+'; }
if(mode=='C') {sign0='_'; sign1='*'; }
if(mode=='D') {sign0='_'; sign1='#'; }
if(sz==0){sz=1;}
for(uint8_t i=k; i>0; i--) {consoleBlank((sz-1),' '); consoleBool(bitRead(val,i-1),sign0,sign1);
							m--; if((m==8) || (m==4)) {consoleChar(' ');};}			
consoleSuff(suff);};
void  RT_HW_BASE:: ConsoleArrV8      (char mode, uint8_t sz, char suff, uint8_t qnt, uint8_t *arr){	//--Вывод qnt элементов массива arr(uint8_t);
 for(uint8_t i=0; i<qnt; i++){if(i>0){consoleChar(',');} ConsoleV8   (mode,sz,'~',arr[i]);} consoleSuff(suff);};
void  RT_HW_BASE:: ConsoleArrV16     (char mode, uint8_t sz, char suff, uint8_t qnt, int16_t *arr){	//--Вывод qnt элементов массива arr(uint8_t);
 for(uint8_t i=0; i<qnt; i++){if(i>0){consoleChar(',');} ConsoleV16   (mode,sz,'~',arr[i]);} consoleSuff(suff);};
void  RT_HW_BASE:: ConsoleArrV32     (char mode, uint8_t sz, char suff, uint8_t qnt, int32_t *arr){	//--Вывод qnt элементов массива arr(uint8_t);
 for(uint8_t i=0; i<qnt; i++){if(i>0){consoleChar(',');} ConsoleV32   (mode,sz,'~',arr[i]);} consoleSuff(suff);};
void  RT_HW_BASE:: ConsoleArrFloat   (char mode, uint8_t sz, char suff, uint8_t qnt, float   *arr){	//--Вывод qnt элементов массива arr(uint8_t);
 for(uint8_t i=0; i<qnt; i++){if(i>0){consoleChar(',');} ConsoleFloat (mode,sz,'~',arr[i]);} consoleSuff(suff);};
void  RT_HW_BASE:: ConsoleArrString  (char mode, uint8_t sz, char suff, uint8_t qnt, String  *arr){	//--Вывод qnt элементов массива arr(uint8_t);
 for(uint8_t i=0; i<qnt; i++){if(i>0){consoleChar(',');} ConsoleString (mode,sz,'~',arr[i]);} consoleSuff(suff);};
void  RT_HW_BASE:: ConsoleArrChar    (char mode, uint8_t sz, char suff, uint8_t qnt, char    *arr){	//--Вывод qnt элементов массива arr(uint8_t);
 for(uint8_t i=0; i<qnt; i++){if(i>0){consoleChar(',');} ConsoleChar  (mode,sz,'~',arr[i]);} consoleSuff(suff);};
void  RT_HW_BASE:: ConsoleArrPin     (char mode, uint8_t sz, char suff, uint8_t qnt, uint8_t *arr){	//--Вывод qnt элементов массива arr(uint8_t);
 for(uint8_t i=0; i<qnt; i++){if(i>0){consoleChar(',');} ConsolePin(mode,sz,'~',arr[i]);} consoleSuff(suff);};
void  RT_HW_BASE:: ConsoleArrAdrI2C  (char mode, uint8_t sz, char suff, uint8_t qnt, uint8_t *arr){	//--Вывод qnt элементов массива arr(uint8_t);
 for(uint8_t i=0; i<qnt; i++){if(i>0){consoleChar(',');} ConsoleAdrI2C   (mode,sz,'~',arr[i]);} consoleSuff(suff);};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
