#include "RT_HW_HTU21.h"
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
//							Настройка (корректировка) ID
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void	RT_HW_HTU21:: setID    (RT_HW_STRUCT_HTU21 &id, uint8_t bus){	//====Настройка параметров---------------
if(id.custom!=0){return;}					//--Выход, если устройство не настроено;
//------------------------------------------
id.adr=0x40;								//--Установка: i2c->адрес; 
id.bus=bus;									//--Установка номера шины i2c;	
setVal(id);									//--Инициализация начальных значений;
//------------------------------------------
RT_HW_Base.i2cBegin(255,255,0,id.bus);		//--Настройка шины i2c как Master(если не настроена) с параметрами default;
if(!RT_HW_Base.i2cCheckBusState(RT_HW_I2C_STATE_MASTER,id.bus)) {id.custom=90; return ;} //--Выход, если шина не Master;
//------------------------------------------
id.tmp.period=id.hum.period=1000;			//--Начальная установка периода    опроса    температуры,влажности;
id.tmp.permit=id.hum.permit=1;;				//--Начальная установка разрешение измерения температуры,влажности;
//------------------------------------------
id.custom=1;								//--Успешный выход;
};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							Управление устройством
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void    RT_HW_HTU21:: direct   (RT_HW_STRUCT_HTU21 &id, bool eN, bool reset){		//====Управление устройством-------------
if(eN) {id.eN=1;}
if(id.dir== 0) {						//==Стартовая идентификация устройства;
	if(id.custom!=1) {return;} 						//--Ожидание настройки ID;
	if(!id.eN)       {return;}						//--Ожидание разрешения работы;
	setVal(id);										//--Установка параметров;
	id.cntErr=0;									//--Сброс счетчика ошибок;
	id.tmp.run=id.tmp.permit;						//--Настройка запуска по температуре;
	id.hum.run=id.hum.permit;						//--Настройка запуска влажности;	
	id.timePeriod=millis();							//--Настройка таймера;
	id.dir++;}
if(id.dir== 1) {						//==Задержка для нормлизации питания ;
	if(RT_HW_Base.getPastMs(id.timePeriod)<50){return;}	//--Задержка 50 мс;
	id.bu16=0; id.dir++;}								//--Очистка параметра для функции i2cFindArr() и переход на следующий этап;
if(id.dir== 2) {						//==Для i2c поиск устройства на шине;
	if(!RT_HW_Base.i2cFindAdr(id.timePeriod,id.bu16,id.adr,id.bus,3,10,2000)){return;} //--Поиск устройства на шине i2c;
	id.dir++;}										//--Переход на основной цикл;
if(id.dir== 3) {						//==Программный сброс;
    init(id); 
	//--Программный сброс;
	if(id.codeErr!=0) {id.dir=90; return;}			//--Переход на продолжении или на обработку сбоя;
	id.tmp.timePeriod=id.hum.timePeriod=millis();	//--Инициализация таймеров периодов;
	id.dir=10;}										//--Переход на основной цикл измерения;
if(id.dir==10) {						//==Проверка для перехода к измерению;
	if(!id.eN){return;} id.eN=0; 					//--Ожидание разрешения работы по событию;	
    if(id.reset!=reset){if(!id.reset){id.reset=reset; id.dir=0; return;}}//--Сброс по сигналу сброс
	if(id.tmp.permit){if(RT_HW_Base.periodMs(id.tmp.timePeriod,id.tmp.period)) {id.tmp.run=1;}} //--Установка разрешения по периоду T;
	if(id.hum.permit){if(RT_HW_Base.periodMs(id.hum.timePeriod,id.hum.period)) {id.hum.run=1;}} //--Установка разрешения по периоду H;	
	if(id.tmp.run || id.hum.run) {id.dir=20;} return;}	//--Проверка готовности одного из устройства;
if(id.dir==20) {						//==Проверка  на переход к измерению по температуре;	
	if(id.tmp.run) {id.tmp.run=0; id.step=0; id.dir++;} else {id.dir=30;}}	//--Проверка на измерение температуры;
if(id.dir==21) {						//==Измерение по температуре;
	if(!readTmp(id)) 			{return;}				//--Ожидание завершения измерения температуры;
	if(id.codeErr)  {id.dir=90;  return;}
					 id.dir=30;  return;}
if(id.dir==30) {						//==Проверка  на переход к измерению по влажности;	
	if(id.hum.run) {id.hum.run=0; id.step=0; id.dir++;} else {id.dir=80;}}	//--Проверка на измерение влажности;
if(id.dir==31) {						//==Измерение по влажности;
	if(!readHum(id)) {return;}						//--Ожидание завершения измерения температуры;
	if(id.codeErr)  {id.dir=90;  return;}	
	id.dir=80;}										//--Переход на 
if(id.dir==80) {						//==Завершение цикла измерения;
	id.ok=1; id.dir=10;}							//--Переход на повторный цикл измерения:
if(id.dir==90) {						//==Обработка ошибок;
	if(++id.cntErr>3) {setVal(id); id.dir=0; return;}	
	id.timePeriod=millis(); id.dir++; return;}		//--Настройка таймера;	
if(id.dir==91) {						//==Задержка для перед перезапуском;
	if(RT_HW_Base.getPastMs(id.timePeriod)<1000){return;}	//--Задержка 1000 мс;	
	id.dir=3;}
	
};	
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							Инициализация (программный сброс)
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void RT_HW_HTU21:: setVal(RT_HW_STRUCT_HTU21 &id){					
	id.tmp.var  =-0.1;				//--Установка default температуры;
	id.hum.var  = 0.2;				//--Установка default влажности;
	id.tmp.fresh=id.hum.fresh=1;	//--Настройка параметров влажности;	
    id.ok=0;						//--Настройка ok;
}	
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							Инициализация (программный сброс)
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void RT_HW_HTU21:: init(RT_HW_STRUCT_HTU21 &id){					
	id.codeErr=RT_HW_Base.i2cSendByte(RT_HW_HTU21_SOFT_RESET,id.adr,id.bus);}	
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							Чтение температуры
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
bool RT_HW_HTU21:: readTmp  (RT_HW_STRUCT_HTU21 &id){
if(id.step==0){							//==Запрос на чтение регистров с температурой;
	id.codeErr=RT_HW_Base.i2cSendByte(RT_HW_HTU21_TRIG_TMP_NOHOLD,id.adr,id.bus);//--Отправка команды;
	if(id.codeErr!=0)	{return 1;} //--Выход по ошибке i2c;	 
	id.timePeriod=millis();	id.step++;}	//--Настройка таймера;	 
if(id.step==1){							//==Пауза для преобразования в сенсоре;
	if(RT_HW_Base.getPastMs(id.timePeriod) < RT_HW_HTU21_TIME_METER_TMP) {return 0;} id.step++;}				 
if(id.step==2){							//===Чтение данных;
	id.codeErr=RT_HW_Base.i2cGetBytes(3,id.adr,id.bus);//--Чтение 3 байт из i2c;
	if(id.codeErr) {return 1;}; 	
	uint8_t msb=RT_HW_Base.i2cReadBuff(id.bus); 
	uint8_t lsb=RT_HW_Base.i2cReadBuff(id.bus);  
	uint8_t crc=RT_HW_Base.i2cReadBuff(id.bus);
	uint16_t rawTmp = ((uint16_t)msb << 8) | (uint16_t)lsb;	
	if(check_crc(rawTmp,crc)!=0){id.codeErr=10; return 1;}  	//--Завершение по ошибке CRC;
	rawTmp &=0xFFFC; 
	float valTmp=rawTmp/(float)65536; 	
	id.tmp.var= -46.85 + (175.72 * valTmp); 
	id.tmp.ok=id.tmp.fresh=1; id.step=0; return 1;}
return 1;};			
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							Чтение влажности
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
bool RT_HW_HTU21:: readHum  (RT_HW_STRUCT_HTU21 &id){
if(id.step==0){							//==Запрос на чтение регистров с влажностью;
	id.codeErr=RT_HW_Base.i2cSendByte(RT_HW_HTU21_TRIG_HUM_NOHOLD,id.adr,id.bus);//--Отправка команды;
	if(id.codeErr)	{return 1;} 					//--Выход при ошибке i2c;	 
	id.timePeriod=millis(); id.step++;}				//--Настройка таймера;	 						 
if(id.step==1){							//==Пауза для преобразования в сенсоре;
	if(RT_HW_Base.getPastMs(id.timePeriod)<RT_HW_HTU21_TIME_METER_HUM) {return 0;} id.step++;}			 
if(id.step==2){							//==Чтение данных;
	id.codeErr=RT_HW_Base.i2cGetBytes(3,id.adr,id.bus);	//--Чтение 3 байт из i2c в буфер i2c;
	if(id.codeErr) {return 1;}; 						//-
	uint8_t msb=RT_HW_Base.i2cReadBuff(id.bus); 
	uint8_t lsb=RT_HW_Base.i2cReadBuff(id.bus);  
	uint8_t crc=RT_HW_Base.i2cReadBuff(id.bus);
	uint16_t rawHum = ((uint16_t)msb << 8) | (uint16_t)lsb;
	if(check_crc(rawHum,crc)!=0){id.codeErr=11; return 1;}  //--Завершение по ошибке CRC;	
	rawHum &= 0xFFFC;  
	id.hum.var=rawHum;
	float valHum=rawHum/(float)65536; 
	id.hum.var= -6 + (125 * valHum); 
	id.hum.ok=id.hum.fresh=1;	id.step=0; return 1;}
return 1;};	
	
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							Проверка CRC
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
uint8_t RT_HW_HTU21:: check_crc(uint16_t message_from_sensor, uint8_t check_value_from_sensor){	//====Вычисление контрольной суммы;
uint32_t divisor   = (uint32_t)RT_HW_HTU21_SHIFTED_DIVISOR;	//--Запоминаем 3-х байтовый полином;
uint32_t remainder = (uint32_t)message_from_sensor << 8;	//--Сдвиг измеренного значения на один байт влево (для работы с 3-байтовым полиномом); 
         remainder|= check_value_from_sensor; 				//--Добавление в младший байт crc из сенсора;
for (uint8_t i=0;i<16;i++){if(remainder & (uint32_t)1<<(23-i)) remainder^= divisor; divisor>>=1;} //--Расчет остатка после проверки crc;
return (uint8_t)remainder;
return 0;
}	
//=================================================================================================	
RT_HW_HTU21 RT_HW_htu21; //--Создание объекта 

