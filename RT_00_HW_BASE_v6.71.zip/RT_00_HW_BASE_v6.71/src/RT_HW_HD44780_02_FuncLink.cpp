#include "RT_HW_HD44780.h"
//-------1.1. Перечисления кодов используемых в функциях-------------------------------------------
//enum {FL_EN=B00000100, BACKLIGHT_ON=0x08, BACKLIGHT_OFF=0x00, SET_CGRAM_ADDR=0x40, SET_DDRAM_ADDR=0x80};	
//-------1.2. Вспомогательные функции--------------------------------------------------------------
uint8_t  RT_HW_HD44780:: timeToTick   (uint16_t time,uint8_t TICK){								//==Конвертация времени в тики(max=255);	
if(TICK*255 >=time) {return time/TICK;}	else {return 255;}};
uint8_t  RT_HW_HD44780:: pointCursor  (uint8_t col,  uint8_t row, uint8_t chip) {				//==Возвращает адрес позиции по номеру колонки и номера строки;
row=constrain(row,1,RT_HW_HD44780_MAX_ROWS)-1;
col=constrain(col,1,RT_HW_HD44780_MAX_COLS)-1;
if(chip==2){uint8_t row_offsets[] = { 0x00, 0x40, 0x00, 0x40 }; return (0x80 | (col + row_offsets[row]));} 
else   	   {uint8_t row_offsets[] = { 0x00, 0x40, 0x14, 0x54 }; return (0x80 | (col + row_offsets[row]));} 
} 
uint8_t  RT_HW_HD44780:: getLenBegin  (uint8_t len,  uint8_t src,char alig){					//==Возвращает кол-во свободных знаков  в начале поля;
if(len<=src){return 0;} if(alig=='C') {return (len-src-(len-src)/2);} if(alig=='R') {return (len-src);} return 0;}
uint8_t  RT_HW_HD44780:: getLenEnd    (uint8_t len,  uint8_t src,char alig){					//==Возвращает кол-во свободных знаков  в конце поля;
if(len<=src){return 0;} if(alig=='C') {return (len-(len-src-(len-src)/2)-src);} if(alig=='L') {return (len-src);} return 0;} 	
int32_t  RT_HW_HD44780:: floatToInt32 (float val,    uint8_t point){ 							//==Конвертор float в int32_t с умножением на кол-во знаков после точек;
   for(uint8_t i=1; i< (point+1); i++){val=val*10;}; return round(val);};
uint8_t  RT_HW_HD44780:: getLenSTR    (String &str,  uint8_t lenMax){ 							//==Возвращает len String(utf-8) с учетом блокирующего символа '~');
uint8_t buff,j,LEN; if(lenMax==0) {lenMax=40;} j=LEN=0;
while (1) {buff=str[j];	         if(buff>=0xC0) {j++; buff=str[j];}  j++;	
if((buff==0) || (buff==RT_HW_HD44780_BREAK_CHAR) || (LEN>lenMax) || (j>160)) {break;} LEN++;} return LEN;}
uint8_t  RT_HW_HD44780:: getCharLcdSTR(String &str,      uint8_t &num)  {						//==Возвращает следующий код(utf-8) из String;
uint8_t buff1,buff2; 
buff2=0; buff1=str[num]; num++; if(buff1>=0xC0) {buff2=str[num];  num++; return getCodeCharLcdPGM(convert(buff1,buff2));} else {return buff1;}}
uint8_t  RT_HW_HD44780:: getLenPGM    (const char *text, uint8_t lenMax){						//==Возвращает len textPGM(utf-8) с учетом блокирующего символа '~');
	uint8_t buff,j,LEN; if(lenMax==0) {lenMax=40;} j=LEN=0;
while (1) {buff=pgm_read_byte(text+j);	j++;
		   if((buff==0) || (buff==RT_HW_HD44780_BREAK_CHAR) || (LEN>lenMax) || (j>160)) {break;}
		   if(buff>=0xC0) {j++; buff=pgm_read_byte(text+j);} LEN++;} return LEN;}
uint8_t  RT_HW_HD44780:: getCharLcdPGM(const char *text, uint8_t &num)  {						//==Возвращает следующий код(utf-8) из PGM;
uint8_t buff1,buff2; 
buff2=0; buff1=pgm_read_byte(text+num); num++; if(buff1>=0xC0) {buff2=pgm_read_byte(text+num); num++; return getCodeCharLcdPGM(convert(buff1,buff2));} else {return buff1;}}
uint8_t  RT_HW_HD44780:: getCodeCharLcdPGM(uint8_t code){										//==Возвращает код символа (из таблицы(PGM) перекодировки LCD);
	return pgm_read_byte(RT_HW_HD44780_CONVERT_RUS+code);};
uint8_t  RT_HW_HD44780:: convert(uint8_t charH, uint8_t charL){									//==Получение номера символа из utf-8;
if(charH==0xD0) {if (charL==0x81) {return 0x40;}  if((charL>=0x90) && (charL<=0xBF)){return (charL-0x90);}};
if(charH==0xD1) {if (charL==0x91) {return 0x41;}  if((charL>=0x80) && (charL<=0x8F)){return (charL-0x50);}}; return charL;}; 
uint8_t  RT_HW_HD44780:: getPointFromChar(char val){											//==Получение цифрового значения кол-ва знаков после точки;
	if(val=='1'){return 1;}	if(val=='2') {return 2;}	if(val=='3'){return 3;}	return 0;}
uint16_t RT_HW_HD44780:: CRC16_String(String &s){												//==Вычисление CRC16 переменной String (1 символ-12 мкс AVR328);
	uint8_t index; uint16_t buff16;
index=s.length();	buff16=0;	for (uint8_t j=index; j>0; j--) {buff16 ^=buff16+s.charAt(j);
     for (uint8_t i=0; i<8; i++) {if (buff16 & 1) {buff16= (buff16 >> 1) ^ 0xA001;} // 0xA001 is the reflection of 0x8005
					   else {buff16 >>= 1;}}}			return buff16;};
char     RT_HW_HD44780:: getSignBool(uint8_t mode, bool v){										//==Возвращает символы для отображения;
if(mode==1) {if(v) {return '*';}  else  {return ' ';}} 	
if(mode==2) {if(v) {return '#';}  else  {return ' ';}} 	
if(mode==3) {if(v) {return '+';}  else  {return '-';}} 	
if(mode==4) {if(v) {return '1';}  else  {return '0';}}
if(mode==5) {if(v) {return '<';}  else  {return '>';}} 
if(mode==6) {if(v) {return '+';}  else  {return '_';}} 	
if(mode==7) {if(v) {return '*';}  else  {return '_';}} 
if(mode==8) {if(v) {return '#';}  else  {return '_';}}  
if(mode==9) {if(v) {return '.';}  else  {return '_';}}	
if(mode==10){if(v) {return 0xFF;} else  {return ' ';}} 
if(v) {return '*';} else  {return ' ';} 	
}
/*
char     RT_HW_HD44780:: colsForSet (uint8_t mode,uint8_t sz){									//==Возвращает кол-во колонок для настройки Lcd; 
if(mode==0){return 16;}	
if(mode==1){return 16;}	
if(mode==2){return 16;}		
if(mode==3){return 20;}
if(mode==4){return 20;}	
if(mode==5){return 20;}			
if(mode==6){return 40;}	
if(mode==7){return 40;}	
if(mode==8){return 40;}	
return 16; 	}
char     RT_HW_HD44780:: rowsForSet (uint8_t mode,uint8_t sz){									//==Возвращает кол-во строк для настройки Lcd; 
if(mode==0){return 4;}	
if(mode==1){return 2;}	
if(mode==2){return 1;}		
if(mode==3){return 4;}
if(mode==4){return 2;}	
if(mode==5){return 1;}
if(mode==6){return 4;}	
if(mode==7){return 2;}			
if(mode==8){return 1;}	
return sz;}
*/
uint8_t  RT_HW_HD44780:: getLenMess(RT_HW_HD44780_VAL_ID &iv){									//==Вычисление длины сообщения;
return (iv.head+iv.minus+iv.depth+iv.pnt+iv.point+iv.end);}
void     RT_HW_HD44780:: setVarID(RT_HW_HD44780_VAL_ID &iv, char mode, int32_t val){			//==Определение параметров для вывода числа.
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// id.mode: =D,0,1,2,3,F,L,T,B,b,H,h,8,z;
// id.form: =0 -без изменения,=1 -1 знак после точки;=2 -2 знака после точки;
//			=8 -преобразование в uint8_t; =16 -преобразование в uint16_t; =32 -преобразование в uint32_t; 
//  Выход: iv.val -нормализованное значение(без знака); 

//	iv.len   - длина общая (знаковая+дробная без знака и точки);
//	iv.minus - длина знаковой части (0-нет знака, 1 - знака '-'; 
//	iv.depth - длина целой части (max=12);   
//	iv.pnt   - длина разделителя частей (0-нет точки,1-есть точка;);
//  iv.point - длина дробной части (max=3); 
// struct RT_HW_HD44780_VAL_ID  {uint32_t val; uint16_t len:4,depth:4,point:2,minus:1,pnt:1,end:1; 
//                               uint8_t head, index;};// fresh:1;}; 
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
uint32_t buff32; uint8_t flag;
if(!iv.len) {iv.len=1;}  				//--Предварительная установка id.len (для исключения неточностей1 -ситуации с val=0; 
flag=iv.minus=iv.point=iv.pnt=iv.val=0; //--Очистка переменных;
if(mode=='I'){iv.point=0; flag=1;}		//--Установка кол-во знаков после точки для 'D';
if(mode=='U'){iv.point=0; flag=1;}		//--Установка кол-во знаков после точки для 'D';
if(mode=='D'){iv.point=0; flag=1;}		//--Установка кол-во знаков после точки для 'D';
if(mode=='0'){iv.point=0; flag=1;}		//--Установка кол-во знаков после точки для 'D';
if(mode=='1'){iv.point=1; flag=1;}		//--Установка кол-во знаков после точки для 'D'; 
if(mode=='2'){iv.point=2; flag=1;} 		//--Установка кол-во знаков после точки для 'D';
if(mode=='3'){iv.point=3; flag=1;}		//--Установка кол-во знаков после точки для 'D';
if(flag==1)  {flag=2; if(val<0) {iv.val=-val; iv.minus=1;} else {iv.val=val;}}
if(mode=='8'){flag=2; iv.val= (uint8_t)val&0xff;} 	
if(mode=='F'){flag=2; iv.val= (uint16_t)val&0xffff;} 	
if(mode=='L'){flag=2; iv.val= (uint32_t)val;}
if(flag==2)  {buff32=iv.val; iv.len=0; 
			  do{buff32=buff32/10; iv.len++; if((buff32==0)|| (iv.len>=12)){break;}} while(1); 	//--Вычисление кол-ва значащих цифр;
			  while(iv.len<=iv.point) {iv.len++;};	//--Увеличение кол-ва значащих цифр, если их кол-во меньше кол-ва знаков после точки;
			  if(iv.point) {iv.pnt=1;}} 			//--Получение  длины р
if(mode=='T') {iv.len=2;   if(val<0) {val=-val;} 
			   if(val<100) {iv.val=val;} else {iv.val=val-((val/100)*100);  iv.len=2;}}	//--Формат 2-х  значного времени;
if(mode=='B') {iv.len=8;   iv.val=val & 0xff;}			//--Формат 8-ми значного BIN-числа;	
if(mode=='b') {iv.len=4;   iv.val=val & 0x0f;}			//--Формат 4-х  значного BIN-числа;	
if(mode=='H') {iv.len=4;   iv.val=val & 0xffff;}		//--Формат 4-х  значного HEX-числа;
if(mode=='h') {iv.len=2;   iv.val=val & 0xff;}			//--Формат 2-х  значного HEX-числа;	
if(mode=='Z') {}
if(mode=='X') {}
iv.depth=iv.len-iv.point;	//--Вычисление кол-во знаков до точки;
iv.index=0;
};
char 	 RT_HW_HD44780:: getCharVal(uint32_t val,uint8_t upper,char mode,uint8_t len,uint8_t n){//==Возвращает цифру(как символ) из val начиная со старшей позиции;
//---mode B,b,H,h,D,0,1,2,3,T; upper =0 верхний регистр, =1 нижний регистр;
uint32_t buff32=0;
if((n>len) || (n>10)) n=0; 
if((mode=='B') || (mode=='b')) {buff32=(val>>(len-n))&1;}
if((mode=='H') || (mode=='h')) {buff32=(val>>(len-n)*4)&0xf;}
if((mode=='D') || (mode=='I') ||(mode=='U')|| (mode=='0') ||(mode=='1') ||(mode=='2') || (mode=='3') || (mode=='T')) 
                                        {n=len-n+1; while(n!=0) {buff32=val; val/=10; buff32=buff32-(val*10); n--;};}
if(buff32<=9) {buff32=buff32 +'0';} else {buff32=buff32-10+(upper ? 'A' : 'a') ;}
return (uint8_t)buff32;}; 

//=================================================================================================
void 	 RT_HW_HD44780:: createChar(uint8_t location, uint8_t charmap[]) {
	//location &= 0x7; // we only have 8 locations 0-7
	//command(LCD_SETCGRAMADDR | (location << 3));
	//for (int i=0; i<8; i++) {
	//	write(charmap[i]);
	//}
}



