/******************Строки для настройки Arduino IDE************************************************


https://dl.espressif.com/dl/package_esp32_index.json
http://arduino.esp8266.com/stable/package_esp8266com_index.json 
https://files.seeedstudio.com/arduino/package_seeeduino_boards_index.json 
https://github.com/stm32duino/BoardManagerFiles/raw/master/package_stmicroelectronics_index.json 
https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_dev_index.json

//--------------------------------------------------------------------------------------------------
http://docs.leaflabs.com/docs.leaflabs.com/index.html
https://github.com/rogerclarkmelbourne/Arduino_STM32
https://github.com/rogerclarkmelbourne/Arduino_STM32/wiki
***************************************************************************************************/

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//						1.Библиотеки привязки к Arduino
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#if defined(ARDUINO) && (ARDUINO >= 100) 
#include <Arduino.h>
#else
#include <WProgram.h>
#endif
#include <stdint.h>
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							1.Макросы для RT_HW_BASE
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#define RT_HW_MICROS				micros()				//--Макрос измерения времени в mcs;
#define RT_HW_MILLIS				millis()				//--Макрос измерения времени в ms;
#define RT_HW_BREAK_CHAR			'~'						//--Блокирующий символ для работы со строками^
#define RT_HW_READ_BYTE_PGM(arr,n) 	pgm_read_byte(&arr[n])	//--Чтение из массива arr n байта;
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							2.Общие макросы для сенсоров
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//						3.Коды идентификаторов архитектур контроллеров
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
enum {RT_HW_CODE_ARCH_ANON=0,	
      RT_HW_CODE_ARCH_AVR,			RT_HW_CODE_ARCH_ESP8266,		RT_HW_CODE_ARCH_ESP32, 
	  RT_HW_CODE_ARCH_SAM, 			RT_HW_CODE_ARCH_SEEED,			
	  RT_HW_CODE_ARCH_STM32, 	 	RT_HW_CODE_ARCH_STM32F1,    	RT_HW_CODE_ARCH_STM32F4,		RT_HW_CODE_ARCH_STM32H7};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//								4.Коды типов контроллеров
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	  
enum {RT_HW_CODE_BOARD_ANON=0};
enum {RT_HW_CODE_BOARD_AVR_UNO=1,       	RT_HW_CODE_BOARD_AVR_NANO,					RT_HW_CODE_BOARD_AVR_PRO,			RT_HW_CODE_BOARD_AVR_MEGA2560};	  
enum {RT_HW_CODE_BOARD_ESP8266_GENERIC=10, 	RT_HW_CODE_BOARD_ESP8266_WEMOS_D1MINILITE, 	RT_HW_CODE_BOARD_ESP8266_WEMOS_D1MINIPRO, 
      RT_HW_CODE_BOARD_ESP8266_NODEMCU_ESP12, RT_HW_CODE_BOARD_ESP8266_NODEMCU_ESP12E};
enum {RT_HW_CODE_ESP32_DEV=20,       		RT_HW_CODE_TTGO_T1,  				RT_HW_CODE_LOLIN_D32, 				
      RT_HW_CODE_M5Stack_Core_ESP32,	    RT_HW_CODE_D1_MINI32,               RT_HW_CODE_ESP32C3_DEV};	
enum {RT_HW_CODE_SAM_DUE=30, 				RT_HW_CODE_SAMD_ZERO,				RT_HW_CODE_SEEED_XIAO_M0,			RT_HW_CODE_NANO_RP2040_CONNECT, 			
	  RT_HW_CODE_NANO_33_BLE,				RT_HW_CODE_RASPBERRY_PI_PICO,		RT_HW_CODE_RASPBERRY_PI,	  		RT_HW_CODE_PORTENTA_H7};	  
enum {RT_HW_CODE_M_GENERIC_STM32F103C=40, 	RT_HW_CODE_M_GENERIC_STM32F103R, 	RT_HW_CODE_M_GENERIC_STM32F103V};
enum {RT_HW_CODE_M_generic_f407v=45,      	RT_HW_CODE_M_blacklPill_f401,    	RT_HW_CODE_M_disco_f411};
enum {RT_HW_CODE_D_BLUEPILL_F103C8=50,	  	RT_HW_CODE_D_BLUEPILL_F103CB,    	RT_HW_CODE_D_BLACKPILL_F103C8,		RT_HW_CODE_D_BLACKPILL_F103CB,	RT_HW_CODE_D_GENERIC_F103CBTX}; 		
enum {RT_HW_CODE_D_GENERIC_F103RETX=55,   	RT_HW_CODE_D_GENERIC_STM32F103V, 	RT_HW_CODE_D_Generic_F103VETX};
enum {RT_HW_CODE_D_BLACK_F407VE=60,       	RT_HW_CODE_D_BLACK_F407VG,       	RT_HW_CODE_D_GENERIC_F407VETX,   	RT_HW_CODE_D_GENERIC_F407VGTX};	   
enum {RT_HW_CODE_D_BLACKPILL_F401CC=65,   	RT_HW_CODE_D_BLACKPILL_F411CE};	   
enum {RT_HW_CODE_D_GENERIC_H743VITX=80};	
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							6.Индексы массивов хранящихся в PGM
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
enum{RT_HW_PGM_SYS_PAR_ID,  RT_HW_PGM_SYS_ADC_ID,	RT_HW_PGM_SYS_TCH_ID,	RT_HW_PGM_SYS_PWM_ID,	RT_HW_PGM_SYS_DAC_ID,	 RT_HW_PGM_SYS_PIN_ID,
//-------------------------------------------------------------------------------------------------	 
	 RT_HW_PGM_PIN_I2C_ID,  RT_HW_PGM_PIN_SPI_ID,	RT_HW_PGM_PIN_UHS_ID,	RT_HW_PGM_PIN_USS_ID,
	 RT_HW_PGM_PIN_CAN_ID,	RT_HW_PGM_PIN_BTH_ID,	RT_HW_PGM_PIN_ETH_ID,	RT_HW_PGM_PIN_WFI_ID,
//-------------------------------------------------------------------------------------------------
     RT_HW_PGM_PIN_ALL_ID,	RT_HW_PGM_PIN_DIN_ID,	RT_HW_PGM_PIN_ADC_ID,	RT_HW_PGM_PIN_TCH_ID,
	 RT_HW_PGM_PIN_DOT_ID,	RT_HW_PGM_PIN_PWM_ID,	RT_HW_PGM_PIN_DAC_ID,	RT_HW_PGM_PIN_INT_ID, 
	 RT_HW_PGM_PIN_N5V_ID,
//-------------------------------------------------------------------------------------------------
	 RT_HW_PGM_PIN_DBG_ID,	RT_HW_PGM_PIN_OUT_ID,	RT_HW_PGM_PIN_INP_ID, 
	 RT_HW_PGM_PIN_DCT_ID,	RT_HW_PGM_PIN_DEV_ID,	RT_HW_PGM_PIN_CSS_ID,	
	 RT_HW_PGM_PIN_LC6_ID,	RT_HW_PGM_PIN_TFT_ID,	RT_HW_PGM_PIN_SSP_ID,  
//-------------------------------------------------------------------------------------------------
	 RT_HW_PGM_ADR_I2C_ID,
//-------------------------------------------------------------------------------------------------	 
	 RT_HW_PGM_QNT_ID,		RT_HW_PGM_END=254}; 	 
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							7.Идентификаторы скоростей UART (аппаратный и программный);
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
enum  {RT_HW_UART_SPEED_HS=115200UL, RT_HW_UART_SPEED_SS=9600UL};	
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							8.Параметры для работы с шиной i2c 
//	1. Коды битов слова состояния(STATE - device.i2cx.state); 
//	2. Коды скоростей шины i2c;
//  3. Скорости шины i2c (соответствуют кодам скоростей); 
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
enum {RT_HW_I2C_STATE_INIT=0, RT_HW_I2C_STATE_MASTER=1, RT_HW_I2C_STATE_SLAVE=2, RT_HW_I2C_STATE_BUSY=7};
enum {RT_HW_I2C_MODE_LOW=0,   RT_HW_I2C_MODE_ST, RT_HW_I2C_MODE_FM, RT_HW_I2C_MODE_FM1, RT_HW_I2C_MODE_FM2,
	  RT_HW_I2C_MODE_FMP,     RT_HW_I2C_MODE_HS, RT_HW_I2C_MODE_UFM}; 	
enum {RT_HW_I2C_SPEED_LOW=  10, RT_HW_I2C_SPEED_ST = 100, 
	  RT_HW_I2C_SPEED_FM = 400, RT_HW_I2C_SPEED_FM1= 600, RT_HW_I2C_SPEED_FM2= 800,
	  RT_HW_I2C_SPEED_FMP=1000, RT_HW_I2C_SPEED_HS =3400, RT_HW_I2C_SPEED_UFM=5000,
	  RT_HW_I2C_FIND_PERIOD=50};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							9.Параметры для работы с шиной SPI
//	1. Коды битов слова состояния(STATE - device.SPIx.state);   
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
enum {RT_HW_SPI_STATE_INIT=0, RT_HW_SPI_STATE_MASTER=1, RT_HW_SPI_STATE_SLAVE=2, RT_HW_SPI_STATE_BUSY=7};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#define RT_HW_DEFAULT_T_NAN -1
#define RT_HW_DEFAULT_H_NAN  1
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//    Таблица для расчета контрольной суммы
// Dow-CRC using polynomial X^8 + X^5 + X^4 + X^0
// Tiny 2x16 entry CRC table created by Arjen Lentz
// See http://lentz.com.au/blog/calculating-crc-with-a-tiny-32-entry-lookup-table
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
static const uint8_t PROGMEM RT_HW_PGM_TABLE_CRC8_2X16[]= {
0x00, 0x5E, 0xBC, 0xE2, 0x61, 0x3F, 0xDD, 0x83,
0xC2, 0x9C, 0x7E, 0x20, 0xA3, 0xFD, 0x1F, 0x41,
0x00, 0x9D, 0x23, 0xBE, 0x46, 0xDB, 0x65, 0xF8,
0x8C, 0x11, 0xAF, 0x32, 0xCA, 0x57, 0xE9, 0x74
};

