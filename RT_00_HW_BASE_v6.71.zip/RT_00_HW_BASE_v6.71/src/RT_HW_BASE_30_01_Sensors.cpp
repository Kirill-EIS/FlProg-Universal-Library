#include "RT_HW_BASE.h"
//-------------------------------------------------------------------------------------------------
#define RT_HW_DHT22_VER            12	//--Версия библиотеки DHT22;
#define RT_HW_DS1820_VER           11	//--Версия библиотеки DS1820;
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//          Параметры
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#define RT_HW_SR04_VER             12	//--Версия библиотеки DHT22;
#define RT_HW_SR04_timePulse	   10	//--Длительность (mcs) генерируемого импульса на пине Trig 
#define RT_HW_SR04_maxBegin       700	//--Максимальное время (mcs) появления ответного импульса Echo 
#define RT_HW_SR04_minBegin       200	//--Минимальное время  (mcs) появления ответного импульса Echo 
#define RT_HW_SR04_maxDurate    25000	//--Максимальная длительность ответного импульса
#define RT_HW_SR04_convert        582 	//--Коэффициент пересчета мкс в мм
#define RT_HW_SR04_CmToMcs	   	   70 	//--Коэффициент преобразования 



//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//            			СЕНСОР  DHT22
// 1.Линия сенсора: притягивается к земле (600mсs); переводится в режим чтения; последовательно принимается 83 изменения линии.
//	 Если нет линия не меняется более 90mcs - фиксируется ошибка с кодом 2.
//    FALLING, RISING и FALLING - это стартовый бит, затем 40 бит: 
// 2. Проверяется контрольная сумма ---> codeErr=3.
// 3. Проверяется диапазон (температура -50.0/+125.0 градусов по Цельсию, влажность 0/100.0 %);
// 4. При отсутствии ошибок запоминаются полученные результаты и при необходимости взводится флаг изменившихся данных (id.fresh);
// 5. После  ошибочных чтений, превышающих maxQntErr, результатам T и H присваивается DHTx_NAN_INT
// Коды ошибок: =0 нет ошибки; =1 не верный пин;=2 ошибка по тайм-ауту 90mcs при измерении; =3 ошибка КС; =4 выход за диапазон измерений;
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void RT_HW_BASE:: dht22SetID( RT_HW_STRUCT_DHT22 &id){		//==Настройка ID сенсора DHT22
if(id.custom==0){	
 if(!checkPinPGM( RT_HW_PGM_PIN_DIN_ID,id.pin)) {id.custom=90; return;}	//--Проверка пина на дискретный ввод;
 if(!checkPinPGM( RT_HW_PGM_PIN_DOT_ID,id.pin)) {id.custom=91; return;}	//--Проверка пина на дискретный вывод;	
 id.vT=RT_HW_DEFAULT_T_NAN; id.vH=RT_HW_DEFAULT_H_NAN;					//--Установка начальных состояний;
 id.fresh=1;
 id.codeErr=id.cntErr=0;
 id.run=1;
 id.timeBegin=millis();
 id.custom=1; }}
void RT_HW_BASE:: dht22Direct(RT_HW_STRUCT_DHT22 &id){		//==Управление чтением сенсора;
if(id.dir==0){
	if(id.custom!=1)  {return;}
 	if(id.extEN==0) {return;} //.codeErr=id.cntErr=id.cntMeter=0; id.ok=0; id.fresh=1; 			//--Инициализация параметров структуры;
	if(id.ok) {if(periodMs(id.timeBegin,id.period)) {id.run=1;}}
	else 	  {if(periodMs(id.timeBegin,2200))      {id.run=1;}}
	if(id.run==0) {return;}
    id.run=0; 
	digitalWrite(id.pin,LOW); pinMode(id.pin,OUTPUT); 	//--Притягивание линия устройства к земле 
	id.timeWait=micros();
    id.dir++;}
if(id.dir==1){
	if(getPastMcs(id.timeWait)<1000) {return;}			//--Удержание линии фиксированное время.
	//delayMicroseconds(700);		    				//--Удержание линии фиксированное время.
//-------ЧТЕНИЕ ДАННЫХ из сенсора------------------------------------------------------------------
{uint8_t age; int8_t i; uint32_t timeDelay; uint16_t rawH, rawT, data; int16_t vT;
digitalWrite(id.pin,HIGH);
pinMode(id.pin,INPUT);  digitalWrite(id.pin,HIGH);			//--Перевод пина устройства в режим чтения
//--Начала цикла изменений на входе (83 раз) - первые три - стартовый импульс;
rawH=rawT=vT=0; data=0;	id.error=id.fresh=0; 
for( i=-3; i<80; i++) {timeDelay=micros();
 do{age = getPastMcs(timeDelay); 
 if(age >90){id.codeErr=2; id.error=1; break;}} while (digitalRead(id.pin) == (i & 1) ? HIGH : LOW ); //--Ожидание импульса с тайм-аутом 90мкс(ошибка тайм-аута codeErr=2)      
 if(id.error) break;
 if(i>=0 && (i&1)) {data<<=1; if(age>30){data|=1;}}		//--Проверяем изменение на линии (первые три стартовых импульса пропускаем)
 if(i==31){rawH=data;}
 if(i==63){rawT=data; data = 0;}}
//--Проверка на контрольную сумму;
 if(!id.error) {if( (uint8_t)(((uint8_t)rawH) + (rawH >> 8) + ((uint8_t)rawT) + (rawT >> 8)) != data ) 
			   {id.codeErr=3; id.error=1; }}
//--Обработка и проверка результата измерения;
if(!id.error)  {if (rawT & 0x8000 ) { vT = -(int16_t)(rawT & 0x7FFF);} else {vT=rawT;}
		        if((rawH > 1000) || (vT < -500) || (vT > 1250)) {id.codeErr=4; id.error=1;}}
//--Обработка ошибочного измерения;
if(id.error)  {if(++id.cntErr > id.maxQntErr) {
			   id.cntErr=0; id.ok=0; id.vT=RT_HW_DEFAULT_T_NAN; id.vH=RT_HW_DEFAULT_H_NAN; id.fresh=true; id.dir=0;} return;}  
//--Обработка положительного результата	;	  
id.ok=1;    id.cntErr=0; id.codeErr=0; 
id.fresh=1; id.vH=rawH;  id.vT=vT;
}			
//-------------------------------------------------------------------------------------------------				
id.dir=0;}};

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//            ЧТЕНИЕ СЕНСОРА  DS1820
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void RT_HW_BASE:: ds1820SetID(RT_HW_STRUCT_ONE_WIRE &iw, RT_HW_STRUCT_DS1820 &id){
if(id.custom==0){
 if(!checkPinPGM( RT_HW_PGM_PIN_DIN_ID,id.pin)) {id.custom=90; return;}	//--Проверка пина на дискретный ввод;
 if(!checkPinPGM( RT_HW_PGM_PIN_DOT_ID,id.pin)) {id.custom=91; return;}	//--Проверка пина на дискретный вывод;	
 oneWireBegin(iw,id.pin);												//--Инициализация шины;
 id.cntErr=0; id.fault=1; id.ok=0; id.fresh=1; 							//--Инициализация параметров структуры;
 digitalWrite(id.pin,HIGH); pinMode(id.pin,OUTPUT);						//--Настройка пина;
 id.custom=1;}};														//--Успешный выход;		
void RT_HW_BASE:: ds1820(RT_HW_STRUCT_ONE_WIRE &iw, RT_HW_STRUCT_DS1820 &id){
if(id.dir==0) {	if(id.custom!=1) {return;} 								//--Ожидание настройки ID;
			    id.timePeriod=millis()+id.period-100; id.dir++;}		//--Установка задержки 100мс для нормализациия питания;
if(id.dir==1) {	if(getPastMs(id.timePeriod)<id.period) {return;} id.timePeriod=millis(); iw.step=0; id.dir++;}	
if(id.dir==2) { if(!id.extEN){return;}					//--Ожидание готовности;
				oneWireReset(iw);						//--Сброс шины;
				if(iw.state==0) {return;}				//--Ожидание завершения сброса;
				if(iw.state==1) {id.dir++; return;}		//--После сброса обнаружены устройства;
				if(iw.state>=2) {id.dir=20; return;}}	//--Устройства не обнаружены; переход на обработку ошибок;
if(id.dir==3) { oneWireWrite(iw,0xCC); id.dir++; return;}
if(id.dir==4) { oneWireWrite(iw,0x44); id.dir++; id.timeDelay=millis(); return;}
if(id.dir==5) {	if(getPastMs(id.timeDelay)<800) {return;} iw.step=0; id.dir++;}
if(id.dir==6) { oneWireReset(iw);
				if(iw.state==0) {return;}				//--Ожидание завершения сброса;
				if(iw.state==1) {id.dir++; return;}		//--После сброса обнаружены устройства;
				if(iw.state>=2) {id.dir=20; return;}}	//--Устройства не обнаружены; переход на обработку ошибок;
if(id.dir==7) { oneWireWrite(iw,0xCC); id.dir++; return;}
if(id.dir==8) { oneWireWrite(iw,0xBE); id.dir++;}
if(id.dir==9) { uint8_t data[9]; uint8_t crc; int16_t raw;
				oneWireReadBytes(iw,data,9);
				crc=crc8(data,8); if((crc !=data[8]) ||  (data[4]==0))  {iw.state=5; id.dir=20; return;}
				raw = (data[1] << 8) | data[0];										//---Вычисление измеренного значения;
				if(id.typeSensor){raw=raw <<3; if (data[7]==0x10) {raw=(raw & 0xFFF0)+12-data[6];}}
				else			 {uint8_t cfg = (data[4] & 0x60);
								  if      (cfg==0x00) raw = raw & ~7; //--Урезаем, если 9 bit resolution, 93.75 ms
								  else if (cfg==0x20) raw = raw & ~3; //--Урезаем, если 10 bit res, 187.5 ms
				                  else if (cfg==0x40) raw = raw & ~1; //--Урезаем, если  11 bit res, 375 ms
								 }
				id.ok=1; id.cntErr=0; if(id.vT!=raw) {id.vT=raw; id.fresh=1;}
				id.dir=1; return;}	   
if(id.dir==20){id.dir=1; if(++id.cntErr>id.maxQntErr) {id.cntErr=0; id.ok=0; id.fresh=1; id.vT=-2;}}	
}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//            ЧТЕНИЕ СЕНСОРА  HC-SR04
// При измерении параметров ответного эхо-импульса c аппаратным прерывание в скетч или в блок FLProg должны быть включены функции 
//	void IRQ_start()  {							//--Запуск обработчика прерывания;				
//		 id.runIRQ=false; attachInterrupt(id.numIRQ, IRQ_handler, CHANGE);};
//	void IRQ_handler(){							//--Обработчик прервания;
//  	if(!id.start) return;
//   	if(!id.begin){if( digitalRead(id.pinEcho)) {id.timeBegin=RT_HW_HC_SR04_MICROS; id.begin=true;}}
//     			 else{if(!digitalRead(id.pinEcho)) {id.timeEnd  =RT_HW_HC_SR04_MICROS; id.end  =true;  detachInterrupt(id.numIRQ);}}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void RT_HW_BASE:: sonarSetID(RT_HW_STRUCT_HC_SR04 &id, uint8_t Echo, uint8_t Trig, uint16_t period, uint16_t maxLenBlockIRQ, uint16_t maxLenPermitIRQ) {	//==Иниицализация;
if(id.custom==0) {
	id.period=period;
	id.tAir=20;
	sonarSpeedAir(id);												//--Расчет скорости воздуха с учетом температуры воздуха;	
	id.LenMaxMcs=(maxLenPermitIRQ-1)*RT_HW_SR04_CmToMcs;			//--Расчет максимального времени в mcs (предварительная);
	id.pinTrig=Trig;												//--Установка пина trig;	
	if(Echo==255) {id.pinEcho=Trig;} else {id.pinEcho=Echo;}		//--Установка пина echo;
	if(!checkPinPGM( RT_HW_PGM_PIN_DOT_ID,id.pinTrig)) {id.code=2; id.custom=2; return;}	//--Проверка пина Trig на дискретный вывод;
	if(!checkPinPGM( RT_HW_PGM_PIN_DIN_ID,id.pinEcho)) {id.code=3; id.custom=3; return;}	//--Проверка пина Echo на дискретный вывод;	
	RT_HW_PIN_DIR_SET_ID(id.ddTrig,id.pinTrig); 					//--Настройка id.dd для пина Trig;
	RT_HW_PIN_DIR_SET_ID(id.ddEcho,id.pinEcho); 					//--Настройка id.dd для пина Echo;
	id.numIRQ=digitalPinToInterrupt(id.pinEcho);					//--Проверка пина Echo на наличие прерываний, возвращается -1;
	if((id.numIRQ>=0) && (!id.blockIRQ))							//--Выбор режима обработки (с прерываниями/без прерываний);
		 {id.modeIRQ=1; id.LenMaxCm =maxLenPermitIRQ;}	//--Параметры для пина c прерыванием  и   прерывания разрешены; 	
    else {id.modeIRQ=0; id.LenMaxCm =maxLenBlockIRQ;}		//--Параметры для пина без прерывания или прерывания запрещены;
	id.LenMcs=id.LenMaxMcs=id.LenMaxCm * RT_HW_SR04_CmToMcs;		//--Расчет максимального времени в mcs (предварительная);
	id.startIRQ=0;
	id.fresh=true;
    id.timePeriod=millis();										//--
	id.code=1; id.custom=1;
	};										//--Установка флага "Успешная настройка";
};
void RT_HW_BASE:: sonarSpeedAir(RT_HW_STRUCT_HC_SR04 &id){		//==Расчет скорости звука с учетом окружающей температуры;
id.speedSoundAir=(331.3 + (0.606 * float(id.tAir))); 
//consoleText(String(F("t,speed=")));  ConsoleV16('I', 0,',',id.tAir);	ConsoleV16('U', 0,'E',id.speedSoundAir);

}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void RT_HW_BASE:: sonar(RT_HW_STRUCT_HC_SR04 &id, bool EN, int16_t tAir){							//==Измерение дистации;
if(id.dir==0) {if (id.custom!=1) {return;} id.dir++;}
if(id.dir==1) {														//--Формирование запускащего импульса;
	if(!EN){return;} 			
	id.startIRQ=0; id.begin=id.end=false;
	RT_HW_PIN_DIR_WRITE_LOW(id.ddTrig); RT_HW_PIN_DIR_MODE_OUTPUT(id.ddTrig);	//--Настройка пина Trig на вывод; 
	RT_HW_PIN_DIR_WRITE_HIGH(id.ddTrig); 										//--Пин Trig в HIGH;  
	delayMicroseconds(10);														//--Задержка 10mcs; 
	RT_HW_PIN_DIR_WRITE_LOW(id.ddTrig); RT_HW_PIN_DIR_MODE_OUTPUT(id.ddTrig);	//--Пин Trig в LOW; 
	pinMode(id.pinEcho,RT_HW_PIN_MODE_INPUT_PULLUP); 							//--Настройка пина Echo на ввод с подтяжкой к Vcc; 		   
	id.timeBegin=id.timeEnd=micros(); 											//--Фиксация начальных времен;	
	if(RT_HW_PIN_DIR_READ(id.ddEcho)){id.code=10; id.runIRQ=0; id.dir=20;} 		//--Чтение Echo. При наличии датчика HIGH не появляется ранее400mcs;		
	if(id.modeIRQ)	{id.runIRQ=1; id.dir=2;} 									//--Переход на обработку по прерыванию;
	else     		{ 	     	    id.dir=3;}									//--Переход на обработку по времени;
}		 
if(id.dir==2) {														//--Ожидание ответного импульса Echo в режиме  с прерыванием;
	if(id.end)                                       	      	{id.code=0; id.dir=20;} //--Выход по окончанию импульса Echo;
	else if(getPastMcs(id.timeBegin)>(RT_HW_SR04_maxDurate+400)){           id.dir=20;} //--Выход по тайм-ауту импульса Echo;
	else   												      	{return;}}						//--Выход для ожидания окончания импульса Echo; 
if(id.dir==3) {														//--Ожидание ответного импульса Echo в режиме без прерывания;	
	do{if( RT_HW_PIN_DIR_READ(id.ddEcho))                     {id.timeBegin=micros();                id.begin=true; break;}  	//--Фиксация переднего фронта;
	     if(getPastMcs(id.timeBegin)>(RT_HW_SR04_maxBegin +400)){id.code=21;                                         break;}} while(1);  //--Выход по тайм-ауту;
	if(id.begin){													
	do{if(!RT_HW_PIN_DIR_READ(id.ddEcho))                     {id.code=0;  id.timeEnd=micros();                  id.end=true;   break;}	
	   if(getPastMcs(id.timeBegin)>id.LenMaxMcs)              {id.code=22; id.timeEnd=id.timeBegin+id.LenMaxMcs; id.end=true;   break;}} while(1);}
    id.dir=20;return;};	
if(id.dir==20) {
	if(id.modeIRQ) {detachInterrupt(id.numIRQ);}									//--Сброс прерывания;
	if(id.code==0) {id.LenMcs=(uint16_t)getPastTime(id.timeBegin,id.timeEnd); 
					if(id.tAir!=tAir) {id.tAir=tAir; sonarSpeedAir(id);}
					id.LenMm=(uint16_t)(((uint32_t)id.LenMcs * id.speedSoundAir)/2000);	
					id.cntErr=0; id.ok=1; id.fresh=1;}	
	else		   {if(++id.cntErr>=5){id.cntErr=5; id.ok=0; id.LenMm=id.LenMaxCm*100; id.LenMcs =id.LenMcs/RT_HW_SR04_CmToMcs;}}							 						 							 
	id.dir++;}							 
if(id.dir==21) {													//--Ожидание 			  
	if(periodMs(id.timePeriod,id.period)) {id.timePeriod=millis(); id.dir=1;} return;}};
/*
void RT_HW_BASE:: sonarEcho (RT_HW_STRUCT_HC_SR04 &id) {											//==Измерение параметров ответного эхо-импульса c аппаратным прерыванием;
	if(id.modeIRQ){if((id.end) || (getPastMcs(id.timeStart)>RT_HW_SR04_maxDurate)) {id.run=0;} return;}
	else{
		//--Ожидание переднего фронта ответного импульса Echo с тайм-аутом;                        
		do{if(digitalRead(id.pinEcho)) {id.timeBegin=micros(); id.begin=true; break;} // Фиксация времени переднего фронта и установка флага прихода переднего фронта
		if(getPastMcs(id.timeStart)>RT_HW_SR04_maxBegin) {break;}} while(1);	
		//--Ожидание  заднего  фронта ответного импульса Echo с тайм-аутом;    			
		if(id.begin){
		do{if(!digitalRead(id.pinEcho)){id.timeEnd  =micros(); id.end  =true; id.start=false; break;}	
		if(getPastMcs(id.timeBegin)>id.lenMaxMcs){id.start=false; id.timeEnd=id.timeBegin+id.lenMaxMcs; id.end=true; break;}} while(1);}
		//--Завершение измерения 
		id.run=0;};
};
*/

//double speedOfSoundInCmPerMs = 0.03313 + 0.0000606 * temperature; // Cair ≈ (331.3 + 0.606 ⋅ ϑ) m/s
//    double distanceCm = durationMicroSec / 2.0 * speedOfSoundInCmPerMs;
//    if (distanceCm == 0 || distanceCm > 400) {
//        return -1.0 ;
//    } else {return distanceCm;}


//	double speedOfSoundInCmPerMs = (331.3 + 0.606 * temperature) * 39.37007874 / 1000 / 1000; // Cair ≈ (331.3 + 0.606 ⋅ ϑ) m/s
//	long* times = measureMicroseconds();

	// Calculate the distance in cm for each result.
//	for (uint8_t i = 0; i < this->echoCount; i++) {
//		double distanceIn = times[i] / 2.0 * speedOfSoundInCmPerMs;
//		if (distanceIn < 1 || distanceIn > 157.4804) {
//			results[i] = HCSR04_INVALID_RESULT;
//		}
//		else {
//			results[i] = distanceIn;
//		}
//	}
//}


//		Функция комплексной работы с сенсором;	


//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++