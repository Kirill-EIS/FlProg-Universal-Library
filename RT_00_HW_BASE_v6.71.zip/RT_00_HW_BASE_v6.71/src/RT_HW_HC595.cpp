#include "RT_HW_HC595.h"
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
//							Настройка ID
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void RT_HW_HC595:: setID(RT_HW_STRUCT_HC595 &id){ 	//==Настройка ID;															
if(id.custom!=0) {return;}
if(id.link=='S'){																//==Настройка устройство через SPI;
	if(!RT_HW_Base.checkPinPGM(RT_HW_PGM_PIN_DOT_ID,id.cs)) 	    {id.custom=90; return;}	//--Проверка пина сs на дискретный вывод;
	digitalWrite(id.cs, 0); pinMode(id.cs, OUTPUT);											//--Настройка пина clk  на выход и LOW;	
	RT_HW_Base.spiBegin(255,255,255,0,id.bus);												//--Настройка SPI как Master. Функция не выполняет действия, если шина раньше не настраивалась;
	if(!RT_HW_Base.spiCheckBusState(RT_HW_SPI_STATE_MASTER,id.bus))	{id.custom=91; return;}	//--Если шина не настроена, выход по ошибке настройки;	
	transfer(id,id.begin);																	//--Установка начального значения;												
	id.custom=1; return;}																	//--Успешный выход;
else if(id.link=='s'){															//==Настройка устройство через SSPI;
	if(!RT_HW_Base.checkPinPGM(RT_HW_PGM_PIN_DOT_ID,id.clk)) 		{id.custom=92; return;}	//--Проверка пина prm(clk) на дискретный вывод;
	if(!RT_HW_Base.checkPinPGM(RT_HW_PGM_PIN_DOT_ID,id.mosi)) 		{id.custom=93; return;}	//--Проверка пина mosi на дискретный вывод;
	if(!RT_HW_Base.checkPinPGM(RT_HW_PGM_PIN_DOT_ID,id.cs)) 	    {id.custom=94; return;}	//--Проверка пина сs на дискретный вывод;
	digitalWrite(id.cs,  0); pinMode(id.cs,  OUTPUT);										//--Настройка пина clk  на выход и LOW;	
	digitalWrite(id.clk, 0); pinMode(id.clk, OUTPUT);										//--Настройка пина clk  на выход и LOW;	
	digitalWrite(id.mosi,0); pinMode(id.mosi,OUTPUT);										//--Настройка пина mosi на выход и LOW;				
	id.custom=1; return;}																	//--Успешный выход;
else {id.custom=97; return;}																//==Выход по ошибке неопознанного интерфейса;
};							//==Конец функции;
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
//							Запись в устройство
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void RT_HW_HC595:: transfer(RT_HW_STRUCT_HC595 &id, uint8_t val){		//==Запись в устройство	
if(id.link=='S'){			//==Отправка байта в SPI;
	//RT_HW_Base.spiBeginTransaction(id.spiClock, id.spiBitOrder, SPI_MODE0, id.bus);	
	RT_HW_Base.spiSendByte (id.cs,id.bus,val);  
	//RT_HW_Base.spiEndTransaction(id.bus);
	return;} 
else if(id.link=='s'){		//==Отправка байта в SSPI
    RT_HW_Base.sspiSendByte(id.clk,id.mosi,id.cs,val,id.spiBitOrder); return;}
else {return;}				//==Устройство не опознано;
};							
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							Управление устройством
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void 	RT_HW_HC595:: direct(RT_HW_STRUCT_HC595 &id, uint8_t val){
if(id.dir==0) {if(id.custom!=1) {return;} id.dir=10;}	//--Ожидание настройки ID;	
if(id.dir==10){											//==Основной вывод;
	if(!id.extEN)  {return;} 							//--Ожидание разрешения работы по событию;	
	if(id.ago!=val) {id.ago=val; transfer(id,id.ago);} 	//--Вывод при изменении данных;
	if(id.period>0) {id.timePeriod=millis(); id.dir++;}}//--Переход на ожидание периода с выходом или просто выход;
if(id.dir==11){											//==Ожидание завершения периода;
	if(RT_HW_Base.periodMs(id.timePeriod,id.period)) {id.dir=10;} return;}}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
RT_HW_HC595 RT_HW_hc595;//--Создание внешнего объекта	
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

