/*** FLProg ************** Библиотека RT_HW_HD44780 ver2.1 для Arduino ***************
  Вывод на несколько LCD типа HD44780 переменных String, char, int16_t, float в указанное место указанного дисплея.
  Если задана длина (len) выводимого сообщения, то вывод осуществляется в пределах указанной длины или до конца  строки.
  Если len=0, то вывод осуществляется до конца строк. 
  Сообщение может быть отформатировано(alig) в пределах заданной длины  влево ('L'), по центру ('C'), право ('R').
    При этом к сообщению добавляются пробелы или оно обрезается. Если alig='N' (или другой отличный символ 
	кроме 'L','C','R'), то форматирование не осуществляется. При этом надо иметь ввиду что более короткое сообщение
	не затрет предыдущее более длинное сообщение. Поэтому рекомендуется явно задавать вид форматирования или использовать
    форматирование по умолчанию, которое в библиотеке ='L' (влево).
  Имеется функция вывода мерцающего символа по указанному адресу.	
	
  Библиотеки  разрабатываются с учетом особенностей использования в системе визуального программирования FLProg.
  ecoins@mail.ru 29.09.2019г.
  Обновление 03.07.21 Добавлен режим 40 колонок х 4 строки; 
**************************************************************************************************/
//#################################################################################################
//-------------------------------------------------------------------------------------------------
#ifndef RT_HW_HD44780_h
#define RT_HW_HD44780_h
#define RT_HW_HD44780_VER 		 17					//--Номер версии библиотеки;
//#define RT_HW_HD44780_EXT_GEN_RUS					//--Внешний генератор русских символов (В РАЗРАБОТКЕ);
//-------------------------------------------------------------------------------------------------
#include  "RT_HW_BASE.h"							//--Подключение базовой библиотеки;
#include "RT_HW_HD44780_01_DEFINED.hpp"
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//                     КЛАСС УПРАВЛЕНИЯ LCD
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
class RT_HW_HD44780{
public:
//-------1.0. Создание объектов и конструктор----------------------------------------------------------------------
RT_HW_HD44780_HIVE 		hive;								//--Общие данные для работы библиотеки;
RT_HW_HD44780_DEVICE_ID *ptr[RT_HW_HD44780_MAX_DEVICE+1];	//--Массив указателей на данные со структурой устройств				
RT_HW_HD44780(); 
//-------1.1. Функции настройки и управления устройством (Main.cpp)------------------------------------------------
void     setID    (RT_HW_HD44780_DEVICE_ID *z);									//==Установка параметров ID устройства;	
void 	 direct   (RT_HW_HD44780_DEVICE_ID &z);									//==Управление устройством;
void     generator(RT_HW_HD44780_DEVICE_ID &z);									//==Тактирующий генератор внешних устройств (блоков FLProg);
bool 	 initBUS4 (RT_HW_HD44780_DEVICE_ID &z);									//==Настройка Lcd c 4-x  битовой шиной данных;
bool 	 initBUS8 (RT_HW_HD44780_DEVICE_ID &z);									//==Настройка Lcd c 8-ми битовой шиной данных;
bool 	 init4004 (RT_HW_HD44780_DEVICE_ID &z);									//==Настройка Lcd 40;
//-------1.2. Функции отправки данных в устройство------------------------------------------------------------------
bool  	 deviceSend    (uint8_t num, uint8_t val, char code, uint16_t time=0);	//==Отправка данных в устройство    (mode:T,I,D,B,A);
uint8_t	 deviceTransfer(uint8_t num, const uint8_t *arr, char code);			//==Отправка байтов через интерфейс;
//-------2.1. Функции управления устройством-----------------------------------------------------------------



void	 lcdGenerator   (RT_HW_HD44780_GENLCD_ID &id, uint8_t Gen, bool EN=1, bool Blink=0);//==Генератор для вывода на lcd;
//-------2.2. Функции для вывода параметров-------------------------------------------------------------------
void 	 lcdSetParamID  (RT_HW_HD44780_PARAM_ID  &id, int8_t num, uint8_t col, uint8_t row, uint8_t len, uint16_t periodOut, uint16_t periodBlink, uint8_t codeSign=1);
void     lcdSendChar    (RT_HW_HD44780_PARAM_ID  &id, bool EN, bool Blink, char mode, char Val=' ', bool val=0);
void     lcdSendVal     (RT_HW_HD44780_PARAM_ID  &id, RT_HW_HD44780_VAL_ID &iv, bool EN, bool Blink, char mode, char alig, int32_t val, char suff,  const char *head);
void     lcdSendStr     (RT_HW_HD44780_PARAM_ID  &id, RT_HW_HD44780_STR_ID &iv, bool EN, bool Blink, char mode, char alig, String str);
//------3.1. Вспомогательные функции-------------------------------------------------------------------------
uint8_t  timeToTick  (uint16_t time, uint8_t TICK=RT_HW_HD44780_PERIOD_TICK);	//==Конвертация времени в тики (max=255)->,один тик=periodTick;	
uint8_t  pointCursor (uint8_t col, uint8_t row, uint8_t chip=1);			//==Вычисление позиции курсора в памяти Lcd	
uint8_t  getLenBegin (uint8_t len,uint8_t src,char alig);					//==Возвращает кол-во свободных знаков  в начале поля;  
uint8_t  getLenEnd   (uint8_t len,uint8_t src,char alig);					//==Возвращает кол-во свободных знаков  в конце поля;
int32_t  floatToInt32(float val, uint8_t point);							//==Конвертор float в int32_t с умножением на кол-во знаков после точек;
char 	 getCharVal  (uint32_t val, uint8_t upper, char mode, uint8_t len, uint8_t n);//==Возвращает цифру(как символ) из val начиная со старшей позиции;
//------3.2  Перекодировка и пр.-----------------------------------------------------------------------------
uint8_t  getLenSTR        (String     &str,  uint8_t lenMax);				//==Возвращает len String(utf-8) с учетом блокирующего символа '~');
uint8_t  getLenPGM        (const char *text, uint8_t lenMax);				//==Возвращает len textPGM(utf-8) с учетом блокирующего символа '~');
uint8_t  getCodeCharLcdPGM(uint8_t code);									//==Возвращает код символа (из таблицы(PGM) перекодировки LCD);
uint8_t  getCharLcdSTR	  (String     &str,  uint8_t &num);					//==Возвращает следующий код(utf-8) из String;
uint8_t  getCharLcdPGM	  (const char *text, uint8_t &num);					//==Возвращает следующий код(utf-8) из PGM;
uint8_t  convert		  (uint8_t charH, uint8_t charL);					//==Получение номера символа из utf-8;
uint8_t  getPointFromChar (char val);										//==Получение цифрового значения кол-ва знаков после точки;
uint16_t CRC16_String	  (String &s);										//==Вычисление CRC16 переменной String (1 символ-12 мкс AVR328);
void	 setVarID	 	  (RT_HW_HD44780_VAL_ID &iv,char mode, int32_t val);//==Обработка численной переменной;
uint8_t  getLenMess  	  (RT_HW_HD44780_VAL_ID &iv);						//==Вычисление длины сообщения;
char     getSignBool 	  (uint8_t mode, bool v);							//==Возвращает символы для отображения коду (mode) набора;
//char     colsForSet  	  (uint8_t mode, uint8_t sz=16);					//==Возвращает кол-во колонок для настройки Lcd; 
//char     rowsForSet  	  (uint8_t mode, uint8_t sz=2);						//==Возвращает кол-во строк для настройки Lcd; 
//------3.3 Проверка на изменения значения с сохранением в буферe------------------------
bool     checkChangeV8    (uint8_t  &ago, int8_t  val) {if(ago!=(uint8_t)val) {ago=(uint8_t)val;  return 1;} return 0;}
bool     checkChangeV16   (uint16_t &ago, int16_t val) {if(ago!=(uint16_t)val){ago=(uint16_t)val; return 1;} return 0;}
bool     checkChangeV32   (int32_t  &ago, int32_t val) {if(ago!=val)          {ago=val;           return 1;} return 0;}
bool	 checkChangeStr   (String   &ago, String  val) {if(ago!=val)          {ago=val;           return 1;} return 0;}
bool     checkChangeFloat (int32_t  &ago, char mode, float val){int32_t buff=floatToInt32(val, getPointFromChar(mode));							
													    if(ago!=buff)         {ago=buff;          return 1;} return 0;}
//-------------------------------------------------------------------------------------------------
void 	createChar	(uint8_t location, uint8_t charmap[]);					//==Загрузка символа в CGRAM;
};//==============  Конец класса ==================================================================
extern RT_HW_HD44780 RT_HW_hd44780; //--Создание объекта LCD типа HD44780
#endif
//=================================================================================================