#include "RT_HW_BASE.h"	 




//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							ФУНКЦИИ ЗАПИСИ-ЧТЕНИЯ ПИНОВ
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
bool     RT_HW_BASE:: pinDigitalRead (RT_HW_PIN_DIR_ID &id, uint8_t pin, char mode){ 				//==Дискретный ввод->mode:I,U,D,F;
//--mode: 'U'- вход с подтяжкой к +Vcc; 'D' -вход с подтяжкой к +Gnd; 'I','F',любой другой символ - j, обычный вход;
//------------------------------------------------------------------------
if(id.dir==0){
	if(!checkPinPGM( RT_HW_PGM_PIN_DIN_ID,pin)) {id.dir=10;} 				//--Проверка на допустимость дискретного ввода;  
	else           { RT_HW_PIN_DIR_SET_ID(id,pin); 							//--Сохранение параметров пина;
		if     (mode=='I') {pinMode(pin, RT_HW_PIN_MODE_INPUT);}			//--Дискретный вход обычный;
		else if(mode=='U') {pinMode(pin, RT_HW_PIN_MODE_INPUT_PULLUP);}	//--Дискретный вход с подтяжкой к +Vcc;
		else if(mode=='D') {pinMode(pin, RT_HW_PIN_MODE_INPUT_PULLDOWN);}	//--Дискретный вход с подтяжкой к Gnd;
		else if(mode=='F') {pinMode(pin, RT_HW_PIN_MODE_INPUT);}			//--Дискретный вход - аналог INPUT; 
		else               {pinMode(pin, RT_HW_PIN_MODE_INPUT);}			//--Дискретный вход - аналог INPUT; 
												 id.dir=1;}}
//------------------------------------------------------------------------
if(id.dir==1) {return RT_HW_PIN_DIR_READ(id);} 
//------------------------------------------------------------------------
return 0;};	//+++END pinDigitalRead();
uint16_t RT_HW_BASE:: pinAnalogRead  (RT_HW_PIN_DIR_ID &id, uint8_t pin, char mode, uint16_t &ago){	//==Аналоговый ввод->mode:D,N,F;
// mode: 'D' -возвращает значение непосредственно с устройства ADC (с разрядностью ADC устройства);
//		 'N' -возвращает нормализованное до системной разрядности (device.sys.depth) значение с ADC;
//		 'F' -возвращает нормализованное до системной разрядности (device.sys.depth) значение с ADC
//			  с фильтрацией дрейфа показаний(device.adc.drift) и дрейфа нуля (device.adc.vNull);
//------------------------------------------------------------------------
if(id.dir==0){
	if(!checkPinPGM( RT_HW_PGM_PIN_ADC_ID,pin)) {id.dir=20;} 	//--Проверка на допустимость аналового ввода; 
	else           { RT_HW_PIN_DIR_SET_ID(id,pin); 										//--Сохранение параметров пина;			
	                 pinMode(id.pin, RT_HW_PIN_MODE_INPUT_ANALOG);						//--Настройка пина;
                                                  id.dir=1;}}
//------------------------------------------------------------------------
if(id.dir==1){
	uint16_t m16, dv; int32_t filter=0;	
	m16=maxBitDepth(device.depth.adc); 				//--Получение максимального значения для ADC 
	dv=analogRead(id.pin); 							//--Чтение значения ADC;
	if(dv>m16) {dv=m16;}							//--Ограничение показания ADC сверху;
	if     (mode=='D') {return dv;}					//--Возвращение значение ADC с устройства;
	else if(mode=='N') {return normADC(dv);}		//--Возвращает нормализованное значения ADC;	
	else if(mode=='F') {							//--Возвращает нормализованное значения ADC с корректировкой на параметры дрейфа;
						filter=makeDelta(ago, dv, device.depth.drift); //--Гистерезис
						if(filter>m16) {filter=m16;} 
						if(filter<device.depth.vNull) {filter=0;}
						ago=filter;
						return normADC(filter);}   
   else      			{return normADC(dv);}		//--Возвращает нормализованное значения ADC;	
}
//------------------------------------------------------------------------
return 0;};	//+++END pinAnalogRead(); 
uint16_t RT_HW_BASE:: pinTouchRead   (uint8_t pin, char mode){										//==Сенсорный ввод ->mode:D,N,F(ESP32);
#if defined(RT_HW_CORE_ESP32)
	if(!checkPinPGM(RT_HW_PGM_PIN_TCH_ID,pin)) {	//--Проверка на допустимость сенсорног ввода; 
	buff.vu16=touchRead(pin);
	if     (mode=='D') {return buff.vu16;}
	else if(mode=='N') {return buff.vu16;} 
	else if(mode=='F') {return buff.vu16;} 
	else               {return buff.vu16;} 
	}
#else
if(mode=='D') {buff.vu8=pin;} else {buff.vu8=0;} 	//--Для устранения предупреждений от C++;
#endif	
return 0;};	//+++END pinTouchRead();
int16_t  RT_HW_BASE:: pinReadHALL(char mode){														//==Ввод с датчика Холла (ESP32);
#if  defined(RT_HW_CORE_ESP32) && defined(RT_HW_PERMIT_HALL)										//--Разрешение работы с датчикаом Холла; 
int16_t buff=hallRead();
	if     (mode=='D') {return buff;} 
	else if(mode=='N') {return buff;} 
	else if(mode=='F') {return buff;} 
	else 			   {return buff;}
#else
buff.vu8=uint8_t(mode);	//--Для устранения предупреждений от C++;	
#endif	
return 0;};	//+++END pinReadHALL();
void     RT_HW_BASE:: pinDigitalWrite(RT_HW_PIN_DIR_ID &id, uint8_t pin, char mode, uint8_t val){	//==Дискретный вывод -> mode:N,O;
//-------------------------------------------------------------------------
if(id.dir==0){	
	if(!checkPinPGM( RT_HW_PGM_PIN_DOT_ID,pin)) {id.dir=40;}						//--Проверка на допустимость аналогово ввода; 
	else           { RT_HW_PIN_DIR_SET_ID(id,pin); 									//--Сохранение параметров пина (пин, регистр, доступ к биту в регистре и т.п.);
		if(mode=='O') {pinMode(pin, RT_HW_PIN_MODE_OUTPUT_OPEN_DRAIN);} 
		else          {pinMode(pin, RT_HW_PIN_MODE_OUTPUT);}
												 id.dir=1;}}
//------------------------------------------------------------------------
if(id.dir==1) { RT_HW_PIN_DIR_WRITE(id,val);}		//--Вывод на дискретный вывод через макрос;
//------------------------------------------------------------------------
};			//+++END pinDigitalWrite();	
uint16_t RT_HW_BASE:: pinAnalogWrite (RT_HW_PIN_DIR_ID &id, uint8_t pin, char mode, uint16_t freq, uint16_t val){ //==ШИМ вывод -> mode:N,O; (PWM);	
//------------------------------------------------------------------------
if(id.dir==0){
	if(!checkPinPGM( RT_HW_PGM_PIN_PWM_ID,pin)) {id.dir=50;}			//--Проверка на допустимость аналогово вывода (PWM); 
	else           { RT_HW_PIN_DIR_SET_ID(id,pin); 							//--Сохранение параметров пина;
//-----------------------------------------------
#if defined(RT_HW_CORE_ESP8266) 	
	//analogWriteFreq(constrain(freq, 100,10000)); 					//--Настройка частоты ШИМ;
	pinMode(id.pin,RT_HW_PIN_MODE_OUTPUT); 	
	buff.vu16=freq;	buff.vu8=(uint8_t)mode;	//--Для устранения предупреждений от C++;	
//-----------------------------------------------		
#elif  defined(RT_HW_CORE_ESP32) 
{int8_t buff=setFirstFreeBit   (device.pwm.channel);		//==Занимает первый свободный бит, возвращает его номер (0:15) или -1; 
 if(buff<0)	{id.dir=52; return 0;} 								//--Если все каналы заняты, выход по состоянию =52 (>50); 
 else       {id.num=buff;	
			 ledcSetup(id.num,constrain(freq,100,40000),device.depth.pwm);//--Настройка канала id.channel: частота и разрешение;
             ledcAttachPin(id.pin,id.num);}}			    	//--Настройка ШИМ ;
					buff.vu8=(uint8_t)mode;	//--Для устранения предупреждений от C++;	
//-----------------------------------------------
#elif defined(RT_HW_CORE_M_STM32F1) || defined(RT_HW_CORE_STM32F4) || defined(RT_HW_CORE_D_STM32)	
	if(mode=='O') {pinMode(id.pin, RT_HW_PIN_MODE_OUTPUT_PWM_OPEN_DRAIN);} 
	else          {pinMode(id.pin, RT_HW_PIN_MODE_OUTPUT_PWM);}	
	buff.vu16=freq;							//--Для устранения предупреждений от C++;	
//-----------------------------------------------
#else
	pinMode(id.pin,RT_HW_PIN_MODE_OUTPUT); 
	buff.vu16=freq;	buff.vu8=(uint8_t)mode;	//--Для устранения предупреждений от C++;	
#endif
												 id.dir=1;}} //--END if (id.dir==0){
//------------------------------------------------------------------------
if(id.dir==1){ uint16_t buff=normPWM(val);
//-----------------------------------------------	
#if  defined(RT_HW_CORE_ESP32) 
	ledcWrite(id.num,buff); 	return buff;	//--Вывод;
//-----------------------------------------------	
#elif  defined(RT_HW_CORE_M_STMF1) || defined(RT_HW_CORE_M_STM32F4)
	pwmWrite(id.pin,buff); 		return buff;	//--Вывод;	
//-----------------------------------------------	
#else
	analogWrite(id.pin,buff);	return buff;
//-----------------------------------------------	
#endif
//-----------------------------------------------	
              }	//--END if (id.dir==1)
return 0;} //+++END	pinAnalogWrite()
uint16_t RT_HW_BASE:: pinDAC		 (RT_HW_PIN_DIR_ID &id, uint8_t pin, uint16_t val){ 				//==Аналоговый вывод (DAC);
//------------------------------------------------------------------------
if(id.dir==0){
	buff.vu16=val;																//--Для устранения предупреждений от C++;
	if(!checkPinPGM( RT_HW_PGM_PIN_DAC_ID,pin))     {id.dir=60;}				//--Проверка на допустимость аналового ввода; 
    else           { RT_HW_PIN_DIR_SET_ID(id,pin);   id.dir=1; }} 				//--Сохранение параметров пина;   
//-----------------------------------------------
if(id.dir==1) {
#if defined(RT_HW_PERMIT_DAC)													//--Разрешение работы с DAC;	
//-----------------------------------------------
#if  defined(RT_HW_CORE_ESP32)  
	 uint16_t buff=normDAC(val); dacWrite(id.pin,buff);		return buff;
//-----------------------------------------------
#elif  defined(RT_HW_CORE_M_STM32F1) || defined(RT_HW_CORE_M_STM32F4) || defined(RT_HW_CORE_D_STM32)	 
     //uint16_t buff=normDAC(val); analogWrite(id.pin,buff); return buff;
	return 0;
//-----------------------------------------------
#else
	uint16_t buff=normDAC(val); analogWrite(id.pin,buff);	return buff;	
//-----------------------------------------------
#endif
//-----------------------------------------------
#endif
//-----------------------------------------------------------------------------
}  //--END if (id.dir==1)
//=============================================================================
return 0;};
bool     RT_HW_BASE:: changeProtectPinDI(RT_HW_CHANGE_PINDI_ID &id, uint8_t timeChange, uint8_t val){//==Защита от дребезга значения на пине DI;
if(id.dir==0) {if(id.ago!=val) {id.time=RT_HW_MILLIS; id.dir++;}                       return id.ago;}
if(id.dir==1) {if((getPastMs(id.time)< (timeChange)) && (id.ago==val))  	{id.dir=0; return id.ago;} 
				if( getPastMs(id.time)>= timeChange)     {id.ago=val;		 id.dir=0; return id.ago;}}
																					   return id.ago;};

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
