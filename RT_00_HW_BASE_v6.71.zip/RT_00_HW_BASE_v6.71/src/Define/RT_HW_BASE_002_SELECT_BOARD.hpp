//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//								1.Контроллеры программной среды AVR
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#if !defined(RT_HW_BOARD_CODE) 		&& defined(ARDUINO_AVR_UNO)					//====КОНТРОЛЛЕР Arduino Uno;	
#define      RT_HW_BOARD_CODE         RT_HW_CODE_BOARD_AVR_UNO				//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                      "Arduno Uno"				//--Наименование платы;
#define      RT_HW_BOARD_AVR_UNO											//--Идентификатор типа платы [variant.standart]
#define      RT_HW_CORE_AVR													//--Идентификатор программной среды
#endif
//---------------------------------------------------------------------------------------------------
#if !defined(RT_HW_BOARD_CODE)     	&& defined(ARDUINO_AVR_NANO) 				//====КОНТРОЛЛЕР Arduino Nano;	
#define      RT_HW_BOARD_CODE         RT_HW_CODE_BOARD_AVR_NANO			    //--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                     "Arduino Nano"     		//--Наименование платы;
#define      RT_HW_BOARD_AVR_NANO											//--Идентификатор типа платы [variant.eigthanaloginputs]
#define      RT_HW_CORE_AVR													//--Идентификатор программной среды
#endif
//---------------------------------------------------------------------------------------------------
#if !defined(RT_HW_BOARD_CODE)  	&& defined(ARDUINO_AVR_PRO) 				//====КОНТРОЛЛЕР Arduino Pro or Pro Mini;	
#define      RT_HW_BOARD_CODE         RT_HW_CODE_BOARD_AVR_PRO				//--Идентификатор типа выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME         "Arduino Pro or Pro mini"     		//--Наименование платы;
#define      RT_HW_BOARD_AVR_PRO											//--Идентификатор типа платы [variant.eigthanaloginputs]
#define      RT_HW_CORE_AVR													//--Идентификатор программной среды
#endif
//---------------------------------------------------------------------------------------------------
#if !defined(RT_HW_BOARD_CODE) 		&& defined(ARDUINO_AVR_MEGA2560) 			//====КОНТРОЛЛЕР Arduino Mega 2560;
#define      RT_HW_BOARD_CODE         RT_HW_CODE_BOARD_AVR_MEGA2560 		//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                    "Arduino Mega 2560"     	//--Наименование платы;
#define      RT_HW_BOARD_AVR_MEGA2560										//--Идентификатор типа платы [variant.mega]
#define      RT_HW_CORE_AVR													//--Идентификатор программной среды
#if defined(RT_HW_BOARD_Arduino_Mega2560)									//--Корректировка 
  #ifdef  PROGMEM															//		для Arduino Mega2560;	
  #undef  PROGMEM															//			атрибута
  #endif																	//				для работы
#define PROGMEM __attribute__(( section(".progmem.data") ))					// 					с PROGMEM для RAM>64kB;
#endif
#endif
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//								2.Контроллеры программной среды esp8266
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_ESP8266_GENERIC)				//====КОНТРОЛЛЕР Generic ESP8266 Module; 	
// В generic.variant определено толькo: A0=17;
enum {D0=16,D1=5, D2=4,D3=0, D4=2, D5=14, D6=12,D7=13,D8=15,D9=3,D10=1};	//--Дополнительное определение номеров пинов;
enum {RX=3, RX0=3,TX=1,TX0=1,TX1=2,RX2=13,TX2=15};							//--Дополнительное определение номеров пинов;
#define      RT_HW_BOARD_CODE          RT_HW_CODE_BOARD_ESP8266_GENERIC			//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME         "Generic ESP8266 Module"     		    //--Наименование платы;
#define      RT_HW_BOARD_ESP8266_GENERIC			//--Идентификатор типа платы [variant.generic]
#define      RT_HW_CORE_ESP													//--Идентификатор программной среды
#define      RT_HW_CORE_ESP8266												//--Идентификатор программной среды
#endif
//---------------------------------------------------------------------------------------------------
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_ESP8266_WEMOS_D1MINILITE)		//====КОНТРОЛЛЕР LOLIN(WEMOS) D1 Lite; 
// В d1_mini.variant определено толькo: D0=16,D1=5,D2=4,D3=0,D4=2,D5=14,D6=12,D7=13,D8=15,RX=3,TX=1;
enum {D9=3, D10=1,RX0=3,TX0=1,TX1=2,RX2=13,TX2=15};							//--Дополнительное определение номеров пинов;
#define      RT_HW_BOARD_CODE     RT_HW_CODE_BOARD_ESP8266_WEMOS_D1MINILITE	//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME         "LOLIN(WEMOS) D1 mini Lite"     	    //--Наименование платы;
#define      RT_HW_BOARD_ESP8266_WEMOS_D1MINILITE							//--Идентификатор типа платы [variant.d1_mini]
#define      RT_HW_CORE_ESP													//--Идентификатор программной среды
#define      RT_HW_CORE_ESP8266												//--Идентификатор программной среды
#endif
//---------------------------------------------------------------------------------------------------
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_ESP8266_WEMOS_D1MINIPRO)		//====КОНТРОЛЛЕР LOLIN(WEMOS) D1 Pro;
// В d1_mini.variant определено толькo: D0=16,D1=5,D2=4,D3=0,D4=2,D5=14,D6=12,D7=13,D8=15,RX=3,TX=1;
enum {D9=3, D10=1,RX0=3,TX0=1,TX1=2,RX2=13,TX2=15};							//--Дополнительное определение номеров пинов;
#define      RT_HW_BOARD_CODE    RT_HW_CODE_BOARD_ESP8266_WEMOS_D1MINIPRO	//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME         "LOLIN(WEMOS) D1 mini Pro"     		//--Наименование платы;
#define      RT_HW_BOARD_ESP8266_WEMOS_D1MINIPRO							//--Идентификатор типа платы [variant.d1_mini]
#define      RT_HW_CORE_ESP													//--Идентификатор программной среды
#define      RT_HW_CORE_ESP8266												//--Идентификатор программной среды
#endif
//---------------------------------------------------------------------------------------------------	
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_ESP8266_NODEMCU_ESP12) 		//====КОНТРОЛЛЕР NodeMCU 0.9 (ESP12 Module);	
// В nodemcu.variant определено толькo: D0=16,D1=5,D2=4,D3=0,D4=2,D5=14,D6=12,D7=13,D8=15,D9=3,D10=1;
enum {RX=3, TX=1,RX0=3,TX0=1,TX1=2,RX2=13,TX2=15};							//--Дополнительное определение номеров пинов;
#define      RT_HW_BOARD_CODE    RT_HW_CODE_BOARD_ESP8266_NODEMCU_ESP12		//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME    "NodeMCU 0.9 (ESP-12 Module)"     			//--Наименование платы;
#define      RT_HW_BOARD_ESP8266_NODEMCU_ESP12								//--Идентификатор типа платы [variant.d1_mini]
#define      RT_HW_CORE_ESP													//--Идентификатор программной среды
#define      RT_HW_CORE_ESP8266												//--Идентификатор программной среды
#endif
//---------------------------------------------------------------------------------------------------		
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_ESP8266_NODEMCU_ESP12E)		//====КОНТРОЛЛЕР NodeMCU 1.0 (ESP12E Module);	
// В nodemcu.variant определено толькo: D0=16,D1=5,D2=4,D3=0,D4=2,D5=14,D6=12,D7=13,D8=15,D9=3,D10=1;
enum {RX=3, TX=1,RX0=3,TX0=1,TX1=2,RX2=13,TX2=15};							//--Дополнительное определение номеров пинов;
#define      RT_HW_BOARD_CODE    RT_HW_CODE_BOARD_ESP8266_NODEMCU_ESP12E	//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME    "NodeMCU 1.0 (ESP-12E Module)"     	//--Наименование платы;
#define      RT_HW_BOARD_ESP8266_NODEMCU_ESP12E								//--Идентификатор типа платы [variant.d1_mini]
#define      RT_HW_CORE_ESP													//--Идентификатор программной среды
#define      RT_HW_CORE_ESP8266												//--Идентификатор программной среды
#endif	
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//								3.Контроллеры программной среды esp32
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_ESP32_DEV)					//====КОНТРОЛЛЕР ESP32 Dev Module;	
#define      RT_HW_BOARD_CODE          RT_HW_CODE_ESP32_DEV					//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                    "ESP32 Dev Module"     	//--Наименование платы;
#define      RT_HW_BOARD_ESP32_DEV											//--Идентификатор типа платы [variant.esp32]
#define      RT_HW_CORE_ESP													//--Идентификатор программной среды
#define      RT_HW_CORE_ESP32												//--Идентификатор программной среды
#endif
//---------------------------------------------------------------------------------------------------	
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_TTGO_T1)	 					//====КОНТРОЛЛЕР TTGO T-Display [подобранный аналог]
#define      RT_HW_BOARD_CODE          RT_HW_CODE_TTGO_T1					//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME         "TTGO T1-Display"     				//--Наименование платы;
#define      RT_HW_BOARD_TTGO_T1											//--Идентификатор типа платы [variant.ttgo-t1];
#define      RT_HW_CORE_ESP													//--Идентификатор программной среды
#define      RT_HW_CORE_ESP32												//--Идентификатор программной среды
#endif
//---------------------------------------------------------------------------------------------------
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_LOLIN_D32)					//====КОНТРОЛЛЕР LOLIN32;		
#define      RT_HW_BOARD_CODE          RT_HW_CODE_LOLIN_D32					//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                    "LOLIN D32"     			//--Наименование платы;
#define      RT_HW_BOARD_LOLIN_D32											//--Идентификатор типа платы [variant.d32
#define      RT_HW_CORE_ESP													//--Идентификатор программной среды
#define      RT_HW_CORE_ESP32												//--Идентификатор программной среды
#endif
//---------------------------------------------------------------------------------------------------
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_M5Stack_Core_ESP32) 			//====КОНТРОЛЛЕР M5Stack-Core-ESP32	
#define      RT_HW_BOARD_CODE          RT_HW_CODE_M5Stack_Core_ESP32		//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                    "M5Stack-Core-ESP32"     	//--Наименование платы;
#define      RT_HW_BOARD_M5Stack_Core_ESP32	 								//--Идентификатор типа платы [variant.m5_stack_core_esp32];
#define      RT_HW_CORE_ESP													//--Идентификатор программной среды
#define      RT_HW_CORE_ESP32												//--Идентификатор программной среды
#endif
//---------------------------------------------------------------------------------------------------
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_D1_MINI32) 					//====КОНТРОЛЛЕР WEMOS D1 MINI ESP32	
#define      RT_HW_BOARD_CODE          RT_HW_CODE_D1_MINI32					//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME          "WEMOS D1 MINI ESP32"     			//--Наименование платы;
#define      RT_HW_BOARD_D1_MINI32											//--Идентификатор типа платы [variant.d1_mini32];
#define      RT_HW_CORE_ESP													//--Идентификатор программной среды
#define      RT_HW_CORE_ESP32												//--Идентификатор программной среды
#endif
//---------------------------------------------------------------------------------------------------
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_ESP32C3_DEV)				//====КОНТРОЛЛЕР ESP32 Dev Module;	
#define      RT_HW_BOARD_CODE          RT_HW_CODE_ESP32C3_DEV				//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                    "ESP32C3 Dev Module"     	//--Наименование платы;
#define      RT_HW_BOARD_ESP32C3_DEV										//--Идентификатор типа платы [variant.esp32]
#define      RT_HW_CORE_ESP													//--Идентификатор программной среды
#define      RT_HW_CORE_ESP32												//--Идентификатор программной среды
#endif

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//								4.Контроллеры программной среды SAM
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_SAM_DUE) 						//====КОНТРОЛЛЕР Arduino DUE;	
#define      RT_HW_BOARD_CODE	       RT_HW_CODE_SAM_DUE					//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                "Arduino DUE"     				//--Наименование платы;
#define      RT_HW_BOARD_SAM_DUE											//--Идентификатор типа платы [aeduino_due_x.variant];
#define      RT_HW_CORE_SAM													//--Идентификатор программной среды
#endif
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//								5.Контроллеры программной среды SAMD
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_SAMD_ZERO)				//====КОНТРОЛЛЕР Arduino Zero;	 
//#define      RT_HW_BOARD_CODE          RT_HW_CODE_SAMD_ZERO					//--Идентификатор выбора платы c кодом платы;
//#define      RT_HW_BOARD_NAME                 "Arduino Zero"     			//--Наименование платы;
//#define      RT_HW_BOARD_SAMD_ZERO											//--Идентификатор типа платы [variant.XIAO_m0];
//#define      RT_HW_CORE_SAMD												//--Идентификатор программной среды
//#endif
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//								6.Контроллеры программной среды SEEED
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_SEEED_XIAO_M0)				//====КОНТРОЛЛЕР Seeeduino XIAO M0;	 
#define      RT_HW_BOARD_CODE          RT_HW_CODE_SEEED_XIAO_M0				//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                 "Seeeduno XIAO M0"     		//--Наименование платы;
#define      RT_HW_BOARD_SEEED_XIAO_M0										//--Идентификатор типа платы [variant.XIAO_m0];
#define      RT_HW_CORE_SEEED												//--Идентификатор программной среды
#endif
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//								7.Контроллеры программной среды NANO 33
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_NANO_RP2040_CONNECT) 			//====КОНТРОЛЛЕР Arduino Nano RP2040 Connect;	
#define      RT_HW_BOARD_NAME            "Arduino Nano RP2040 Connect"     	//--Наименование платы;
#define      RT_HW_BOARD_CODE	       RT_HW_CODE_NANO_RP2040_CONNECT		//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NANO_RP2040_CONNECT								//--Идентификатор типа платы [aeduino_due_x.variant];
#define      RT_HW_CORE_NANO_33												//--Идентификатор программной среды
#endif
//-------------------------------------------------------------------------------------------------
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_NANO_33_BLE) 					//====КОНТРОЛЛЕР Arduino Nano RP2040 Connect;	
#define      RT_HW_BOARD_CODE	       RT_HW_CODE_NANO_33_BLE				//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME            "Arduino Nano 33 BLE"     			//--Наименование платы;
#define      RT_HW_BOARD_NANO_33_BLE										//--Идентификатор типа платы [aeduino_due_x.variant];
#define      RT_HW_CORE_NANO_33												//--Идентификатор программной среды								//--Наименование архитектуры;
#endif
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//								8.Контроллеры программной среды RASPBERRIY PI
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_RASPBERRY_PI_PICO)			//====КОНТРОЛЛЕР Seeeduino XIAO M0;	 
#define      RT_HW_BOARD_CODE          RT_HW_CODE_RASPBERRY_PI_PICO			//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                    "Raspberry Pi Pico"     	//--Наименование платы;
#define      RT_HW_BOARD_RASPBERRY_PI_PICO									//--Идентификатор типа платы [variant.XIAO_m0];
#define      RT_HW_CORE_RASPBERRY_PI										//--Идентификатор программной среды
#endif
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//								9.Контроллеры программной среды PORTENTA H7(M7)
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_PORTENTA_H7)					//====КОНТРОЛЛЕР Portenta H7 ;	 
#define      RT_HW_BOARD_CODE          RT_HW_CODE_PORTENTA_H7				//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                    "Portenta H7"     			//--Наименование платы;
#define      RT_HW_BOARD_PORTENTA_H7										//--Идентификатор типа платы [variant.XIAO_m0];
#define      RT_HW_CORE_PORTENTA_H7											//--Идентификатор программной среды
#endif
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							 20.Контроллеры программной среды (M) STM32F1
//Generic STM32F103C6/fake STM32F103C8
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_GENERIC_STM32F103C)			//====КОНТРОЛЛЕР (M)Generic_STM32F103C_series;
#define      RT_HW_BOARD_CODE        RT_HW_CODE_M_GENERIC_STM32F103C        //--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                 "(M)Generic STM32F103C series"//--Наименование платы;
#define      RT_HW_BOARD_M_GENERIC_STM32F103C								//--Идентификатор типа платы [variant.generic_stm32f103c];
#define      RT_HW_CORE_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_M_STM32F1											//--Идентификатор программной среды
#endif
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_GENERIC_STM32F103R)			//====КОНТРОЛЛЕР (M)Generic_STM32F103R series;
#define      RT_HW_BOARD_CODE        RT_HW_CODE_M_GENERIC_STM32F103R        //--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                 "(M)Generic STM32F103R series"//--Наименование платы;
#define      RT_HW_BOARD_M_GENERIC_STM32F103R								//--Идентификатор типа платы [variant.generic_stm32f103r];
#define      RT_HW_CORE_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_M_STM32F1											//--Идентификатор программной среды
#endif
//-------------------------------------------------------------------------------------------------
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_GENERIC_STM32F103V)			//====КОНТРОЛЛЕР (M)Generic_STM32F103V series;
#define      RT_HW_BOARD_CODE        RT_HW_CODE_M_GENERIC_STM32F103V        //--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                 "(M)Generic STM32F103V series"//--Наименование платы;
#define      RT_HW_BOARD_M_GENERIC_STM32F103V								//--Идентификатор типа платы [variant.generic_stm32f103v];
#define      RT_HW_CORE_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_M_STM32F1											//--Идентификатор программной среды
#endif


//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							 21.Контролеры программной среды (M) STM32F4
// В ядре STM32-Master для контроллеров STM32F4 пока ограниченная поддержка контроллеров STM32F4
// Так STM32F407V нет поддержки WireSlave, Serialx.availableForWrite и др.
// Если ядро будет развиваться, в дальнейшем может быть добавлены необходимые функции
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_generic_f407v)				//====КОНТРОЛЛЕР (M)Generic_STM32F407V;	
#define      RT_HW_BOARD_CODE        RT_HW_CODE_M_generic_f407v        		//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME            "(M)Generic_STM32F407V"			//--Наименование платы;
#define      RT_HW_BOARD_M_generic_f407v  									//--Идентификатор типа платы [variant.generic_f407v];
#define      RT_HW_CORE_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_M_STM32F4											//--Идентификатор программной среды
#endif
//-------------------------------------------------------------------------------------------------
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_blackpill_f401)				//====КОНТРОЛЛЕР (M)BlackPill F401CCU6		
#define      RT_HW_BOARD_CODE        RT_HW_CODE_M_blackpill_f401        	//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                 "(M)BlackPill F401CCU6"		//--Наименование платы;
#define      RT_HW_BOARD_M_blackpill_f401  									//--Идентификатор типа платы [variant.blackpill_f401];
#define      RT_HW_CORE_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_M_STM32F4											//--Идентификатор программной среды
#endif
//-------------------------------------------------------------------------------------------------
#if !defined(RT_HW_BOARD_CODE) && (defined(ARDUINO_disco_f411))					//====КОНТРОЛЛЕР (M)BlackPill F401CCU6		
#define      RT_HW_BOARD_CODE        RT_HW_CODE_M_disco_f411       			//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME             "(M)BlackPill F411CE"				//--Наименование платы;
#define      RT_HW_BOARD_M_disco_f411 										//--Идентификатор типа платы [variant.disco_f411];
#define      RT_HW_CORE_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_M_STM32F4											//--Идентификатор программной среды
#endif
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							 22.Контроллеры программной среды (D) STM32F1
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_BLUEPILL_F103C8) 				//====КОНТРОЛЛЕР (D)BluePill F103C8	 					  
#define      RT_HW_BOARD_CODE        RT_HW_CODE_D_BLUEPILL_F103C8       	//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                 "(D)BluePill F103C8"			//--Наименование платы;
#define      RT_HW_BOARD_D_BLUEPILL_F103C8 									//--Идентификатор типа платы [variant.PILL_F103XX];
#define      RT_HW_CORE_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32F1											//--Идентификатор программной среды
#endif
//-------------------------------------------------------------------------------------------------
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_BLUEPILL_F103CB) 				//====КОНТРОЛЛЕР (D)BluePill F103CB	 					  
#define      RT_HW_BOARD_CODE        RT_HW_CODE_D_BLUEPILL_F103CB       	//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                 "(D)BluePill F103CB"			//--Наименование платы;
#define      RT_HW_BOARD_D_BLUEPILL_F103CB 									//--Идентификатор типа платы [variant.PILL_F103XX];
#define      RT_HW_CORE_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32F1											//--Идентификатор программной среды
#endif
//-------------------------------------------------------------------------------------------------
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_BLACKPILL_F103C8) 			//====КОНТРОЛЛЕР (D)BlackPill F103C8	 					  
#define      RT_HW_BOARD_CODE        RT_HW_CODE_D_BLACKPILL_F103C8       	//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                 "(D)BlackPill F103C8"			//--Наименование платы;
#define      RT_HW_BOARD_D_BLACKPILL_F103C8 								//--Идентификатор типа платы [variant.PILL_F103XX];
#define      RT_HW_CORE_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32F1											//--Идентификатор программной среды
#endif
//-------------------------------------------------------------------------------------------------
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_BLACKPILL_F103CB) 			//====КОНТРОЛЛЕР (D)BlackPill F103CB	 					  
#define      RT_HW_BOARD_CODE        RT_HW_CODE_D_BLACKPILL_F103CB       	//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                 "(D)BlackPill F103CB"			//--Наименование платы;
#define      RT_HW_BOARD_D_BLACKPILL_F103CB 								//--Идентификатор типа платы [variant.PILL_F103XX];
#define      RT_HW_CORE_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32F1											//--Идентификатор программной среды
#endif
//-------------------------------------------------------------------------------------------------
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_GENERIC_F103CBTX) 			//====КОНТРОЛЛЕР (D)Generic F103CBTx	 					  
#define      RT_HW_BOARD_CODE        RT_HW_CODE_D_GENERIC_F103CBTX       	//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                 "(D)Generic F103CBTx"			//--Наименование платы;
#define      RT_HW_BOARD_D_GENERIC_F103CBTX 								//--Идентификатор типа платы [variant.STM32F1(xxx/F10CB(T-U)];
#define      RT_HW_CORE_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32F1											//--Идентификатор программной среды
#endif
//-------------------------------------------------------------------------------------------------
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_GENERIC_F103RETX) 			//====КОНТРОЛЛЕР (D)Generic F103RETx	 					  
#define      RT_HW_BOARD_CODE        RT_HW_CODE_D_GENERIC_F103RETX       	//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                 "(D)Generic F103RETx"			//--Наименование платы;
#define      RT_HW_BOARD_D_GENERIC_F103RETX 								//--Идентификатор типа платы [variant.STM32F1(xxx/F103R(C-D-E)Y)];
#define      RT_HW_CORE_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32F1											//--Идентификатор программной среды
#endif
//-------------------------------------------------------------------------------------------------
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_GENERIC_F103VETX) 			//====КОНТРОЛЛЕР (D)Generic F103VETx	 					  
#define      RT_HW_BOARD_CODE        RT_HW_CODE_D_GENERIC_F103VETX       	//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                 "(D)Generic F103VETx"			//--Наименование платы;
#define      RT_HW_BOARD_D_GENERIC_F103VETX 								//--Идентификатор типа платы [variant.STM32F1(xxx/F103V(C-D-E)H-T)];
#define      RT_HW_CORE_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32F1											//--Идентификатор программной среды
#endif
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							 32.Контроллеры программной среды (D) STM32F4
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_BLACK_F407VE)					//====КОНТРОЛЛЕР (D)Black F407VE	
#define      RT_HW_BOARD_CODE        RT_HW_CODE_D_BLACK_F407VE      		//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                 "(D)Black F407VE"				//--Наименование платы;
#define      RT_HW_BOARD_D_BLACK_F407VE 									//--Идентификатор типа платы [variant.variant_BLACK_F407VX];
#define      RT_HW_CORE_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32F4											//--Идентификатор программной среды
#endif
//-------------------------------------------------------------------------------------------------
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_BLACK_F407VG)     			//====КОНТРОЛЛЕР (D)Black F407VG	
#define      RT_HW_BOARD_CODE        RT_HW_CODE_D_BLACK_F407VG      		//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                 "(D)Black F407VG"				//--Наименование платы;
#define      RT_HW_BOARD_D_BLACK_F407VG 									//--Идентификатор типа платы [variant.variant_BLACK_F407VX];
#define      RT_HW_CORE_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32F4											//--Идентификатор программной среды
#endif
//-------------------------------------------------------------------------------------------------
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_GENERIC_F407VETX)      		//====КОНТРОЛЛЕР (D)Generic F407VETx	
#define      RT_HW_BOARD_CODE        RT_HW_CODE_D_GENERIC_F407VETX       	//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                 "(D)Generic F407VETx"			//--Наименование платы;
#define      RT_HW_BOARD_D_GENERIC_F407VETX  								//--Идентификатор типа платы [variant.STM32F4xx/F407];
#define      RT_HW_CORE_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32F4											//--Идентификатор программной среды
#endif
//-------------------------------------------------------------------------------------------------
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_GENERIC_F407VGTX)      		//====КОНТРОЛЛЕР (D)Generic F407VETx	
#define      RT_HW_BOARD_CODE        RT_HW_CODE_D_GENERIC_F407VGTX       	//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                 "(D)Generic F407VGTx"			//--Наименование платы;
#define      RT_HW_BOARD_D_GENERIC_F407VGTX  								//--Идентификатор типа платы [variant.STM32F4xx/F407];
#define      RT_HW_CORE_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32F4											//--Идентификатор программной среды
#endif
//-------------------------------------------------------------------------------------------------
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_BLACKPILL_F401CC)      		//====КОНТРОЛЛЕР (D)BlackPill F401CC	
#define      RT_HW_BOARD_CODE        RT_HW_CODE_D_BLACKPILL_F401CC        	//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                 "(D)BlackPill F401CC"			//--Наименование платы;
#define      RT_HW_BOARD_D_BLACKPILL_F401CC  								//--Идентификатор типа платы [variant.STM32F4xx/_F401C];
#define      RT_HW_CORE_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32F4											//--Идентификатор программной среды
#endif
//-------------------------------------------------------------------------------------------------
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_BLACKPILL_F411CE)      		//====КОНТРОЛЛЕР (D)BlackPill F411CE	
#define      RT_HW_BOARD_CODE        RT_HW_CODE_D_BLACKPILL_F411CE        	//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                 "(D)BlackPill F411CE"			//--Наименование платы;
#define      RT_HW_BOARD_D_BLACKPILL_F411CE  								//--Идентификатор типа платы [variant.STM32F4xx/_F411C];
#define      RT_HW_CORE_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32F4											//--Идентификатор программной среды
#endif
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							 10.Контроллеры программной среды STM32duino (H7)
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#if !defined(RT_HW_BOARD_CODE) && defined(ARDUINO_GENERIC_H743_VITX)			//====КОНТРОЛЛЕР (D)Generic H743VITX	
#define      RT_HW_BOARD_CODE        RT_HW_CODE_D_GENERIC_H743_VITX         //--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME                 "(D)Generic H743 VITX"			//--Наименование платы;
#define      RT_HW_BOARD_D_GENERIC_H743_VITX  								//--Идентификатор типа платы [variant.STM32H7xx];
#define      RT_HW_CORE_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32												//--Идентификатор программной среды
#define      RT_HW_CORE_D_STM32H7											//--Идентификатор программной среды
#endif
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							90.Контроллеры с не опознанной программной средой 
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#if !defined(RT_HW_BOARD_CODE)  												//====КОНТРОЛЛЕР неопознанный
#define      RT_HW_BOARD_CODE       RT_HW_CODE_BOARD_ANON        			//--Идентификатор выбора платы c кодом платы;
#define      RT_HW_BOARD_NAME      "ANON"									//--Наименование платы;
#define      RT_HW_BOARD_ANON  												//--Идентификатор типа платы [variant.STM32H7xx];
#define      RT_HW_CORE_ANON												//--Идентификатор программной среды
#endif
//-------------------------------------------------------------------------------------------------

//=================================================================================================