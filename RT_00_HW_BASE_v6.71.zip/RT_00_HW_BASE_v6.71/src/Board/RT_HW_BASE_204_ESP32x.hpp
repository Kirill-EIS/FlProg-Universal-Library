//*************************************************************************************************
//							1.Контроллер типа ESP32C3 Dev module [esp32.variant]
//*************************************************************************************************

#if !defined(RT_HW_BOARD_SELECT)  && defined(RT_HW_BOARD_ESP32C3_DEVK)
#define      RT_HW_BOARD_SELECT 			"BOARD ESP32C3 Dev"		//--Идентификатор выбора платы;
//-------------------------------------------------------------------------------------------------
#define RT_HW_BOARD_MEMORY  "FLASH=1310Kb; RAM=328Kb; Ext_FLASH=4/16Mb;"	//--Параметры памяти;												
#define RT_HW_PERMIT_UART0													//--Разрешение работы с UART0; 
#define RT_HW_PERMIT_I2C0													//--Разрешение работы с i2c0; 
#define RT_HW_PERMIT_SPI0													//--Разрешение работы с spi0 (clk=18,miso=19,mosi=23,cs=5);  
//#define RT_HW_PERMIT_HALL													//--Разрешение работы с датчикаом Холла; 
//------Системные пины------------------------------------------------------------------------------
enum   {RT_HW_BOARD_CONTROL=10, RT_HW_BOARD_LED=1, RT_HW_BOARD_BUTTON=25};	//--Пины контроль,led,кнопка;
//------Параметры контроллера общие-------------------------------------------------------------------	
enum   {RT_HW_PIN_QNT_MAX=22,	RT_HW_FCPU=240, 	RT_HW_VCC=3300}; 
//-----Параметры UART------------------------------------------------------------------------------	
enum   {RT_HW_UART0_RX=20,   RT_HW_UART0_TX=21};
//-----Параметры I2C------------------------------------------------------------------------------	
enum   {RT_HW_I2C0_SDA=8,  RT_HW_I2C0_SCL=9};  	
//-----Параметры SPI------------------------------------------------------------------------------	
enum   {RT_HW_SPI0_SCK=4,  RT_HW_SPI0_MISO=5,  RT_HW_SPI0_MOSI=6};
//-----Системные параметры-------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_SYS_PAR[]  	={12,			   	RT_HW_PGM_END};  //--SYS->depth;
const uint8_t PROGMEM RT_HW_PGM_SYS_PIN[]  	={RT_HW_BOARD_CONTROL, RT_HW_BOARD_LED, RT_HW_BOARD_BUTTON, RT_HW_PGM_END}; 
const uint8_t PROGMEM RT_HW_PGM_SYS_ADC[]  	={12,20,9,			RT_HW_PGM_END};  //--ADC->depth,drift,null;
const uint8_t PROGMEM RT_HW_PGM_SYS_TCH[]  	={8,  				RT_HW_PGM_END};  //--TCH->depth,drift,null; 
const uint8_t PROGMEM RT_HW_PGM_SYS_PWM[]  	={12,10,			RT_HW_PGM_END};  //--PWM->depth,freq; 
const uint8_t PROGMEM RT_HW_PGM_SYS_DAC[]  	={8,				RT_HW_PGM_END};  //--DAC->depth; 
//-----Системные пины и параметры коммуникаций------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_I2C[] 	={RT_HW_I2C0_SDA, RT_HW_I2C0_SCL,  RT_HW_PGM_END}; 
const uint8_t PROGMEM RT_HW_PGM_PIN_SPI[] 	={RT_HW_SPI0_SCK, RT_HW_SPI0_MISO, RT_HW_SPI0_MOSI, RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_UHS[] 	={RT_HW_UART0_RX, RT_HW_UART0_TX,  RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_USS[] 	={				 				   RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_CAN[] 	={				 		    		RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_BTH[] 	={'B','L','E',				 		RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_ETH[] 	={  								RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_WFI[] 	={192,  							RT_HW_PGM_END};
//-----Доступные пины контроллера------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_ALL[] 	={ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,18,19,20,21,RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DIN[] 	={ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,18,19,20,21,RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_ADC[] 	={ 0, 1, 2, 3, 4, 5, 	  		  			   RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_TCH[] 	={ 						  					   RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DOT[] 	={ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,18,19,20,21,RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_PWM[] 	={ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,18,19,20,21,RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DAC[] 	=  									   		   RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_INT[] 	={ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,18,19,20,21,RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_N5V[] 	={ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,18,19,20,21,RT_HW_PGM_END};
//-----Тестовые пины и адреса------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_DBG[]  	={					RT_HW_PGM_END};	// debug1,debug2,debug3,timeDebug;	
const uint8_t PROGMEM RT_HW_PGM_PIN_OUT[] 	={1,				RT_HW_PGM_END};	// PWM0, PWM1, LED1,LED2;
const uint8_t PROGMEM RT_HW_PGM_PIN_INP[] 	={0,				RT_HW_PGM_END};	// A0,A1,btn1,btn2;
const uint8_t PROGMEM RT_HW_PGM_PIN_DCT[] 	={    				RT_HW_PGM_END};	// DAC0,DAC1,TCH0;
const uint8_t PROGMEM RT_HW_PGM_PIN_DEV[] 	={2, 	 			RT_HW_PGM_END};	// DS1820,DHT22,HC-SR04
const uint8_t PROGMEM RT_HW_PGM_PIN_CSS[] 	={7, 	    		RT_HW_PGM_END};	// CS SPI:595,LCD,NRF,DEVl 	
const uint8_t PROGMEM RT_HW_PGM_PIN_LC6[]  	={					RT_HW_PGM_END};	// Пины для подключения LCD по 4-х битной шине;
const uint8_t PROGMEM RT_HW_PGM_PIN_TFT[]  	={               	RT_HW_PGM_END};	// Пины(дополнительные[]  TFT дисплея(SPI[] -CS,R/S,LED,RST,TOUCH;
const uint8_t PROGMEM RT_HW_PGM_PIN_SSP[]	={					RT_HW_PGM_END};	// Пины программного SPI: clk,miso,mosi,cs;	
const uint8_t PROGMEM RT_HW_PGM_ADR_I2C[]  	={39,62,32,33,		RT_HW_PGM_END};	// lcd1,lcd2,mcp1,mcp2;
//-------------------------------------------------------------------------------------------------
#endif

