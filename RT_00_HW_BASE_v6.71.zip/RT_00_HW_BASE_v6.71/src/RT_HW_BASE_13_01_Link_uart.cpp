#include "RT_HW_BASE.h"	 
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//			14.0. Создание объекта для программного UART 
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
#if defined(RT_HW_PERMIT_UARTS)
SoftwareSerial SerialS(RT_HW_UARTS_RX, RT_HW_UARTS_TX);
#endif
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// 				1. Определение дополнительных UART для STM32duino
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//#if defined(RT_HW_ARCH_STM32DUINO)
#if defined(RT_HW_PERMIT_UART2) && defined(RT_HW_CORE_D_STM32)
HardwareSerial  Serial2(RT_HW_UART2_RX,RT_HW_UART2_TX);
#endif
#if defined(RT_HW_PERMIT_UART3) && defined(RT_HW_CORE_D_STM32)
HardwareSerial  Serial3(RT_HW_UART3_RX,RT_HW_UART3_TX);
#endif
#if defined(RT_HW_PERMIT_UART4) && defined(RT_HW_CORE_D_STM32)
HardwareSerial  Serial4(RT_HW_UART4_RX,RT_HW_UART4_TX);
#endif
#if defined(RT_HW_PERMIT_UART5) && defined(RT_HW_CORE_D_STM32)
HardwareSerial  Serial5(RT_HW_UART5_RX,RT_HW_UART5_TX);
#endif
#if defined(RT_HW_PERMIT_UART6) && defined(RT_HW_CORE_D_STM32)
HardwareSerial  Serial6(RT_HW_UART6_RX,RT_HW_UART6_TX);
#endif
#if defined(RT_HW_PERMIT_UART7) && defined(RT_HW_CORE_D_STM32)
HardwareSerial  Serial7(RT_HW_UART7_RX,RT_HW_UART7_TX);
#endif
#if defined(RT_HW_PERMIT_UART8) && defined(RT_HW_CORE_D_STM32)
HardwareSerial  Serial8(RT_HW_UART8_RX,RT_HW_UART8_TX);
#endif
//-------------------------------------------------------------------

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//			14.1. Контроль наличия UART в контроллере по его номеру 
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
bool RT_HW_BASE:: uartCheckNum(uint8_t num){
//-----------------
#if defined(RT_HW_PERMIT_UART0)
if(num==0){return 1;}
#endif
#if defined(RT_HW_PERMIT_UART1)
if(num==1){return 1;}
#endif
#if defined(RT_HW_PERMIT_UART2)
if(num==2){return 1;}
#endif
#if defined(RT_HW_PERMIT_UART3)
if(num==3){return 1;}
#endif
#if defined(RT_HW_PERMIT_UART4)
if(num==4){return 1;}
#endif
#if defined(RT_HW_PERMIT_UART5)
if(num==5){return 1;}
#endif
#if defined(RT_HW_PERMIT_UART6)
if(num==6){return 1;}
#endif
#if defined(RT_HW_PERMIT_UART7)
if(num==7){return 1;}
#endif
#if defined(RT_HW_PERMIT_UART8)
if(num==8){return 1;}
#endif
#if defined(RT_HW_PERMIT_UARTS)
if(num==9){return 1;}
#endif
return 0;};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//			14.2. Функция uartBegin(n,speed)
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
void  RT_HW_BASE:: uartBegin (uint8_t n, uint32_t speed){
#if defined(RT_HW_PERMIT_UART0)
if(n==0){if(!bitRead(device.uart.begin,n)) {bitSet(device.uart.begin,n); Serial.begin(speed);}}
#endif	
#if	defined(RT_HW_PERMIT_UART1)
if(n==1){if(!bitRead(device.uart.begin,n)) {bitSet(device.uart.begin,n); Serial1.begin(speed);}}
#endif		
#if	defined(RT_HW_PERMIT_UART2)
if(n==2){if(!bitRead(device.uart.begin,n)) {bitSet(device.uart.begin,n); Serial2.begin(speed);}}
#endif	
#if	defined(RT_HW_PERMIT_UART3)
if(n==3){if(!bitRead(device.uart.begin,n)) {bitSet(device.uart.begin,n); Serial3.begin(speed);}}
#endif
#if defined(RT_HW_PERMIT_UART4)
if(n==4){if(!bitRead(device.uart.begin,n)) {bitSet(device.uart.begin,n); Serial4.begin(speed);}}
#endif	
#if defined(RT_HW_PERMIT_UART5)
if(n==5){if(!bitRead(device.uart.begin,n)) {bitSet(device.uart.begin,n); Serial5.begin(speed);}}
#endif
#if defined(RT_HW_PERMIT_UART6)
if(n==6){if(!bitRead(device.uart.begin,n)) {bitSet(device.uart.begin,n); Serial6.begin(speed);}}
#endif
#if defined(RT_HW_PERMIT_UART7)
if(n==7){if(!bitRead(device.uart.begin,n)) {bitSet(device.uart.begin,n); Serial7.begin(speed);}}
#endif
#if defined(RT_HW_PERMIT_UART8)
if(n==8){if(!bitRead(device.uart.begin,n)) {bitSet(device.uart.begin,n); Serial8.begin(speed);}}
#endif
#if defined(RT_HW_PERMIT_UARTS)
if(n==9){if(!bitRead(device.uart.begin,n)) {bitSet(device.uart.begin,n); SerialS.begin(speed);}}
#endif			
}	
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//			14.3. uartSerial(n) проверка подключения устройства.
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
bool  RT_HW_BASE:: uartSerial (uint8_t n){
//--Проверка с учетом особенностей STM32 в среде STM32duino, SEEEDUINO
#ifdef RT_HW_PERMIT_UART0
if(n==0){
//--------Для программной среды STM32duino---------------------------------------------------------
#if defined(RT_HW_CORE_D_STM32) && defined (USBCON) && defined(USBD_USE_CDC) 
if(device.uart.dir0==4) {return 1;}
if(device.uart.dir0==0) {device.uart.timeStart=RT_HW_MILLIS+500; device.uart.dir0++; return 0;}
if(device.uart.dir0==1) {if(RT_HW_MILLIS<(device.uart.timeStart)) {return 0;} 
						 if(CDC_connected()){device.uart.timeStart=RT_HW_MILLIS+20;  device.uart.dir0++; return 1;}
                                             device.uart.timeStart=RT_HW_MILLIS+500;                     return 0;}
if(device.uart.dir0==2)	{if(RT_HW_MILLIS<device.uart.timeStart)          {return 0;}
						 bitSet(device.uart.ready,0); device.uart.dir0=4; return 1;} 
//--------Для программной среды Seeeduino---------------------------------------------------------
/*
#elif defined(RT_HW_CORE_SEEED)
if(device.uart.dir0==10){return 1;}
if(device.uart.dir0==0) {             device.uart.timeStart=millis();                                 device.uart.dir0++;  return 0;}
if(device.uart.dir0==1) {if(getPastMs(device.uart.timeStart)>1500)   {device.uart.timeStart=millis(); device.uart.dir0++;} return 0;}
if(device.uart.dir0==2) {if(getPastMs(device.uart.timeStart)> 500)                                   {device.uart.dir0++;} return 0;}
if(device.uart.dir0==3)	{device.uart.timeStart=millis(); 
						  //if(!Serial.dtr()){device.uart.dir0=2;} 						 
						 if(!Serial){device.uart.dir0=2;} 
						 else {device.uart.dir0++;} return 0;}
if(device.uart.dir0==4) {if(getPastMs(device.uart.timeStart) >20) {bitSet(device.uart.ready,0); device.uart.dir0=10;}      return 0;}			 
*/
#else	
//--------Для других программных среды (avr,esp8266,esp32,sam,STM32master_F1,STM32master_F4------	
if(Serial) {bitSet(device.uart.ready,n); return 1;} else {return 0;}
#endif
//-----------------------------------------------------------------------------------------------
}
#endif
//------------------------------------------------------------------------------
#if defined(RT_HW_PERMIT_UART1)
if(n==1){if(Serial1){bitSet(device.uart.ready,n); return 1;}}
#endif		
#if defined(RT_HW_PERMIT_UART2)
if(n==2){if(Serial2){bitSet(device.uart.ready,n); return 1;}}
#endif	
#if defined(RT_HW_PERMIT_UART3)
if(n==3){if(Serial3){bitSet(device.uart.ready,n); return 1;}}
#endif
#if defined(RT_HW_PERMIT_UART4)
if(n==4){if(Serial4){bitSet(device.uart.ready,n); return 1;}}
#endif	
#if defined(RT_HW_PERMIT_UART5)
if(n==5){if(Serial5){bitSet(device.uart.ready,n); return 1;}}
#endif
#if defined(RT_HW_PERMIT_UART6)
if(n==6){if(Serial6){bitSet(device.uart.ready,n); return 1;}}
#endif
#if defined(RT_HW_PERMIT_UART7)
if(n==7){if(Serial7){bitSet(device.uart.ready,n); return 1;}}
#endif
#if defined(RT_HW_PERMIT_UART8)
if(n==8){if(Serial8){bitSet(device.uart.ready,n); return 1;}}
#endif
#if defined(RT_HW_PERMIT_UARTS)
if(n==9){if(SerialS){bitSet(device.uart.ready,n); return 1;}}
#endif	
return 0;	
};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//			14.4. uartAvaible(n)
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
uint8_t  RT_HW_BASE:: uartAvailable(uint8_t n){
#if defined(RT_HW_PERMIT_UART0)
if(n==0){return Serial.available();}
#endif	
#if defined(RT_HW_PERMIT_UART1) && !defined(RT_HW_BLOCK_UART1_READ) //---У ESP8266 Serail1 работает только на выход;
if(n==1){return Serial1.available();}
#endif		
#if defined(RT_HW_PERMIT_UART2)
if(n==2){return Serial2.available();}
#endif	
#if defined(RT_HW_PERMIT_UART3)
if(n==3){return Serial3.available();}
#endif
#if defined(RT_HW_PERMIT_UART4)
if(n==4){return Serial4.available();}
#endif	
#if defined(RT_HW_PERMIT_UART5)
if(n==5){return Serial5.available();}
#endif
#if defined(RT_HW_PERMIT_UART6)
if(n==6){return Serial6.available();}
#endif
#if defined(RT_HW_PERMIT_UART7)
if(n==7){return Serial7.available();}
#endif
#if defined(RT_HW_PERMIT_UART8)
if(n==8){return Serial8.available();}
#endif
#if defined(RT_HW_PERMIT_UARTS)
if(n==9){return SerialS.available();}
#endif	
return 	0;	
};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//			14.5. uartAvaibleForWrite(n)
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
uint8_t  RT_HW_BASE:: uartAvailableForWrite(uint8_t n){
#if !defined(RT_HW_BLOCK_AVAILABLE_FOR_WRITE) 	//--Не везде присутсвует функция Serial.availableForWrite();													
#if defined(RT_HW_PERMIT_UART0)
if(n==0){return Serial.availableForWrite();}
#endif	
#if defined(RT_HW_PERMIT_UART1)
if(n==1){return Serial1.availableForWrite();}
#endif		
#if defined(RT_HW_PERMIT_UART2)
if(n==2){return Serial2.availableForWrite();}
#endif	
#if defined(RT_HW_PERMIT_UART3)
if(n==3){return Serial3.availableForWrite();}
#endif
#if defined(RT_HW_PERMIT_UART4)
if(n==4){return Serial4.availableForWrite();}
#endif	
#if defined(RT_HW_PERMIT_UART5)
if(n==5){return Serial5.availableForWrite();}
#endif
#if defined(RT_HW_PERMIT_UART6)
if(n==6){return Serial6.availableForWrite();}
#endif
#if defined(RT_HW_PERMIT_UART7)
if(n==7){return Serial7.availableForWrite();}
#endif
#if defined(RT_HW_PERMIT_UART8)
if(n==8){return Serial8.availableForWrite();}
#endif
#if defined(RT_HW_PERMIT_UARTS)
if(n==9){return SerialS.availableForWrite();}
#endif
//---------------------------------------------------------
#else
RT_HW_Base.buff.vu8=n;	//--Для устранения предупреждений от C++;
return 63;	
#endif		//--#if !defined(RT_HW_BLOCK_AVAILABLE_FOR_WRITE) 
return 	63;};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//			14.6. uartRead(n)
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
uint8_t RT_HW_BASE:: uartRead(uint8_t n){
#if defined(RT_HW_PERMIT_UART0)
if(n==0){return Serial.read();}
#endif	
#if defined(RT_HW_PERMIT_UART1) && !defined(RT_HW_BLOCK_UART1_READ) //---У ESP8266 Serail1 работает только на выход;
if(n==1){return Serial1.read();}
#endif		
#if defined(RT_HW_PERMIT_UART2) 
if(n==2){return Serial2.read();}
#endif	
#if defined(RT_HW_PERMIT_UART3)
if(n==3){return Serial3.read();}
#endif
#if defined(RT_HW_PERMIT_UART4)
if(n==4){return Serial4.read();}
#endif	
#if defined(RT_HW_PERMIT_UART5)
if(n==5){return Serial5.read();}
#endif
#if defined(RT_HW_PERMIT_UART6)
if(n==6){return Serial6.read();}
#endif
#if defined(RT_HW_PERMIT_UART7)
if(n==7){return Serial7.read();}
#endif
#if defined(RT_HW_PERMIT_UART8)
if(n==8){return Serial8.read();}
#endif
#if defined(RT_HW_PERMIT_UARTS)
if(n==9){return SerialS.read();}
#endif	
return 	0;	
};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//			14.7. uartWrite(n,val)
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
void RT_HW_BASE:: uartWrite(uint8_t n, uint8_t val){
#if defined(RT_HW_PERMIT_UART0)
if(n==0){Serial.write(val);}
#endif	
#if defined(RT_HW_PERMIT_UART1)
if(n==1){Serial1.write(val);}
#endif		
#if defined(RT_HW_PERMIT_UART2)
if(n==2){Serial2.write(val);}
#endif	
#if defined(RT_HW_PERMIT_UART3)
if(n==3){Serial3.write(val);}
#endif
#if defined(RT_HW_PERMIT_UART4)
if(n==4){Serial4.write(val);}
#endif	
#if defined(RT_HW_PERMIT_UART5)
if(n==5){Serial5.write(val);}
#endif
#if defined(RT_HW_PERMIT_UART6)
if(n==6){Serial6.write(val);}
#endif
#if defined(RT_HW_PERMIT_UART7)
if(n==7){Serial7.write(val);}
#endif
#if defined(RT_HW_PERMIT_UART8)
if(n==8){Serial8.write(val);}
#endif
#if defined(RT_HW_PERMIT_UARTS)
if(n==9){SerialS.write(val);}
#endif		
};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//			14.78 uartPrint(n,str)
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
void RT_HW_BASE:: uartPrint(uint8_t n, String str){
#if defined(RT_HW_PERMIT_UART0)
if(n==0){Serial.print(str);}
#endif	
#if defined(RT_HW_PERMIT_UART1)
if(n==1){Serial1.print(str);}
#endif		
#if defined(RT_HW_PERMIT_UART2)
if(n==2){Serial2.print(str);}
#endif	
#if defined(RT_HW_PERMIT_UART3)
if(n==3){Serial3.print(str);}
#endif
#if defined(RT_HW_PERMIT_UART4)
if(n==4){Serial4.print(str);}
#endif	
#if defined(RT_HW_PERMIT_UART5)
if(n==5){Serial5.print(str);}
#endif
#if defined(RT_HW_PERMIT_UART6)
if(n==6){Serial6.print(str);}
#endif
#if defined(RT_HW_PERMIT_UART7)
if(n==7){Serial7.print(str);}
#endif
#if defined(RT_HW_PERMIT_UART8)
if(n==8){Serial8.print(str);}
#endif
#if defined(RT_HW_PERMIT_UARTS)
if(n==9){SerialS.print(str);}
#endif		
};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	