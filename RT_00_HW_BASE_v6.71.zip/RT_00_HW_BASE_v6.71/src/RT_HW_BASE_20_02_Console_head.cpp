#include "RT_HW_BASE.h"	 
//=================================================================================================
//							ОСНОВНЫЕ ФУНКЦИИ ВЫВОДА ЗАГОЛОВКОВ 
//=================================================================================================
void  RT_HW_BASE:: ConsoleDateTime() {		//==Вывод даты и времени компиляции;
String str;
str=__DATE__; consoleText(str,';'); consoleBlank(59);
str=__TIME__; consoleText(str,'E');} 
void  RT_HW_BASE:: ConsoleCoreBoard(){		//==Вывод наименований  архитектуры, платы, кода платы;
consoleText(String(F("Board::"))); 			consoleText(String(F(RT_HW_BOARD_NAME)),'/');	consoleUint8(RT_HW_BOARD_CODE,';'); consoleBlank(2);
consoleText(String(F("Arch::"))); 			consoleText(String(F(RT_HW_ARCH_NAME)),'/');	consoleUint8(RT_HW_ARCH_CODE,'E');  
consoleText(String(F("Core::")));			consoleText(String(F(RT_HW_CORE_NAME)),';');	consoleBlank(2);
consoleText(String(F("RT_HW_BASE.h::")));	consoleText(String(F(RT_HW_BASE_VER_NAME)),'E');
};
void  RT_HW_BASE:: ConsoleSelectBoard(){	//==Вывод наименования выбранной платы;
consoleText(String(F("Select::")));			consoleText(String(F(RT_HW_BOARD_SELECT)),'E');}									
void  RT_HW_BASE:: ConsoleFcpuBoard(){		//==Вывод параметров процессора и памяти;
consoleText(String(F("Fcpu="))); 			consoleUint16(RT_HW_FCPU); consoleText(String(F("mHz")),';'); 
consoleText(String(F(" Vcc="))); 			consoleFloat((float)RT_HW_VCC/1000,'1',';'); 
consoleText(String(F(" Memory::")));		consoleText(RT_HW_BOARD_MEMORY,'E');} 
void  RT_HW_BASE:: ConsoleDepthBoard(){		//==Вывод разрядности устройств;
uint8_t bf8[6];
bf8[0]=device.depth.sys; bf8[1]=device.depth.adc; bf8[2]=device.depth.drift; bf8[3]=device.depth.vNull; bf8[4]=device.depth.pwm; bf8[5]=device.depth.dac;
consoleText(String(F("DEPTH:: SYS,ADC.depth,drift,null,PWM,DAC="))); ConsoleArrV8('U',2,';',6,bf8);	
consoleBlank(2); consoleText(String(F("SYS.max="))); ConsoleV16('U',5,'E',maxBitDepth(device.depth.sys));}
void  RT_HW_BASE:: ConsoleSystemPins(){		//==Вывод номеров системных пинов;
uint8_t bf8[3];
bf8[0]=device.pin.control; bf8[1]=device.pin.led; bf8[2]=device.pin.button;
ConsoleString('L',0,'=',String(F("pins->control,led,button"))); ConsoleArrPin('T',0,'E',3,bf8);}
void  RT_HW_BASE:: ConsoleParamShed(){		//==Вывод параметров диспетчера задач;
uint8_t bf8[5]; 
bf8[0]=shed.quick.qnt; bf8[1]=shed.fast.qnt; bf8[2]=shed.slow.qnt; bf8[3]=shed.back.qnt; bf8[4]=shed.frdm.qnt;
consoleText(String(F("Sheduler::qnt->quick,fast,slow,back,frdm="))); ConsoleArrV8('U',0,'E',5,bf8);	
int16_t bf16[4];
bf16[0]=10; 	bf16[1]=25;	  bf16[2]=250;   bf16[3]=100;
consoleBlank(7); consoleText(String(F("period->quick,fast,slow,back="))); ConsoleArrV16('O',0,'E',4,bf16);}
void  RT_HW_BASE:: ConsoleWaringMess(){		//--Исключения при загрузке (ESP8266,ESP32);
#if defined(RT_HW_CORE_ESP8266)
consoleText(String(F("[Boot: pins->D3,D4=1; pin->D8=0;]")),'E');
#endif
#if defined(RT_HW_CORE_ESP32)
consoleText(String(F("[Boot: pins->3,12=1; pins->0,5,14,15=PWM; pin->1=debug;]")),'E');
#endif
};
void  RT_HW_BASE:: ConsoleScanI2C   (char mode, uint8_t qnt){	//==Сканирование шины i2c;	
if(qnt==0){return;}	for(uint8_t i=0; i<qnt; i++){i2cScanDevice(mode,i);}};
void  RT_HW_BASE:: ConsolePins      (uint8_t mode){		//==Вывод параметров интерфейсов;
consoleBegin();	
if(bitRead(mode,0)) {ConsoleBoardPins('T');}
if(bitRead(mode,1)) {ConsoleTableNamePins();}	
}
//=================================================================================================
//							ДОПОЛНИТЕЛЬНЫЕ ФУНКЦИИ ВЫВОДА ЗАГОЛОВКОВ 
//=================================================================================================
void  RT_HW_BASE:: ConsoleParamWire	(char code){			//==Вывод параметров i2c;						

//-----------------------------Шина i2c0------------------------------------------------------------
#if defined(RT_HW_PERMIT_I2C0)
buff.arr[0]=device.i2c0.sda; buff.arr[1]=device.i2c0.scl;  
consoleText(String(F("i2c0->SDA,SCL,State="))); ConsoleArrPin(code,0,',',2,buff.arr);
if     (bitRead(device.i2c0.state,RT_HW_I2C_STATE_SLAVE)) {consoleText(String(F("Slave=")));  		consoleInt8(device.i2c0.adr,'E');} 
else if(bitRead(device.i2c0.state,RT_HW_I2C_STATE_MASTER)){consoleText(String(F("Master, freq="))); consoleUint32(device.i2c0.speed/1000); consoleText(String(F("kHz")),'E');}
else 													  {consoleText(String(F("No init")),';');}
#if   defined(RT_HW_CORE_ESP8266)
consoleText(String(F(" [SDA,SCL another pin D1-D10]")),'E');
#elif defined(RT_HW_CORE_ESP32)  
consoleText(String(F(" [SDA,SCL another pin <35]")),'E');
#elif defined(RT_HW_CORE_M_STM32F1) || defined(RT_HW_CORE_M_STM32F4) || defined(RT_HW_CORE_D_STM32)
consoleText(String(F(" [SDA,SCL pin PB7,PB6 or PB9,PB8]")),'E');   
#else
consoleCR();
#endif 
#endif
//-----------------------------Шина i2c1------------------------------------------------------------
#if defined(RT_HW_PERMIT_I2C1)
buff.arr[0]=device.i2c1.sda; buff.arr[1]=device.i2c1.scl;  
consoleText(String(F("i2c1->SDA,SCL,State="))); ConsoleArrPin(code,0,',',2,buff.arr);
if     (bitRead(device.i2c1.state,RT_HW_I2C_STATE_SLAVE)) {consoleText(String(F("Slave=")));  		consoleInt8(device.i2c1.adr,'E');} 
else if(bitRead(device.i2c1.state,RT_HW_I2C_STATE_MASTER)){consoleText(String(F("Master, freq="))); consoleUint32(device.i2c1.speed/1000); consoleText(String(F("kHz")),'E');}
else 													  {consoleText(String(F("No init")),';');}
#if defined(RT_HW_CORE_ESP32)  
consoleText(String(F(" [SDA,SCL another pin <35]")),'E');  
#else
consoleCR();
#endif 
#endif
//-----------------------------Шина i2c2------------------------------------------------------------
#if defined(RT_HW_PERMIT_I2C2)
buff.arr[0]=device.i2c2.sda; buff.arr[1]=device.i2c2.scl;  
consoleText(String(F("i2c2->SDA,SCL,State="))); ConsoleArrPin(code,0,',',2,buff.arr);
if     (bitRead(device.i2c2.state,RT_HW_I2C_STATE_SLAVE)) {consoleText(String(F("Slave=")));        consoleInt8(device.i2c2.adr,'E');} 
else if(bitRead(device.i2c2.state,RT_HW_I2C_STATE_MASTER)){consoleText(String(F("Master, freq="))); consoleUint32(device.i2c2.speed/1000); consoleText(String(F("kHz")),'E');}
else 													  {consoleText(String(F("No init")),';');}
consoleCR();
#endif
};
void  RT_HW_BASE:: ConsoleParamSPI	(char code){			//==Вывод параметров SPI;	
#ifdef RT_HW_PERMIT_SPI0
{uint8_t arr[4];
arr[0]=device.spi0.sck; arr[1]=device.spi0.miso; arr[2]=device.spi0.mosi; 
consoleText(String(F("SPI0->SCK,MISO,MOSI,State="))); ConsoleArrPin(code,0,',',3,arr);
if     (bitRead(device.spi0.state,RT_HW_SPI_STATE_SLAVE)) {consoleText(String(F("Slave="))); consoleInt8(device.spi0.ss,'E');} 
else if(bitRead(device.spi0.state,RT_HW_SPI_STATE_MASTER)){consoleText(String(F("Master")),'E');}
else 													  {consoleText(String(F("No init")),';');}
consoleCR();
}
#endif 
#ifdef RT_HW_PERMIT_SPI1
{uint8_t arr[4];
arr[0]=device.spi1.sck; arr[1]=device.spi1.miso; arr[2]=device.spi1.mosi;
consoleText(String(F("SPI1->SCK,MISO,MOSI,State="))); ConsoleArrPin(code,0,',',3,arr);
if     (bitRead(device.spi1.state,RT_HW_SPI_STATE_SLAVE)) {consoleText(String(F("Slave="))); consoleInt8(device.spi1.ss,'E');} 
else if(bitRead(device.spi1.state,RT_HW_SPI_STATE_MASTER)){consoleText(String(F("Master")),'E');}
else 													  {consoleText(String(F("No init")),';');}
consoleCR();
}
#endif
#ifdef RT_HW_PERMIT_SPI2
{uint8_t arr[4];
arr[0]=device.spi2.sck; arr[1]=device.spi2.miso; arr[2]=device.spi2.mosi;;
consoleText(String(F("SPI-->SCK,MISO,MOSI,State="))); ConsoleArrPin(code,0,',',3,arr);
if     (bitRead(device.spi2.state,RT_HW_SPI_STATE_SLAVE)) {consoleText(String(F("Slave="))); consoleInt8(device.spi2.ss,'E');} 
else if(bitRead(device.spi2.state,RT_HW_SPI_STATE_MASTER)){consoleText(String(F("Master")),'E');}
else 													  {consoleText(String(F("No init")),';');}
consoleCR();
}
#endif 
};
void  RT_HW_BASE:: ConsoleParamUART	(char code){			//==Вывод параметров UART;
buff.vu8=0;
#ifdef RT_HW_CORE_ESP8266
consoleText(String(F("[UART  possible options are (1,3),(2,3) or (15,13)]")),'L');
consoleText(String(F("[ Set Serial.pins(uint8_t tx, uint8_t rx) or Serial.swap(uint8_t tx_pin)]")),'L');
consoleText(String(F("[  toggle between use of GPIO13/GPIO15 or GPIO3/GPIO(1/2)as RX and TX]")),'E');
consoleText(String(F("[UART1 allows only TX on 2 if UART is not (2,3)]")),'E');	 
#endif
//-------------------------------------------------------------------------------------------------
#ifdef RT_HW_PERMIT_UART0
{uint8_t arr[]={readArrPGM(RT_HW_PGM_PIN_UHS_ID,0),  readArrPGM(RT_HW_PGM_PIN_UHS_ID,1)}; if((arr[0]!=255) && (arr[1]!=255)) {consoleText(String(F("UART0(RX,TX):"))); ConsoleArrPin(code,0,'E',2,arr);}}		  
#endif
#ifdef RT_HW_PERMIT_UART1
{uint8_t arr[]={readArrPGM(RT_HW_PGM_PIN_UHS_ID,2),  readArrPGM(RT_HW_PGM_PIN_UHS_ID,3)}; 	if((arr[0]!=255) && (arr[1]!=255)) {consoleText(String(F("UART1(RX,TX):"))); ConsoleArrPin(code,0,'E',2,arr);}}	
#endif
#ifdef RT_HW_PERMIT_UART2
{uint8_t arr[]={readArrPGM(RT_HW_PGM_PIN_UHS_ID,4),  readArrPGM(RT_HW_PGM_PIN_UHS_ID,5)}; 	if((arr[0]!=255) && (arr[1]!=255)) {consoleText(String(F("UART2(RX,TX):"))); ConsoleArrPin(code,0,'E',2,arr);}}	 
#endif
#ifdef RT_HW_PERMIT_UART3
{uint8_t arr[]={readArrPGM(RT_HW_PGM_PIN_UHS_ID,6),  readArrPGM(RT_HW_PGM_PIN_UHS_ID,7)}; 	if((arr[0]!=255) && (arr[1]!=255)) {consoleText(String(F("UART3(RX,TX):"))); ConsoleArrPin(code,0,'E',2,arr);}}
#endif
#ifdef RT_HW_PERMIT_UART4
{uint8_t arr[]={readArrPGM(RT_HW_PGM_PIN_UHS_ID,8),  readArrPGM(RT_HW_PGM_PIN_UHS_ID,9)}; if((arr[0]!=255) && (arr[1]!=255)) {consoleText(String(F("UART4(RX,TX):"))); ConsoleArrPin(code,0,'E',2,arr);}}
#endif
#ifdef RT_HW_PERMIT_UART5
{uint8_t arr[]={readArrPGM(RT_HW_PGM_PIN_UHS_ID,10), readArrPGM(RT_HW_PGM_PIN_UHS_ID,11)};if((arr[0]!=255) && (arr[1]!=255)) {consoleText(String(F("UART5(RX,TX):"))); ConsoleArrPin(code,0,'E',2,arr);}}
#endif
#ifdef RT_HW_PERMIT_UART6
{uint8_t arr[]={readArrPGM(RT_HW_PGM_PIN_UHS_ID,12), readArrPGM(RT_HW_PGM_PIN_UHS_ID,13)};if((arr[0]!=255) && (arr[1]!=255)) {consoleText(String(F("UART6(RX,TX):"))); ConsoleArrPin(code,0,'E',2,arr);}}
#endif
#ifdef RT_HW_PERMIT_UART7
{uint8_t arr[]={readArrPGM(RT_HW_PGM_PIN_UHS_ID,14), readArrPGM(RT_HW_PGM_PIN_UHS_ID,15)};if((arr[0]!=255) && (arr[1]!=255)) {consoleText(String(F("UART7(RX,TX):"))); ConsoleArrPin(code,0,'E',2,arr);}}
#endif
#ifdef RT_HW_PERMIT_UART8
{uint8_t arr[]={readArrPGM(RT_HW_PGM_PIN_UHS_ID,16), readArrPGM(RT_HW_PGM_PIN_UHS_ID,17)};if((arr[0]!=255) && (arr[1]!=255)) {consoleText(String(F("UART8(RX,TX):"))); ConsoleArrPin(code,0,'E',2,arr);}}
#endif
#ifdef RT_HW_PERMIT_UARTS
{uint8_t arr[]={readArrPGM(RT_HW_PGM_PIN_USS_ID,0),  readArrPGM(RT_HW_PGM_PIN_USS_ID,1)}; if((arr[0]!=255) && (arr[1]!=255)) {consoleText(String(F("UARTS(RX,TX):"))); ConsoleArrPin(code,0,'E',2,arr);}}
#endif
	};
void  RT_HW_BASE:: ConsoleParamCAN	(char code){			//==Вывод параметров CAN;
#ifdef RT_HW_PERMIT_CAN
{uint8_t arr[]={readArrPGM(RT_HW_PGM_PIN_CAN_ID,0),  readArrPGM(RT_HW_PGM_PIN_CAN_ID,1)}; if((arr[0]!=255) && (arr[1]!=255)) {consoleText(String(F("CAN  (RX,TX):"))); ConsoleArrPin(code,0,'E',2,arr);}}
#endif
};
void  RT_HW_BASE:: ConsoleParamBTH(){						//==Вывод параметров BlueTooth;
#ifdef RT_HW_PERMIT_BTH
consoleText(String(F("BlueTooth->в разработке:"))); 
consoleChar((char)getIntPGM(RT_HW_PGM_PIN_BTH_ID,0));
consoleChar((char)getIntPGM(RT_HW_PGM_PIN_BTH_ID,1));
consoleChar((char)getIntPGM(RT_HW_PGM_PIN_BTH_ID,2));
consoleSuff('E');
#endif
};
void  RT_HW_BASE:: ConsoleParamETH(){						//==Вывод параметров Ethernet; 
#ifdef RT_HW_PERMIT_ETH
consoleText(String(F("Ethernet->в разработке:"))); 
ConsoleV8('O',0,'.',readArrPGM(RT_HW_PGM_PIN_ETH_ID,0));
ConsoleV8('O',0,'.',readArrPGM(RT_HW_PGM_PIN_ETH_ID,1));
ConsoleV8('O',0,'.',readArrPGM(RT_HW_PGM_PIN_ETH_ID,2));
ConsoleV8('O',0,'E',readArrPGM(RT_HW_PGM_PIN_ETH_ID,3));
#endif
};
void  RT_HW_BASE:: ConsoleParamWFI(){						//==Вывод параметров Wi-Fi; 
#ifdef RT_HW_PERMIT_WFI
consoleText(String(F("Wi-Fi(в разработке)->:"))); 
ConsoleV8('O',0,'.',readArrPGM(RT_HW_PGM_PIN_WFI_ID,0));
ConsoleV8('O',0,'.',readArrPGM(RT_HW_PGM_PIN_WFI_ID,1));
ConsoleV8('O',0,'.',readArrPGM(RT_HW_PGM_PIN_WFI_ID,2));
ConsoleV8('O',0,'E',readArrPGM(RT_HW_PGM_PIN_WFI_ID,3));
#endif
};
void  RT_HW_BASE:: ConsoleBoardPins	(char code){			//==Вывод доступных пинов контроллера [U,I ; для ESP8266,ESP32 дополнительно T,D,A  ];
	for(uint8_t i=RT_HW_PGM_PIN_ALL_ID;i<=RT_HW_PGM_PIN_N5V_ID;i++){ConsoleArrPGM(i,code);}
	if(getLenPosPGM(RT_HW_PGM_PIN_N5V_ID)==0) {consoleText(String(F("All pins tolerant to 5V")),'E'); }};	
void  RT_HW_BASE:: ConsoleSysParam 	(char code){			//==Вывод системных параметров;
	for(uint8_t i=0;i<=RT_HW_PGM_SYS_DAC_ID;i++){ConsoleArrPGM(i,code);}};
void  RT_HW_BASE:: ConsoleSysPins  	(char code){			//==Вывод системных пинов;
	ConsoleArrPGM(RT_HW_PGM_SYS_PIN_ID,code);};		
void  RT_HW_BASE:: ConsoleLinkPins	(char code){			//==Вывод интерфейсных пинов;
	for(uint8_t i=RT_HW_PGM_PIN_I2C_ID; i<=RT_HW_PGM_PIN_CAN_ID; i++){ConsoleArrPGM(i,code);}};
void  RT_HW_BASE:: ConsoleNetParam	(char code){			//==Вывод сетевых параметров (BlueTooth,Wi-Fi,Ethernet);
	for(uint8_t i=RT_HW_PGM_PIN_BTH_ID; i<=RT_HW_PGM_PIN_WFI_ID; i++){ConsoleArrPGM(i,code);}};	
void  RT_HW_BASE:: ConsoleTestPins	(char code){			//==Вывод тестовых адресов устройств SSPI; 
	for(uint8_t i=RT_HW_PGM_PIN_DBG_ID;i<=RT_HW_PGM_PIN_SSP_ID;i++){ConsoleArrPGM(i,code);}};	 
void  RT_HW_BASE:: ConsoleTestAddr	(char code){			//==Вывод тестовых адресов устройств i2c; 
	ConsoleArrPGM(RT_HW_PGM_ADR_I2C_ID,code);};
void  RT_HW_BASE:: ConsoleTableNamePins(){					//==Вывод таблицы доступных пинов;
//-----------------------------------------------------------------------------------------------------------------------------
#if   defined(RT_HW_CORE_ESP8266)	
ConsoleText  ('C',80,'L','-',String(F("Name pins ESP8266")));
ConsoleString('L',5,':',String(F("D[11]")));
{uint8_t arr[]={D0,D1,D2,D3,D4,D5,D6,D7,D8,D9,D10};	ConsoleArrV8('U',2,'E',11,arr);}
ConsoleString('L',0,':',String(F("RX,RX0,TX,TX0[4]")));
{uint8_t arr[]={RX,RX0,TX,TX0};  					ConsoleArrV8('U',2,';',4,arr); consoleBlank(2);}
ConsoleString('L',0,':',String(F("TX1,RX2,TX2[3]")));
{uint8_t arr[]={TX1,RX2,TX2};  						ConsoleArrV8('U',2,';',3,arr); consoleCR();}
//--------------------------------------------------------------------------------------------------------------------------
#elif defined(RT_HW_CORE_M_STM32F1) || defined(RT_HW_CORE_M_STM32F4) || defined(RT_HW_CORE_D_STM32)
uint8_t arr[16]; char reg; bool ok;
ConsoleText  ('C',80,'L','-',String(F("Name pins STM32")));
for(uint8_t m=0; m<12; m++){reg=char(((uint8_t)'A')+m); ok=0; for(uint8_t i=0;i<16;i++){arr[i]=getNumPinSTM32(reg,i); if(arr[i]<254){ok=1;}}	
  if(ok){consoleChar('P'); consoleChar((char)reg,'['); ConsoleV8('U',2,']',16); consoleBlank(2); ConsoleArrPin('D',3,'E',16,arr);}}	
#endif
};
void  RT_HW_BASE:: ConsoleArrPGM(uint8_t kind, char code){ 	//=Вывод данных из массива типа kind в формате code:: T,D,A-пины, U,I-данные];
uint8_t arr[RT_HW_PIN_QNT_LINE]; uint8_t lenFull, lenVal, index;
if(kind>RT_HW_PGM_QNT_ID) 	{return;}																//--Выход по несуществующему типу массива; 
lenFull=0;      for(uint8_t i=0; i<255;     i++){if(getFromArrPGM(kind,i)==254) {break;} lenFull++;}	//--Вычисление длины массива;
lenVal=lenFull; for(uint8_t i=0; i<lenFull; i++){if(getFromArrPGM(kind,i) <254) {break;} lenVal--; }  	//--Вычисление длины массива со значащими значениями (<254);
if(lenVal==0) 				{return;}																//--Выход, если нет массив пуст;
//=================================================================================================
#if defined(RT_HW_CORE_ESP8266) || defined(RT_HW_CORE_M_STM32F1) || defined(RT_HW_CORE_M_STM32F4) || defined(RT_HW_CORE_D_STM32)	
if((code=='T') || (code=='D') ||(code=='A') || (code=='I') || (code=='U')) {index=0; 
ConsoleString('L',3,'[',getNameKindPin(kind)); ConsoleV8('U',2,']',lenVal); consoleChar(':',' ');	//--Вывод заголовка (
for(uint8_t i=0; i<lenVal; i++){arr[index]=readArrPGM(kind,i); index++; 
//-------------------------------------------------------------------------------------------------
if((code=='T') || (code=='D')){ 
if(((i+1)>=lenVal)) 				{ConsoleArrPin(code, RT_HW_PIN_TXT_LEN, 'E',index, arr); index=0; break;}
if(index>=RT_HW_PIN_QNT_LINE)       {ConsoleArrPin(code, RT_HW_PIN_TXT_LEN, 'E',index, arr); index=0; consoleBlank(9);}}
//-------------------------------------------------------------------------------------------------
if(code=='A'){ 
if(((i+1)>=lenVal)) 				{ConsoleArrPin(code, RT_HW_PIN_TXT_LEN, 'E',index, arr); index=0; break;}
if(index>=(RT_HW_PIN_QNT_LINE/2))   {ConsoleArrPin(code, RT_HW_PIN_TXT_LEN, 'E',index, arr); index=0; consoleBlank(9);}}
//-------------------------------------------------------------------------------------------------
if((code=='U') || (code=='I')) { 
if(((i+1)>=lenVal)) 				{ConsoleArrV8(code,  RT_HW_PIN_TXT_LEN, 'E',index, arr); index=0; break;}
if(index>=RT_HW_PIN_QNT_LINE)       {ConsoleArrV8(code,  RT_HW_PIN_TXT_LEN, 'E',index, arr); index=0; consoleBlank(9);}}
//-------------------------------------------------------------------------------------------------
}}
//=================================================================================================
#else
if((code=='T') || (code=='D') ||(code=='A')) {code='U';}
if((code=='U') || (code=='I')) {index=0; 
ConsoleString('L',3,'[',getNameKindPin(kind)); ConsoleV8('U',2,']',lenVal); consoleChar(':',' ');	//--Вывод заголовка (
for(uint8_t i=0; i<lenVal; i++){arr[index]=readArrPGM(kind,i); index++; 
if(((i+1)>=lenVal)) 				{ConsoleArrV8(code,  RT_HW_PIN_TXT_LEN, 'E',index, arr); index=0; break;}
if(index>=RT_HW_PIN_QNT_LINE)       {ConsoleArrV8(code,  RT_HW_PIN_TXT_LEN, 'E',index, arr); index=0; consoleBlank(9);}
}}	
#endif
//=================================================================================================
};