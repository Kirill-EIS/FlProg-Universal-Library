 #include "RT_HW_BASE.h"
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//								SPI
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//---------------------------1.ОПРЕДЕЛЕНИЕ ДОПОЛНИТЕЛЬНЫХ ШИН------------------------------------------------
#if defined(RT_HW_PERMIT_SPI1) && defined(RT_HW_CORE_ESP32)
SPIClass SPI1(HSPI);
#endif
#if defined(RT_HW_PERMIT_SPI1) && (defined(RT_HW_CORE_M_STM32F1) || defined(RT_HW_CORE_M_STM32F4))	
SPIClass SPI_1(1);
#endif
#if defined(RT_HW_PERMIT_SPI1) && (defined(RT_HW_CORE_D_STM32))	
SPIClass SPI_1(1);
#endif
#if defined(RT_HW_PERMIT_SPI2) && (defined(RT_HW_CORE_M_STM32F1) || defined(RT_HW_CORE_M_STM32F4) || defined(RT_HW_CORE_D_STM32))	
SPIClass SPI_2(2);
#endif
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//								SPI
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//---------------------------2.ФУНКЦИИ ПРОВЕРКА И УСТАНОВКА СОСТОЯНИЯ ШИН SPI--------------------------------
bool    RT_HW_BASE:: spiCheckBusNum(									    uint8_t bus){	//==Проверка  доступности    шины с номером bus;
#if defined(RT_HW_PERMIT_SPI0)	
if(bus==0) {return 1;}
#endif
#if defined(RT_HW_PERMIT_SPI1)	
if(bus==1) {return 1;}
#endif
#if defined(RT_HW_PERMIT_SPI2)	
if(bus==2) {return 1;}
#endif	
return 0;};	//++++++END spiCheckBusNum()
bool    RT_HW_BASE:: spiCheckBusState(uint8_t numBitState,				    uint8_t bus){	//==Проверка  бита состояния шины с номером bus;
#if defined(RT_HW_PERMIT_SPI0)	
if(bus==0) {return bitRead(device.spi0.state,numBitState);}
#endif
#if defined(RT_HW_PERMIT_SPI1)	
if(bus==1) {return bitRead(device.spi1.state,numBitState);}
#endif
#if defined(RT_HW_PERMIT_SPI2)	
if(bus==2) {return bitRead(device.spi2.state,numBitState);}
#endif
return 0;}	//++++++END i2cCheckBusState()
void    RT_HW_BASE:: spiSetBusState  (uint8_t numBitState,                  uint8_t bus){	//==Установка бита состояния шины с номером bus;
#if defined(RT_HW_PERMIT_SPI0)	
if(bus==0) {bitSet(device.spi0.state,numBitState);}
#endif
#if defined(RT_HW_PERMIT_SPI1)	
if(bus==1) {bitSet(device.spi1.state,numBitState);}
#endif
#if defined(RT_HW_PERMIT_SPI2)	
if(bus==2) {bitSet(device.spi2.state,numBitState);}
#endif
}	//++++++END spiSetBusState()
void    RT_HW_BASE:: spiClearBusState(uint8_t numBitState,                   uint8_t bus){	//==Сброс     бита состояния шины с номером bus;
#if defined(RT_HW_PERMIT_SPI0)	
if(bus==0) {bitClear(device.spi0.state,numBitState);}
#endif
#if defined(RT_HW_PERMIT_SPI1)	
if(bus==1) {bitClear(device.spi1.state,numBitState);}
#endif
#if defined(RT_HW_PERMIT_SPI2)	
if(bus==2) {bitClear(device.spi2.state,numBitState);}
#endif
}	//++++++END spiClearBusState()
uint8_t RT_HW_BASE:: spiGetBusState  (                                      uint8_t bus){	//==Возращает рег.состояния  шины с номером bus;
#if defined(RT_HW_PERMIT_SPI0)	
if(bus==0) {return device.spi0.state;}
#endif
#if defined(RT_HW_PERMIT_SPI1)	
if(bus==1) {return device.spi1.state;}
#endif
#if defined(RT_HW_PERMIT_SPI2)	
if(bus==2) {return device.spi2.state;}
#endif
return 0;}	//++++++END i2cGetBusState()
//---------------------------3.ФУНКЦИИ ИНИЦИАЛИЗАЦИИ И НАСТРОЙКИ ШИН I2C-------------------------------------
void 	RT_HW_BASE:: spiBeginTransaction(SPISettings setParam, uint8_t bus){
#if defined(RT_HW_PERMIT_SPI0)	
if(bus==0) {SPI.beginTransaction(setParam);}
#endif
#if defined(RT_HW_PERMIT_SPI1)	
//if(bus==1) {SPI1.beginTransaction(setParam);}
#endif
#if defined(RT_HW_PERMIT_SPI2)	
//if(bus==2) {SPI2.beginTransaction(setParam);}
#endif
}	//++++++END i2cGetBusState()	
void 	RT_HW_BASE:: spiEndTransaction(uint8_t bus){
#if defined(RT_HW_PERMIT_SPI0)	
if(bus==0) {SPI.endTransaction();}
#endif
#if defined(RT_HW_PERMIT_SPI1)	
//if(bus==1) {SPI.endTransaction();}
#endif
#if defined(RT_HW_PERMIT_SPI2)	
//if(bus==2) {SPI.endTransaction();}
#endif
}	//++++++END i2cGetBusState()	
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void    RT_HW_BASE:: spiBegin(uint8_t sck, uint8_t miso, uint8_t mosi, uint8_t ss, uint8_t bus){//==Инициализация шины SPI;
if(!spiCheckBusNum(bus)) {return;}							//--Выход, если недопустимый номер шины i2c;
//-------------------------------------------------------------------------------------------------
#if defined(RT_HW_PERMIT_SPI0)	
if(bus==0){					//-------Общие настройки шины SPI0-------------------------------------
 if(spiCheckBusState(RT_HW_SPI_STATE_INIT,bus)) {return;};	//--Выход, если шина инициализирована;
//-------------------------------------------------------------------------------------------------				  
 if(ss==0){	//------Настройки шины SPI0 как Master (по условию)--------------------
  #if defined(RT_HW_CORE_ESP8266) 
    if(SPI.pins((int8_t)sck, (int8_t)miso,(int8_t)mosi,(int8_t)ss)){
	SPI.begin();
	spiSetBusState(RT_HW_SPI_STATE_MASTER,bus);				//--Установка флага MASTER; 
	spiSetBusState(RT_HW_SPI_STATE_INIT,  bus);		return;}//--Установка флага INIT и выход; 
  #elif defined(RT_HW_CORE_ESP32)
    //SPI.begin();
	SPI.begin((int8_t)sck, (int8_t)miso, (int8_t)mosi, (int8_t)ss);
    spiSetBusState(RT_HW_SPI_STATE_MASTER,bus);				//--Установка флага MASTER; 
    spiSetBusState(RT_HW_SPI_STATE_INIT,  bus);		return;	//--Установка флага INIT и выход;
  #elif defined(RT_HW_CORE_D_STM32)
    //SPI.setSCLK(sck);
    //SPI.setMISO(miso);
    //SPI.setMOSI(mosi);
	//SPI.setSSEL(0);
	SPI.begin();
	spiSetBusState(RT_HW_SPI_STATE_MASTER,bus);				//--Установка флага MASTER; 
    spiSetBusState(RT_HW_SPI_STATE_INIT,  bus);		return;	//--Установка флага INIT и выход;
  #else  
	sck=miso=mosi; mosi=sck;
	SPI.begin();
	spiSetBusState(RT_HW_SPI_STATE_MASTER,bus);				//--Установка флага MASTER; 
	spiSetBusState(RT_HW_SPI_STATE_INIT,  bus);		return;	//--Установка флага INIT и выход; 
  #endif		//---------------------------------------------------------------------------------	
  }  //--END if(MASTER)
 if(ss>0){	//------Настройки шины SPI0 как Slave(по условию)---------------------- 									
  return;	
  } //--END if(SLAVE) 							 
  } //--END if(bus==0)   
#endif    //--END #if defined(RT_HW_PERMIT_SPI0)
//-------------------------------------------------------------------------------------------------
#if defined(RT_HW_PERMIT_SPI1)	
if(bus==1){					//-------Общие настройки шины spi1-------------------------------------
 if(spiCheckBusState(RT_HW_SPI_STATE_INIT,bus)) {return;};	//--Выход, если шина инициализирована;
//-------------------------------------------------------------------------------------------------				  
 if(ss==0){	//------Настройки шины spi1 как Master (по условию)--------------------
  #if defined(RT_HW_CORE_ESP32RT_HW_ARCH_ESP32) 											
  return;	//--Выход; 	//---------------------------------------------------------
  #else												
  return;	//--Установка флага INIT и выход;  
  #endif		//---------------------------------------------------------------------------------
  }  //--END if(MASTER)
 if(ss>0){	//------Настройки шины spi1 как Slave(по условию)------------------------ 									
  #if defined(RT_HW_ARCH_ESP32) 
  return;	//--Установка флага INIT и выход; 
  #else 		//--------------------------------------------------------------------------------  
  return;	//--Установка флага INIT и выход; 
  #endif		//---------------------------------------------------------------------------------
  } //--END if(SLAVE) 							 
  } //--END if(bus==1)   
#endif    //--END #if defined(RT_HW_PERMIT_SPI1) && defined(RT_HW_ARCH_FAMOUS)---------------------	
//-------------------------------------------------------------------------------------------------
#if defined(RT_HW_PERMIT_SPI2)	
if(bus==2){					//-------Общие настройки шины i2c1-------------------------------------
 if(spiCheckBusState(RT_HW_SPI_STATE_INIT,bus)) {return;};	//--Выход, если шина инициализирована;
//-------------------------------------------------------------------------------------------------				  
 if(ss==0){	//------Настройки шины SPI2 как Master (по условию)--------------------																	//				для core STM32duino;
   return;		//--Установка флага INIT и выход;  	//---------------------------------------------------------------------------------
  }  //--END if(MASTER)
 if(ss>0){	//------Настройки шины SPI2 как Slave(по условию)------------------------ 									 												//				для core STM32duino;
  return;	//--Установка флага INIT и выход; 		//-------------------------------------------------------------------------------
  } //--END if(SLAVE 							 
  } //--END if(bus==2)   
#endif    //--END #if defined(RT_HW_PERMIT_SPI2);	
}       //++++++END spiBegin()
uint8_t RT_HW_BASE:: spiTransfer (uint8_t val, uint8_t bus){									//==Отправка байта в SPI;
#if defined(RT_HW_PERMIT_SPI0)	
if(bus==0) {return SPI.transfer(val);}
#endif
#if defined(RT_HW_PERMIT_SPI1)	
//if(bus==1) {SPI1.transfer(val);}
#endif
#if defined(RT_HW_PERMIT_SPI2)	
//if(bus==2) {SPI2.transfer(val);}
#endif
return 0;};

void    RT_HW_BASE:: spiSendByte (uint8_t cs, uint8_t bus, uint8_t val){								//==Отправка байта в SPI;
RT_HW_PIN_DIR_ID idCS; 
RT_HW_PIN_DIR_SET_ID(idCS,cs);
#if defined(RT_HW_PERMIT_SPI0)
if(bus==0){
//if(!spiCheckBusState(RT_HW_SPI_STATE_MASTER,bus)){return 1;} 
RT_HW_PIN_DIR_WRITE_LOW(idCS);
SPI.transfer(val); 
RT_HW_PIN_DIR_WRITE_HIGH(idCS);		   
}
#endif	
#if defined(RT_HW_PERMIT_SPI1)
if(bus==1){;}
#endif	 
#if defined(RT_HW_PERMIT_SPI2)
if(bus==2){;}
#endif	 
}	
void RT_HW_BASE:: spiSendBytes(uint8_t cs, uint8_t bus, uint8_t qnt, const uint8_t *arr){	//==Отправка байтов в SPI;
RT_HW_PIN_DIR_ID idCS; 
RT_HW_PIN_DIR_SET_ID(idCS,cs);
if(qnt>32) {qnt=32;};
#if defined(RT_HW_PERMIT_SPI0)
if(bus==0){
//if(!spiCheckBusState(RT_HW_SPI_STATE_MASTER,bus)){return 1;} 
for(uint8_t i=0; i<qnt; i++) {
RT_HW_PIN_DIR_WRITE_LOW(idCS);
	SPI.transfer(arr[i]);
RT_HW_PIN_DIR_WRITE_HIGH(idCS);	
} 
//return 0;
}
#endif	
#if defined(RT_HW_PERMIT_SPI1)
if(bus==1){}
#endif	 
#if defined(RT_HW_PERMIT_SPI2)
if(bus==2){}
#endif	 
}	