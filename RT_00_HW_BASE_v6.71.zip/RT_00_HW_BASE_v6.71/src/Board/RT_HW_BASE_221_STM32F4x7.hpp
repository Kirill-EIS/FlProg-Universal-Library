//*************************************************************************************************
//							1.Контроллер типа STM32F407Vx
 //                                          RT_HW_BOARD_STM32MASTER_F4_GENERIC_F407V
//*************************************************************************************************
#if !defined(RT_HW_BOARD_SELECT) && (defined(RT_HW_BOARD_M_generic_f407v) ||\
                                     defined(RT_HW_BOARD_D_BLACK_F407VE)     || defined(RT_HW_BOARD_D_BLACK_F407VG))
//---------------------------------------------------------------------------------------------------
#if                                  defined(RT_HW_BOARD_M_generic_f407v) 
#define        RT_HW_BOARD_SELECT	            "BOARD (M) generic_f407v"
#define        RT_HW_BLOCK_AVAILABLE_FOR_WRITE
//----------------------------------------------------------------------------------------------------
#elif                                defined(RT_HW_BOARD_D_BLACK_F407VE)     || defined(RT_HW_BOARD_D_BLACK_F407VG)
#define        RT_HW_BOARD_SELECT	            "BOARD (D) BLACK_F407V(E,G)"
//----------------------------------------------------------------------------------------------------
#else
#define        RT_HW_BOARD_SELECT	            "BOARD (X) F407V"	
#endif
//------------------------------------------------------------------------------------------------
#define RT_HW_BOARD_MEMORY 	  "FLASH=512Kb; RAM=128Kb;"						//--Параметры памяти;
#define RT_HW_PERMIT_UART0
#define RT_HW_PERMIT_UART1
#define RT_HW_PERMIT_UART2
#define RT_HW_PERMIT_UART3
#define RT_HW_PERMIT_UART4
#define RT_HW_PERMIT_UART5
//#define RT_HW_PERMIT_UART6
#define RT_HW_PERMIT_CAN
#define RT_HW_PERMIT_I2C0
#define RT_HW_PERMIT_I2C1
#define RT_HW_PERMIT_SPI0
//#define RT_HW_PERMIT_SPI1
#define RT_HW_PERMIT_DAC													//--Разрешение работы с DAC;
//------Системные пины-----------------------------------------------------------------------------
enum   {RT_HW_BOARD_CONTROL=PE2, RT_HW_BOARD_LED=PE6, RT_HW_BOARD_BUTTON=PE4};//--Пины контроль,led,кнопка;
//------Параметры контроллера общие----------------------------------------------------------------	
enum{RT_HW_PIN_QNT_MAX=80,	RT_HW_FCPU=168, 		RT_HW_VCC=3300};
//-----Параметры UART------------------------------------------------------------------------------	
enum   {RT_HW_UART0_RX=PA12, RT_HW_UART0_TX=PA11,	//--USB
		RT_HW_UART1_RX=PA10, RT_HW_UART1_TX=PA9,  
		RT_HW_UART2_RX=PA3,  RT_HW_UART2_TX=PA2, 
		RT_HW_UART3_RX=PB11, RT_HW_UART3_TX=PB10, 
		RT_HW_UART4_RX=PC11, RT_HW_UART4_TX=PC10,
        RT_HW_UART5_RX=PD2,  RT_HW_UART5_TX=PC12, 
		RT_HW_UART6_RX=PC7,  RT_HW_UART6_TX=PC6};	
//-----Параметры CAN------------------------------------------------------------------------------	
enum   {RT_HW_CAN_RX=PD0,    RT_HW_CAN_TX=PD1};	
//-----Параметры I2C------------------------------------------------------------------------------	
enum   {RT_HW_I2C0_SDA=PB7,  RT_HW_I2C0_SCL=PB6,  RT_HW_I2C0_MODE_FM=RT_HW_I2C_MODE_FM,
        RT_HW_I2C1_SDA=PB11, RT_HW_I2C1_SCL=PB10, RT_HW_I2C1_MODE_FM=RT_HW_I2C_MODE_FM}; 
//-----Параметры SPI------------------------------------------------------------------------------	
enum   {RT_HW_SPI0_SCK=PA5,  RT_HW_SPI0_MISO=PA6,  RT_HW_SPI0_MOSI=PA7,  RT_HW_SPI0_SS=PA4,  
        RT_HW_SPI1_SCK=PB13, RT_HW_SPI1_MISO=PB14, RT_HW_SPI1_MOSI=PB15, RT_HW_SPI1_SS=PB12};
//-----Системные параметры-------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_SYS_PAR[]	={12,       RT_HW_PGM_END};  //--SYS->depth;
const uint8_t PROGMEM RT_HW_PGM_SYS_ADC[] 	={12,16,20, RT_HW_PGM_END};  //--ADC->depth,drift,null;
const uint8_t PROGMEM RT_HW_PGM_SYS_TCH[] 	={  		RT_HW_PGM_END};  //--TCH->depth,drift,null; 
const uint8_t PROGMEM RT_HW_PGM_SYS_PWM[] 	={16,10,	RT_HW_PGM_END};  //--PWM->depth,freq; 
const uint8_t PROGMEM RT_HW_PGM_SYS_DAC[] 	={12,		RT_HW_PGM_END};  //--DAC->depth; 
const uint8_t PROGMEM RT_HW_PGM_SYS_PIN[] 	={RT_HW_BOARD_CONTROL, RT_HW_BOARD_LED, RT_HW_BOARD_BUTTON, RT_HW_PGM_END};  //--Пины->control,led; 
//-----Параметры коммуникаций----------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_I2C[] 	={RT_HW_I2C0_SDA, RT_HW_I2C0_SCL, RT_HW_I2C1_SDA,  RT_HW_I2C1_SCL, RT_HW_PGM_END}; //--adr,SDA,SCL,mode; 
const uint8_t PROGMEM RT_HW_PGM_PIN_SPI[] 	={RT_HW_SPI0_SCK, RT_HW_SPI0_MISO, RT_HW_SPI0_MOSI, RT_HW_SPI0_SS,
											  RT_HW_SPI1_SCK, RT_HW_SPI1_MISO, RT_HW_SPI1_MOSI, RT_HW_SPI1_SS,	RT_HW_PGM_END}; 
const uint8_t PROGMEM RT_HW_PGM_PIN_UHS[] 	={RT_HW_UART0_RX, RT_HW_UART0_TX, 
										      RT_HW_UART1_RX, RT_HW_UART1_TX, RT_HW_UART2_RX, RT_HW_UART2_TX, 
										      RT_HW_UART3_RX, RT_HW_UART3_TX, RT_HW_UART4_RX, RT_HW_UART4_TX,
                                              RT_HW_UART5_RX, RT_HW_UART5_TX, RT_HW_UART6_RX, RT_HW_UART6_TX,  RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_USS[] 	={RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_CAN[] 	={RT_HW_CAN_RX,RT_HW_CAN_TX, RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_BTH[] 	={RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_ETH[] 	={1,RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_WFI[] 	={RT_HW_PGM_END};
//-----Доступные пины контроллера------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_ALL[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PA8,PA9,PA10,PA11,PA12, 255, 255,PA15,
											  PB0,PB1,255,PB3,PB4,PB5,PB6,PB7,PB8,PB9,PB10,PB11,PB12,PB13,PB14,PB15,
										      PC0,PC1,PC2,PC3,PC4,PC5,PC6,PC7,PC8,PC9,PC10,PC11,PC12,PC13, 255, 255,
										      PD0,PD1,PD2,PD3,PD4,PD5,PD6,PD7,PD8,PD9,PD10,PD11,PD12,PD13,PD14,PD15,
										      PE0,PE1,PE2,PE3,PE4,PE5,PE6,PE7,PE8,PE9,PE10,PE11,PE12,PE13,PE14,PE15, RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DIN[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PA8,PA9,PA10,PA11,PA12, 255, 255,PA15,
										      PB0,PB1,255,PB3,PB4,PB5,PB6,PB7,PB8,PB9,PB10,PB11,PB12,PB13,PB14,PB15,
										      PC0,PC1,PC2,PC3,PC4,PC5,PC6,PC7,PC8,PC9,PC10,PC11,PC12,PC13, 255, 255,
										      PD0,PD1,PD2,PD3,PD4,PD5,PD6,PD7,PD8,PD9,PD10,PD11,PD12,PD13,PD14,PD15,
										      PE0,PE1,PE2,PE3,PE4,PE5,PE6,PE7,PE8,PE9,PE10,PE11,PE12,PE13,PE14,PE15, RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_ADC[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PB0,PB1,PC0, PC1, PC2, PC3, PC4, PC5,  RT_HW_PGM_END};									
const uint8_t PROGMEM RT_HW_PGM_PIN_TCH[] 	={RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_DOT[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PA8,PA9,PA10,PA11,PA12, 255, 255,PA15,
										      PB0,PB1,255,PB3,PB4,PB5,PB6,PB7,PB8,PB9,PB10,PB11,PB12,PB13,PB14,PB15,
										      PC0,PC1,PC2,PC3,PC4,PC5,PC6,PC7,PC8,PC9,PC10,PC11,PC12,PC13, 255, 255,
										      PD0,PD1,PD2,PD3,PD4,PD5,PD6,PD7,PD8,PD9,PD10,PD11,PD12,PD13,PD14,PD15,
                                              PE0,PE1,PE2,PE3,PE4,PE5,PE6,PE7,PE8,PE9,PE10,PE11,PE12,PE13,PE14,PE15, RT_HW_PGM_END}; 
const uint8_t PROGMEM RT_HW_PGM_PIN_PWM[]   ={PA0,PA1,PA2,PA3,255,PA5,PA6,PA7,PA8,PA9,PA10,PA11, 255, 255, 255, 255,
										      PB0,PB1,255,PB3,PB4,PB5,PB6,PB7,PB8,PB9,PB10, 255, 255,PB13,PB14,PB15, RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DAC[]   ={PA4,PA5, RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_INT[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PA8,PA9,PA10,PA11,PA12, 255, 255,PA15,
										      PB0,PB1,255,PB3,PB4,PB5,PB6,PB7,PB8,PB9,PB10,PB11,PB12,PB13,PB14,PB15,
										      PC0,PC1,PC2,PC3,PC4,PC5,PC6,PC7,PC8,PC9,PC10,PC11,PC12,PC13, 255, 255,
										      PD0,PD1,PD2,PD3,PD4,PD5,PD6,PD7,PD8,PD9,PD10,PD11,PD12,PD13,PD14,PD15,
										      PE0,PE1,PE2,PE3,PE4,PE5,PE6,PE7,PE8,PE9,PE10,PE11,PE12,PE13,PE14,PE15, RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_N5V[]	={PA4,PA5, RT_HW_PGM_END};	
//-----Тестовые пины-------------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_DBG[]	={PE3, PE4, PE5,        RT_HW_PGM_END};	//--debug1,debug2;	
const uint8_t PROGMEM RT_HW_PGM_PIN_OUT[] 	={PB0, PB1, PC0,        RT_HW_PGM_END};	//--PWM0,PWM1,led,dev;
const uint8_t PROGMEM RT_HW_PGM_PIN_INP[] 	={PA1, PC1, PE4,PE5,    RT_HW_PGM_END};	//--A0,A1,btn1,btn2,btn3;
const uint8_t PROGMEM RT_HW_PGM_PIN_DCT[] 	={PA4, PA5,             RT_HW_PGM_END};	//--DAC0,DAC1,TCH0;
const uint8_t PROGMEM RT_HW_PGM_PIN_DEV[] 	={PD4, PD5, PD6, PD7,   RT_HW_PGM_END};	//--DS1820,DHT22,HC-SR04;
const uint8_t PROGMEM RT_HW_PGM_PIN_CSS[] 	={PE12,PE13,PE14,PE15,  RT_HW_PGM_END};	//--CS SPI:595,LCD,NRF,DEVl 	
const uint8_t PROGMEM RT_HW_PGM_PIN_LC6[] 	={RT_HW_PGM_END};						//--Пины для подключения LCD по 4-х битной шине;
const uint8_t PROGMEM RT_HW_PGM_PIN_TFT[] 	={RT_HW_PGM_END};						//--Пины(дополнительные) TFT дисплея(SPI);
const uint8_t PROGMEM RT_HW_PGM_PIN_SSP[] 	={RT_HW_PGM_END};						//--Пины программного SPI;	
//-----Тестовые адреса-----------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_ADR_I2C[] 	={63,62,32,33,			RT_HW_PGM_END}; //--lcd1,lcd2,mcp1,mcp2;
//-------------------------------------------------------------------------------------------------
#endif
//*************************************************************************************************
//							2.Контроллер типа STM32F407Vx
 //                                          RT_HW_BOARD_STM32MASTER_F4_GENERIC_F407V
//*************************************************************************************************
#if !defined(RT_HW_BOARD_SELECT) && (defined(RT_HW_BOARD_M_generic_f407v) ||\
									 defined(RT_HW_BOARD_D_GENERIC_F407VETX) || defined(RT_HW_BOARD_D_GENERIC_F407VGTX))
//---------------------------------------------------------------------------------------------------
#if                                  defined(RT_HW_BOARD_M_generic_f407v) 
#define        RT_HW_BOARD_SELECT	            "BOARD (M) generic_f407v"
#define        RT_HW_BLOCK_AVAILABLE_FOR_WRITE
//----------------------------------------------------------------------------------------------------
#elif                                defined(RT_HW_BOARD_D_GENERIC_F407VETX) || defined(RT_HW_BOARD_D_GENERIC_F407VGTX)
#define        RT_HW_BOARD_SELECT	            "BOARD (D) GENERIC_F407VETX(VGTX)"
//----------------------------------------------------------------------------------------------------
#else
#define        RT_HW_BOARD_SELECT	            "BOARD (X) F407V"	
#endif
//------------------------------------------------------------------------------------------------
#define RT_HW_BOARD_MEMORY 	  "FLASH=512Kb; RAM=128Kb;"						//--Параметры памяти;
#define RT_HW_PERMIT_UART0
//#define RT_HW_PERMIT_UART1
#define RT_HW_PERMIT_UART2
#define RT_HW_PERMIT_UART3
#define RT_HW_PERMIT_UART4
#define RT_HW_PERMIT_UART5
//#define RT_HW_PERMIT_UART6
#define RT_HW_PERMIT_CAN
#define RT_HW_PERMIT_I2C0
#define RT_HW_PERMIT_I2C1
#define RT_HW_PERMIT_SPI0
//#define RT_HW_PERMIT_SPI1
#define RT_HW_PERMIT_DAC													//--Разрешение работы с DAC;
//------Системные пины-----------------------------------------------------------------------------
enum   {RT_HW_BOARD_CONTROL=PE2, RT_HW_BOARD_LED=PE6, RT_HW_BOARD_BUTTON=PE4};//--Пины контроль,led,кнопка;
//------Параметры контроллера общие----------------------------------------------------------------	
enum{RT_HW_PIN_QNT_MAX=80,	RT_HW_FCPU=168, 		RT_HW_VCC=3300};
//-----Параметры UART------------------------------------------------------------------------------	
enum   {RT_HW_UART0_RX=PA12, RT_HW_UART0_TX=PA11,	//--USB
		RT_HW_UART1_RX=PA10, RT_HW_UART1_TX=PA9,  
		RT_HW_UART2_RX=PA3,  RT_HW_UART2_TX=PA2, 
		RT_HW_UART3_RX=PB11, RT_HW_UART3_TX=PB10, 
		RT_HW_UART4_RX=PC11, RT_HW_UART4_TX=PC10,
        RT_HW_UART5_RX=PD2,  RT_HW_UART5_TX=PC12, 
		RT_HW_UART6_RX=PC7,  RT_HW_UART6_TX=PC6};	
//-----Параметры CAN------------------------------------------------------------------------------	
enum   {RT_HW_CAN_RX=PD0,    RT_HW_CAN_TX=PD1};	
//-----Параметры I2C------------------------------------------------------------------------------	
enum   {RT_HW_I2C0_SDA=PB7,  RT_HW_I2C0_SCL=PB6,  RT_HW_I2C0_MODE_FM=RT_HW_I2C_MODE_FM,
        RT_HW_I2C1_SDA=PB11, RT_HW_I2C1_SCL=PB10, RT_HW_I2C1_MODE_FM=RT_HW_I2C_MODE_FM}; 
//-----Параметры SPI------------------------------------------------------------------------------	
enum   {RT_HW_SPI0_SCK=PA5,  RT_HW_SPI0_MISO=PA6,  RT_HW_SPI0_MOSI=PA7,  RT_HW_SPI0_SS=PA4,  
        RT_HW_SPI1_SCK=PB13, RT_HW_SPI1_MISO=PB14, RT_HW_SPI1_MOSI=PB15, RT_HW_SPI1_SS=PB12};
//-----Системные параметры-------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_SYS_PAR[]	={12,       RT_HW_PGM_END};  //--SYS->depth;
const uint8_t PROGMEM RT_HW_PGM_SYS_ADC[] 	={12,16,20, RT_HW_PGM_END};  //--ADC->depth,drift,null;
const uint8_t PROGMEM RT_HW_PGM_SYS_TCH[] 	={  		RT_HW_PGM_END};  //--TCH->depth,drift,null; 
const uint8_t PROGMEM RT_HW_PGM_SYS_PWM[] 	={16,10,	RT_HW_PGM_END};  //--PWM->depth,freq; 
const uint8_t PROGMEM RT_HW_PGM_SYS_DAC[] 	={12,		RT_HW_PGM_END};  //--DAC->depth; 
const uint8_t PROGMEM RT_HW_PGM_SYS_PIN[] 	={RT_HW_BOARD_CONTROL, RT_HW_BOARD_LED, RT_HW_BOARD_BUTTON, RT_HW_PGM_END};  //--Пины->control,led; 
//-----Параметры коммуникаций----------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_I2C[] 	={RT_HW_I2C0_SDA, RT_HW_I2C0_SCL, RT_HW_I2C1_SDA,  RT_HW_I2C1_SCL, RT_HW_PGM_END}; //--adr,SDA,SCL,mode; 
const uint8_t PROGMEM RT_HW_PGM_PIN_SPI[] 	={RT_HW_SPI0_SCK, RT_HW_SPI0_MISO, RT_HW_SPI0_MOSI, RT_HW_SPI0_SS,
											  RT_HW_SPI1_SCK, RT_HW_SPI1_MISO, RT_HW_SPI1_MOSI, RT_HW_SPI1_SS,	RT_HW_PGM_END}; 
const uint8_t PROGMEM RT_HW_PGM_PIN_UHS[] 	={RT_HW_UART0_RX, RT_HW_UART0_TX, 
										      RT_HW_UART1_RX, RT_HW_UART1_TX, RT_HW_UART2_RX, RT_HW_UART2_TX, 
										      RT_HW_UART3_RX, RT_HW_UART3_TX, RT_HW_UART4_RX, RT_HW_UART4_TX,
                                              RT_HW_UART5_RX, RT_HW_UART5_TX, RT_HW_UART6_RX, RT_HW_UART6_TX,  RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_USS[] 	={RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_CAN[] 	={RT_HW_CAN_RX,RT_HW_CAN_TX, RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_BTH[] 	={RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_ETH[] 	={1,RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_WFI[] 	={RT_HW_PGM_END};
//-----Доступные пины контроллера------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_ALL[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PA8,PA9,PA10,PA11,PA12, 255, 255,PA15,
											  PB0,PB1,255,PB3,PB4,PB5,PB6,PB7,PB8,PB9,PB10,PB11,PB12,PB13,PB14,PB15,
										      PC0,PC1,PC2,PC3,PC4,PC5,PC6,PC7,PC8,PC9,PC10,PC11,PC12,PC13, 255, 255,
										      PD0,PD1,PD2,PD3,PD4,PD5,PD6,PD7,PD8,PD9,PD10,PD11,PD12,PD13,PD14,PD15,
										      PE0,PE1,PE2,PE3,PE4,PE5,PE6,PE7,PE8,PE9,PE10,PE11,PE12,PE13,PE14,PE15, RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DIN[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PA8,PA9,PA10,PA11,PA12, 255, 255,PA15,
										      PB0,PB1,255,PB3,PB4,PB5,PB6,PB7,PB8,PB9,PB10,PB11,PB12,PB13,PB14,PB15,
										      PC0,PC1,PC2,PC3,PC4,PC5,PC6,PC7,PC8,PC9,PC10,PC11,PC12,PC13, 255, 255,
										      PD0,PD1,PD2,PD3,PD4,PD5,PD6,PD7,PD8,PD9,PD10,PD11,PD12,PD13,PD14,PD15,
										      PE0,PE1,PE2,PE3,PE4,PE5,PE6,PE7,PE8,PE9,PE10,PE11,PE12,PE13,PE14,PE15, RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_ADC[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PB0,PB1,PC0, PC1, PC2, PC3, PC4, PC5,  RT_HW_PGM_END};									
const uint8_t PROGMEM RT_HW_PGM_PIN_TCH[] 	={RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_DOT[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PA8,PA9,PA10,PA11,PA12, 255, 255,PA15,
										      PB0,PB1,255,PB3,PB4,PB5,PB6,PB7,PB8,PB9,PB10,PB11,PB12,PB13,PB14,PB15,
										      PC0,PC1,PC2,PC3,PC4,PC5,PC6,PC7,PC8,PC9,PC10,PC11,PC12,PC13, 255, 255,
										      PD0,PD1,PD2,PD3,PD4,PD5,PD6,PD7,PD8,PD9,PD10,PD11,PD12,PD13,PD14,PD15,
                                              PE0,PE1,PE2,PE3,PE4,PE5,PE6,PE7,PE8,PE9,PE10,PE11,PE12,PE13,PE14,PE15, RT_HW_PGM_END}; 
const uint8_t PROGMEM RT_HW_PGM_PIN_PWM[]   ={PA0,PA1,PA2,PA3,255,PA5,PA6,PA7,PA8,PA9,PA10,PA11, 255, 255, 255, 255,
										      PB0,PB1,255,PB3,PB4,PB5,PB6,PB7,PB8,PB9,PB10, 255, 255,PB13,PB14,PB15, RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DAC[]   ={PA4,PA5, RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_INT[] 	={PA0,PA1,PA2,PA3,PA4,PA5,PA6,PA7,PA8,PA9,PA10,PA11,PA12, 255, 255,PA15,
										      PB0,PB1,255,PB3,PB4,PB5,PB6,PB7,PB8,PB9,PB10,PB11,PB12,PB13,PB14,PB15,
										      PC0,PC1,PC2,PC3,PC4,PC5,PC6,PC7,PC8,PC9,PC10,PC11,PC12,PC13, 255, 255,
										      PD0,PD1,PD2,PD3,PD4,PD5,PD6,PD7,PD8,PD9,PD10,PD11,PD12,PD13,PD14,PD15,
										      PE0,PE1,PE2,PE3,PE4,PE5,PE6,PE7,PE8,PE9,PE10,PE11,PE12,PE13,PE14,PE15, RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_N5V[]	={PA4,PA5, RT_HW_PGM_END};	
//-----Тестовые пины-------------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_DBG[]	={PE3, PE4, PE5,        RT_HW_PGM_END};	//--debug1,debug2;	
const uint8_t PROGMEM RT_HW_PGM_PIN_OUT[] 	={PB0, PB1, PC0,        RT_HW_PGM_END};	//--PWM0,PWM1,led,dev;
const uint8_t PROGMEM RT_HW_PGM_PIN_INP[] 	={PA1, PC1, PE4,PE5,    RT_HW_PGM_END};	//--A0,A1,btn1,btn2,btn3;
const uint8_t PROGMEM RT_HW_PGM_PIN_DCT[] 	={PA4, PA5,             RT_HW_PGM_END};	//--DAC0,DAC1,TCH0;
const uint8_t PROGMEM RT_HW_PGM_PIN_DEV[] 	={PD4, PD5, PD6, PD7,   RT_HW_PGM_END};	//--DS1820,DHT22,HC-SR04;
const uint8_t PROGMEM RT_HW_PGM_PIN_CSS[] 	={PE12,PE13,PE14,PE15,  RT_HW_PGM_END};	//--CS SPI:595,LCD,NRF,DEVl 	
const uint8_t PROGMEM RT_HW_PGM_PIN_LC6[] 	={RT_HW_PGM_END};						//--Пины для подключения LCD по 4-х битной шине;
const uint8_t PROGMEM RT_HW_PGM_PIN_TFT[] 	={RT_HW_PGM_END};						//--Пины(дополнительные) TFT дисплея(SPI);
const uint8_t PROGMEM RT_HW_PGM_PIN_SSP[] 	={RT_HW_PGM_END};						//--Пины программного SPI;	
//-----Тестовые адреса-----------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_ADR_I2C[] 	={63,62,32,33,			RT_HW_PGM_END}; //--lcd1,lcd2,mcp1,mcp2;
//-------------------------------------------------------------------------------------------------
#endif

//=================================================================================================
