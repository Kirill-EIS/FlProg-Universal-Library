#include "RT_HW_BASE.h"
RT_HW_BASE:: RT_HW_BASE(){							//==Конструктор;
	//console.dir=0; console.begin=console.ready=console.head=console.mess=0; 


//-------------------------------------------------------------------------------------------------
//			Настройка диспетчера задач
//-------------------------------------------------------------------------------------------------
shed.cnt50=shed.cnt100=shed.cnt250=shed.gen250=0;
shed.quick.cnt=shed.fast.cnt=shed.slow.cnt=shed.back.cnt=shed.frdm.cnt=0;
shed.quick.qnt=5; 							//--Кол-во срочных   задач (период  10мс);
shed.fast.qnt=4;							//--Кол-во быстрых   задач (период  25мс);
shed.slow.qnt=4; 							//--Кол-во медленных задач (период 250мс);
shed.back.qnt=5;   							//--Кол-во фоновых   задач (период 100мс);
shed.frdm.qnt=25; 							//--Кол-во свободных задач (период loop()-когда нет вызванных задач);
shed.periodQuick=10;						//--Период оперативных задач в mc;
shed.periodBase=25;							//--Период оперативных задач в mc;
shed.run=0;									//--Флаги разрешения запусков задач(quick,fast,slow,back,frdm);
//-------------------------------------------------------------------------------------------------
//			Настройка общих параметров
//-------------------------------------------------------------------------------------------------
device.board.codeArch= RT_HW_ARCH_CODE;		//--Код архитектуры контроллера;
device.board.codeBoard=RT_HW_BOARD_CODE;	//--Код контроллера;
//-------------------------------------------------------------------------------------------------
//			Настройка параметров консоли
//struct RT_HW_STRUCT_CONSOLE {uint8_t dir; uint8_t cnt:4, resetHead:1; uint8_t state; uint8_t numUart; uint32_t speed;};	
//-------------------------------------------------------------------------------------------------
console.dir=console.numUart=0;	//--Очистка регистра состояния консоли;
console.speed=0;
//-------------------------------------------------------------------------------------------------
//			Настройка рабочих регистров для работы с пинами
//-------------------------------------------------------------------------------------------------
device.pin.control	 = readArrPGM (RT_HW_PGM_SYS_PIN_ID, 0);	//--Пин контрольного светодиода; 
device.pin.led	 	 = readArrPGM (RT_HW_PGM_SYS_PIN_ID, 1);	//--Пин светодиода на плате;
device.pin.button	 = readArrPGM (RT_HW_PGM_SYS_PIN_ID, 2);	//--Пин кнопки на плате; 
device.dbg.pinDebug  = readArrPGM (RT_HW_PGM_PIN_DBG_ID, 0);	//--Пин отладки;
device.dbg.timeDebug = readArrPGM (RT_HW_PGM_PIN_DBG_ID, 3);	//--Время задержки для функции debugToPin; 
device.depth.sys	 = readArrPGM(RT_HW_PGM_SYS_PAR_ID, 0);	//--Cистемное разрешение (8,10,12,16); 
device.depth.adc	 = readArrPGM(RT_HW_PGM_SYS_ADC_ID, 0); //--Разрешение ADC;
device.depth.drift	 = readArrPGM(RT_HW_PGM_SYS_ADC_ID,	1); //--Допустимый дрейф показаний ADC;
device.depth.vNull	 = readArrPGM(RT_HW_PGM_SYS_ADC_ID, 2); //--Допустимый дрейф нуля ADC;
device.depth.tch	 = readArrPGM(RT_HW_PGM_SYS_TCH_ID, 0);	//--Разрешение TCH (ESP32);
device.depth.pwm	 = readArrPGM(RT_HW_PGM_SYS_PWM_ID, 0);	//--Разрешение PWM; 
device.depth.dac	 = readArrPGM(RT_HW_PGM_SYS_DAC_ID, 0); //--Разрешение DAC;			 
//-----Настройка разрядности ADC и PWM--------------------------------------------------------------
#if !defined(RT_HW_BLOCK_SET_RESOLUTION_ADC) 
	analogReadResolution(device.depth.adc);//--ADC; 
#endif 
//-----Настройка разрядности PWM-------------------------------------------------------------------
#if !defined(RT_HW_BLOCK_SET_RESOLUTION_PWM)
	analogWriteResolution(device.depth.pwm);//--PWM; 
#endif  
//-----Разрешение использование выводов JTDI,JTDO,JRST(PA15,PB3,PB4) как GPIO ((M)STM32F1---------
#if defined(RT_HW_PERMIT_ENABLE_PIN_JTAG)	
	afio_cfg_debug_ports(AFIO_DEBUG_SW_ONLY);	
#endif
//-----Настройка DAC контроллера M5Stack-Core-ESP32------------------------------------------------
#if defined(RT_HW_BOARD_M5Stack_Core_ESP32) 
dacWrite(25,0);		//--Чтобы избежать звуков зуммера при включении;
#endif 
//--------------------------------------------------------------------------------------------------
//			Установка параметров UART
//-------------------------------------------------------------------------------------------------
console.numUart=0; 
device.uart.begin=device.uart.ready=0; 
//-------------------------------------------------------------------------------------------------
//			Установка параметров i2c (значения default)
// биты параметра state->enum {RT_HW_I2C_STATE_INIT=0, RT_HW_I2C_STATE_SLAVE=1, RT_HW_I2C_STATE_BUSY=7}
//-------------------------------------------------------------------------------------------------
#if defined(RT_HW_PERMIT_I2C0)								
device.i2c0.state   = 0; 									//--Состояние;	
device.i2c0.adr	 	= 0;									//--Адрес; 
device.i2c0.sda	 	= readArrPGM(RT_HW_PGM_PIN_I2C_ID,0);	//--Пин SDA; 
device.i2c0.scl		= readArrPGM(RT_HW_PGM_PIN_I2C_ID,1);	//--Пин SCL; 
device.i2c0.speed	= RT_HW_I2C_SPEED_DEFAULT * 1000UL;		//--Частота;
#endif
#if defined(RT_HW_PERMIT_I2C1)
device.i2c1.state   = 0; 									//--Состояние;		
device.i2c1.adr	 	= 0;									//--Адрес; 
device.i2c1.sda	 	= readArrPGM(RT_HW_PGM_PIN_I2C_ID,2);	//--Пин SDA; 
device.i2c1.scl		= readArrPGM(RT_HW_PGM_PIN_I2C_ID,3);	//--Пин SCL; 
device.i2c1.speed	= RT_HW_I2C_SPEED_DEFAULT * 1000UL;		//--Частота;
#endif
#if defined(RT_HW_PERMIT_I2C2)
device.i2c2.state   = 0; 									//--Состояние;		
device.i2c2.adr	 	= 0;									//--Адрес; 
device.i2c2.sda	 	= readArrPGM(RT_HW_PGM_PIN_I2C_ID,4);	//--Пин SDA; 
device.i2c2.scl		= readArrPGM(RT_HW_PGM_PIN_I2C_ID,5);	//--Пин SCL; 
device.i2c2.speed	= RT_HW_I2C_SPEED_DEFAULT *1000UL;		//--Частота;	
#endif
//-------------------------------------------------------------------------------------------------
//			Установка параметров SPI (значения default)
// биты параметра state->enum {RT_HW_SPI_STATE_INIT=0, RT_HW_SPI_STATE_SLAVE=1, RT_HW_SPI_STATE_BUSY=7}
//struct RT_HW_STRUCT_SPI   	{int8_t   sck,miso,mosi,ss; char mode='M'; uint16_t freq;};	
//-------------------------------------------------------------------------------------------------
#if defined(RT_HW_PERMIT_SPI0)								
device.spi0.state   = 0; 									//--Состояние;	
device.spi0.sck	 	= readArrPGM(RT_HW_PGM_PIN_SPI_ID,0);	//--Пин SCK; 
device.spi0.miso	= readArrPGM(RT_HW_PGM_PIN_SPI_ID,1);	//--Пин MISO; 
device.spi0.mosi	= readArrPGM(RT_HW_PGM_PIN_SPI_ID,2);	//--Пин MOSI; 
device.spi0.ss		= readArrPGM(RT_HW_PGM_PIN_SPI_ID,3);	//--Пин SS (Slave); 
#endif
#if defined(RT_HW_PERMIT_SPI1)
device.spi1.state   = 0; 									//--Состояние;	
device.spi1.sck	 	= readArrPGM(RT_HW_PGM_PIN_SPI_ID,4);	//--Пин SCK; 
device.spi1.miso	= readArrPGM(RT_HW_PGM_PIN_SPI_ID,5);	//--Пин MISO; 
device.spi1.mosi	= readArrPGM(RT_HW_PGM_PIN_SPI_ID,6);	//--Пин MOSI; 
device.spi1.ss		= readArrPGM(RT_HW_PGM_PIN_SPI_ID,7);	//--Пин SS (Slave); 
#endif
#if defined(RT_HW_PERMIT_SPI2)
device.spi2.state   = 0; 									//--Состояние;	
device.spi2.sck	 	= readArrPGM(RT_HW_PGM_PIN_SPI_ID,8);	//--Пин SCK; 
device.spi2.miso	= readArrPGM(RT_HW_PGM_PIN_SPI_ID,9);	//--Пин MISO; 
device.spi2.mosi	= readArrPGM(RT_HW_PGM_PIN_SPI_ID,10);	//--Пин MOSI; 
device.spi2.ss		= readArrPGM(RT_HW_PGM_PIN_SPI_ID,11);	//--Пин SS (Slave); 	
#endif
//-------------------------------------------------------------------------------------------------
};
			
//---------------------------------------------------------------------------------------		
RT_HW_BASE RT_HW_Base;								//==Создание внешнего объекта	
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++