//*************************************************************************************************
//							1.Контроллеры типа Arduino UNO [standrat.variant]
//*************************************************************************************************
#if !defined(RT_HW_BOARD_SELECT) && defined(RT_HW_BOARD_AVR_UNO)	
#define      RT_HW_BOARD_SELECT 	             "BOARD AVR UNO"			//--Идентификатор выбора платы
//-------------------------------------------------------------------------------------------------
#define RT_HW_BOARD_MEMORY	 "FLASH=32Kb, RAM=2Kb, EEPROM=1Kb"				//--Параметры памяти;
#define RT_HW_PERMIT_UART0													//--Разрешение работы с UART0; 
#define RT_HW_PERMIT_UARTS													//--Разрешение работы с SoftSerial UART;
#define RT_HW_PERMIT_I2C0													//--Разрешение работы с i2c0; 
#define RT_HW_PERMIT_SPI0													//--Разрешение работы с spi0; 
//------Системные пины-----------------------------------------------------------------------------
enum   {RT_HW_BOARD_CONTROL=10, RT_HW_BOARD_LED=13, RT_HW_BOARD_BUTTON=8};	//--Пины контроль,led,кнопка;
//-----Параметры контроллера общие-----------------------------------------------------------------	
enum   {RT_HW_PIN_QNT_MAX=20,	RT_HW_FCPU=16, RT_HW_VCC=5000};	
//-----Параметры UART------------------------------------------------------------------------------	
enum   {RT_HW_UART0_RX=0, RT_HW_UART0_TX=1};
enum   {RT_HW_UARTS_RX=8, RT_HW_UARTS_TX=9}; //--Пины с учетом особенностей <SoftwareSerial.h>	
//-----Параметры I2C------------------------------------------------------------------------------	
enum   {RT_HW_I2C0_SDA=18, RT_HW_I2C0_SCL=19, RT_HW_I2C0_MODE_FM=RT_HW_I2C_MODE_FM};  
//-----Параметры SPI------------------------------------------------------------------------------	
enum   {RT_HW_SPI0_SCK=13, RT_HW_SPI0_MISO=12, RT_HW_SPI0_MOSI=11, RT_HW_SPI0_SS=10};
//-----Системные параметры-------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_SYS_PAR[] 	={12,			   RT_HW_PGM_END};  //--SYS->depth;
const uint8_t PROGMEM RT_HW_PGM_SYS_PIN[] 	={RT_HW_BOARD_CONTROL, RT_HW_BOARD_LED, RT_HW_BOARD_BUTTON, RT_HW_PGM_END};  //--Пины->control,led; 
const uint8_t PROGMEM RT_HW_PGM_SYS_ADC[] 	={10,3,4, 		   RT_HW_PGM_END};  //--ADC->depth,drift,null;
const uint8_t PROGMEM RT_HW_PGM_SYS_TCH[] 	={         	   	   RT_HW_PGM_END};  //--TCH->depth,drift,null; 
const uint8_t PROGMEM RT_HW_PGM_SYS_PWM[] 	={ 8,10,           RT_HW_PGM_END};  //--PWM->depth,freq; 
const uint8_t PROGMEM RT_HW_PGM_SYS_DAC[] 	={          	   RT_HW_PGM_END};  //--DAC->depth; 
//-----Системные пины и параметры коммуникаций------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_I2C[]	={RT_HW_I2C0_SDA,  RT_HW_I2C0_SCL,	    				RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_SPI[]	={RT_HW_SPI0_SCK,  RT_HW_SPI0_MISO, RT_HW_SPI0_MOSI, RT_HW_SPI0_SS, RT_HW_PGM_END}; 
const uint8_t PROGMEM RT_HW_PGM_PIN_UHS[]	={RT_HW_UART0_RX,  RT_HW_UART0_TX,						RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_USS[]	={RT_HW_UARTS_RX,  RT_HW_UARTS_TX,						RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_CAN[]	={														RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_BTH[]	={														RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_ETH[]	={														RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_WFI[]	={														RT_HW_PGM_END};
//-----Доступные пины контроллера------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_ALL[]	={0 , 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,16,17,18,19,RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DIN[]	={2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,16,17,18,19,		  RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_ADC[]	={14,15,16,17,18,19,									      RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_TCH[]	={															  RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DOT[]	={2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,		      RT_HW_PGM_END}; 
const uint8_t PROGMEM RT_HW_PGM_PIN_PWM[]	={3,5,6,9,10,11,											  RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DAC[]	={															  RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_INT[]	={2,3,														  RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_N5V[]	={RT_HW_PGM_END};	
//-----Тестовые пины и адреса------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_DBG[]	={	    			RT_HW_PGM_END};	// debug1,debug2,debug3;	
const uint8_t PROGMEM RT_HW_PGM_PIN_OUT[]	={5,6,16,         	RT_HW_PGM_END};	// PWM0,PWM1,led1,led2;
const uint8_t PROGMEM RT_HW_PGM_PIN_INP[]	={17,255,8,        	RT_HW_PGM_END};	// A0,A1,btn1,btn2;
const uint8_t PROGMEM RT_HW_PGM_PIN_DCT[]	={          		RT_HW_PGM_END};	// DAC0,DAC1,TCH0;
const uint8_t PROGMEM RT_HW_PGM_PIN_DEV[]	={7,4,2,3,			RT_HW_PGM_END};	// DS1820,DHT22,HC-SR04(Echo,Trig)
const uint8_t PROGMEM RT_HW_PGM_PIN_CSS[]	={14,15,16,			RT_HW_PGM_END};	// CS SPI:595,LCD,NRF,DEVl 		
const uint8_t PROGMEM RT_HW_PGM_PIN_LC6[]	={					RT_HW_PGM_END};	// Пины для подключения LCD по 4-х битной шине;
const uint8_t PROGMEM RT_HW_PGM_PIN_TFT[]	={					RT_HW_PGM_END};	// Пины(дополнительные) TFT дисплея(SPI);
const uint8_t PROGMEM RT_HW_PGM_PIN_SSP[] 	={					RT_HW_PGM_END};	// Пины программного SPI;	
const uint8_t PROGMEM RT_HW_PGM_ADR_I2C[] 	={39,62,32,33,		RT_HW_PGM_END};	// lcd1,lcd2,mcp1,mcp2;
//-------------------------------------------------------------------------------------------------
#endif
//*************************************************************************************************
//							2.Контроллеры типа Arduino Nano [egthanaloginputs.variant]
//*************************************************************************************************
#if !defined(RT_HW_BOARD_SELECT) &&  defined(RT_HW_BOARD_AVR_NANO)
#define      RT_HW_BOARD_SELECT                   "BOARD AVR NANO" 			//--Идентификатор выбора платы
//-------------------------------------------------------------------------------------------------
#define RT_HW_BOARD_MEMORY	 "FLASH=32Kb, RAM=2Kb, EEPROM=1Kb"				//--Параметры памяти;
#define RT_HW_PERMIT_UART0													//--Разрешение работы с UART0; 
#define RT_HW_PERMIT_UARTS													//--Разрешение работы с SoftSerial UART;
#define RT_HW_PERMIT_I2C0													//--Разрешение работы с i2c0; 
#define RT_HW_PERMIT_SPI0													//--Разрешение работы с spi0; 
//------Системные пины------------------------------------------------------------------------------
enum   {RT_HW_BOARD_CONTROL=10, RT_HW_BOARD_LED=13, RT_HW_BOARD_BUTTON=8};	//--Пины контроль,led,кнопка;
//-----Параметры контроллера общие-----------------------------------------------------------------	
enum   {RT_HW_PIN_QNT_MAX=22,	RT_HW_FCPU=16, RT_HW_VCC=5000};
//-----Параметры UART------------------------------------------------------------------------------	
enum   {RT_HW_UART0_RX=0, RT_HW_UART0_TX=1};
enum   {RT_HW_UARTS_RX=8, RT_HW_UARTS_TX=9}; //--Пины для SoftSerial задаются из особенностей библиотеки <SoftwareSerial.h>	
//-----Параметры I2C------------------------------------------------------------------------------	
enum   {RT_HW_I2C0_SDA=18, RT_HW_I2C0_SCL=19, RT_HW_I2C0_MODE_FM=RT_HW_I2C_MODE_FM};  
//-----Параметры SPI------------------------------------------------------------------------------	
enum   {RT_HW_SPI0_SCK=13, RT_HW_SPI0_MISO=12, RT_HW_SPI0_MOSI=11, RT_HW_SPI0_SS=10};
//-----Системные параметры-------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_SYS_PAR[] 	={12,			   RT_HW_PGM_END};  //--SYS->depth;
const uint8_t PROGMEM RT_HW_PGM_SYS_PIN[] 	={RT_HW_BOARD_CONTROL, RT_HW_BOARD_LED, RT_HW_BOARD_BUTTON, RT_HW_PGM_END}; 
const uint8_t PROGMEM RT_HW_PGM_SYS_ADC[] 	={10,3,4, 		   RT_HW_PGM_END};  //--ADC->depth,drift,null;
const uint8_t PROGMEM RT_HW_PGM_SYS_TCH[] 	={         	   	   RT_HW_PGM_END};  //--TCH->depth,drift,null; 
const uint8_t PROGMEM RT_HW_PGM_SYS_PWM[] 	={ 8,10,           RT_HW_PGM_END};  //--PWM->depth,freq; 
const uint8_t PROGMEM RT_HW_PGM_SYS_DAC[] 	={          	   RT_HW_PGM_END};  //--DAC->depth; 
//-----Системные пины и параметры коммуникаций------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_I2C[]	={RT_HW_I2C0_SDA,  RT_HW_I2C0_SCL,	    				RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_SPI[]	={RT_HW_SPI0_SCK,  RT_HW_SPI0_MISO, RT_HW_SPI0_MOSI, RT_HW_SPI0_SS, RT_HW_PGM_END}; 
const uint8_t PROGMEM RT_HW_PGM_PIN_UHS[]	={RT_HW_UART0_RX,  RT_HW_UART0_TX,						RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_USS[]	={RT_HW_UARTS_RX,  RT_HW_UARTS_TX,						RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_CAN[]	={														RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_BTH[]	={														RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_ETH[]	={														RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_WFI[]	={														RT_HW_PGM_END};
//-----Доступные пины контроллера------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_ALL[]	={ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,16,17,18,19,20,21,	RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DIN[]	={ 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,16,17,18,19,				RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_ADC[]	={14,15,16,17,18,19,20,21,												RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_TCH[]	={																		RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DOT[]	={2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,					RT_HW_PGM_END}; 
const uint8_t PROGMEM RT_HW_PGM_PIN_PWM[]	={3,5,6,9,10,11,														RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DAC[]	={																		RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_INT[]	={2,3,																	RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_N5V[]	={RT_HW_PGM_END};	
//-----Тестовые пины и адреса------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_DBG[] 	={	    			RT_HW_PGM_END};	// debug1,debug2,debug3;	
const uint8_t PROGMEM RT_HW_PGM_PIN_OUT[]	={5,6,16,17,        RT_HW_PGM_END};	// PWM0,PWM1,led1,led2;
const uint8_t PROGMEM RT_HW_PGM_PIN_INP[]	={20,21,8,	      	RT_HW_PGM_END};	// A0,A1,btn1,btn2;
const uint8_t PROGMEM RT_HW_PGM_PIN_DCT[]	={          		RT_HW_PGM_END};	// DAC0,DAC1,TCH0;
const uint8_t PROGMEM RT_HW_PGM_PIN_DEV[]	={7,4,2,3,			RT_HW_PGM_END};	// DS1820,DHT22,HC-SR04(Echo,Trig);
const uint8_t PROGMEM RT_HW_PGM_PIN_CSS[]	={14,15,16,			RT_HW_PGM_END};	// CS SPI:595,LCD,NRF,DEVl 		
const uint8_t PROGMEM RT_HW_PGM_PIN_LC6[] 	={					RT_HW_PGM_END};	// Пины для подключения LCD по 4-х битной шине;
const uint8_t PROGMEM RT_HW_PGM_PIN_TFT[]	={					RT_HW_PGM_END};	// Пины(дополнительные) TFT дисплея(SPI);
const uint8_t PROGMEM RT_HW_PGM_PIN_SSP[] 	={					RT_HW_PGM_END};	// Пины программного SPI;	
const uint8_t PROGMEM RT_HW_PGM_ADR_I2C[] 	={39,62,32,33,		RT_HW_PGM_END};	// lcd1,lcd2,mcp1,mcp2;
//-------------------------------------------------------------------------------------------------
#endif
//*************************************************************************************************
//							3.Контроллеры типа Arduino PRO or mini [egthanaloginputs.variant]
//*************************************************************************************************
#if !defined(RT_HW_BOARD_SELECT) && defined(RT_HW_BOARD_AVR_PRO)
#define      RT_HW_BOARD_SELECT 	             "BOARD AVR PRO"			//--Идентификатор выбора платы
//-------------------------------------------------------------------------------------------------
#define RT_HW_BOARD_MEMORY	 "FLASH=32Kb, RAM=2Kb, EEPROM=1Kb"				//--Параметры памяти;
#define RT_HW_PERMIT_UART0													//--Разрешение работы с UART0; 
#define RT_HW_PERMIT_UARTS													//--Разрешение работы с SoftSerial UART;
#define RT_HW_PERMIT_I2C0													//--Разрешение работы с i2c0; 
#define RT_HW_PERMIT_SPI0													//--Разрешение работы с spi0; 
//------Системные пины------------------------------------------------------------------------------
enum   {RT_HW_BOARD_CONTROL=10, RT_HW_BOARD_LED=13, RT_HW_BOARD_BUTTON=8};	//--Пины контроль,led,кнопка;
//-----Параметры контроллера общие-----------------------------------------------------------------	
enum   {RT_HW_PIN_QNT_MAX=22,	RT_HW_FCPU=16, RT_HW_VCC=5000};
//-----Параметры UART------------------------------------------------------------------------------	
enum   {RT_HW_UART0_RX=0, RT_HW_UART0_TX=1};
enum   {RT_HW_UARTS_RX=8, RT_HW_UARTS_TX=9}; //--Пины для SoftSerial задаются из особенностей библиотеки <SoftwareSerial.h>	
//-----Параметры I2C------------------------------------------------------------------------------	
enum   {RT_HW_I2C0_SDA=18, RT_HW_I2C0_SCL=19, RT_HW_I2C0_MODE_FM=RT_HW_I2C_MODE_FM};  
//-----Параметры SPI------------------------------------------------------------------------------	
enum   {RT_HW_SPI0_SCK=13, RT_HW_SPI0_MISO=12, RT_HW_SPI0_MOSI=11, RT_HW_SPI0_SS=10};
//-----Системные параметры-------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_SYS_PAR[]	={12,			   RT_HW_PGM_END};  //--SYS->depth;
const uint8_t PROGMEM RT_HW_PGM_SYS_PIN[] 	={RT_HW_BOARD_CONTROL, RT_HW_BOARD_LED, RT_HW_BOARD_BUTTON, 			RT_HW_PGM_END}; 
const uint8_t PROGMEM RT_HW_PGM_SYS_ADC[] 	={10,3,4, 		   RT_HW_PGM_END};  //--ADC->depth,drift,null;
const uint8_t PROGMEM RT_HW_PGM_SYS_TCH[] 	={         	   	   RT_HW_PGM_END};  //--TCH->depth,drift,null; 
const uint8_t PROGMEM RT_HW_PGM_SYS_PWM[] 	={ 8,10,           RT_HW_PGM_END};  //--PWM->depth,freq; 
const uint8_t PROGMEM RT_HW_PGM_SYS_DAC[] 	={          	   RT_HW_PGM_END};  //--DAC->depth; 
//-----Системные пины и параметры коммуникаций------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_I2C[]	={RT_HW_I2C0_SDA,  RT_HW_I2C0_SCL,	    				RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_SPI[]	={RT_HW_SPI0_SCK,  RT_HW_SPI0_MISO, RT_HW_SPI0_MOSI, RT_HW_SPI0_SS,	RT_HW_PGM_END}; 
const uint8_t PROGMEM RT_HW_PGM_PIN_UHS[]	={RT_HW_UART0_RX,  RT_HW_UART0_TX,						RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_USS[]	={RT_HW_UARTS_RX,  RT_HW_UARTS_TX,						RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_CAN[]	={														RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_BTH[]	={														RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_ETH[]	={														RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_WFI[]	={														RT_HW_PGM_END};
//-----Доступные пины контроллера------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_ALL[]	={0 , 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,16,17,18,19,20,21,	RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DIN[]	={2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,16,17,18,19,					RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_ADC[]	={14,15,16,17,18,19,20,21,												RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_TCH[]	={																		RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DOT[]	={2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,					RT_HW_PGM_END}; 
const uint8_t PROGMEM RT_HW_PGM_PIN_PWM[]	={3,5,6,9,10,11,														RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DAC[]	={																		RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_INT[]	={2,3,																	RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_N5V[]	={RT_HW_PGM_END};	
//-----Тестовые пины и адреса------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_DBG[] 	={	    			RT_HW_PGM_END};	// debug1,debug2,debug3;	
const uint8_t PROGMEM RT_HW_PGM_PIN_OUT[]	={5,6,16,17,        RT_HW_PGM_END};	// PWM0,PWM1,led1,led2;
const uint8_t PROGMEM RT_HW_PGM_PIN_INP[]	={20,21,8,        	RT_HW_PGM_END};	// A0,A1,btn1,btn2;
const uint8_t PROGMEM RT_HW_PGM_PIN_DCT[]	={          		RT_HW_PGM_END};	// DAC0,DAC1,TCH0;
const uint8_t PROGMEM RT_HW_PGM_PIN_DEV[]	={7,4,2,3,			RT_HW_PGM_END};	// DS1820,DHT22,HC-SR04(Echo,Trig)
const uint8_t PROGMEM RT_HW_PGM_PIN_CSS[]	={14,15,			RT_HW_PGM_END};	// CS SPI:595,LCD,NRF,DEVl 		
const uint8_t PROGMEM RT_HW_PGM_PIN_LC6[] 	={					RT_HW_PGM_END};	// Пины для подключения LCD по 4-х битной шине;
const uint8_t PROGMEM RT_HW_PGM_PIN_TFT[] 	={					RT_HW_PGM_END};	// Пины(дополнительные) TFT дисплея(SPI[];
const uint8_t PROGMEM RT_HW_PGM_PIN_SSP[]	={					RT_HW_PGM_END};	// Пины программного SPI;	
const uint8_t PROGMEM RT_HW_PGM_ADR_I2C[] 	={39,62,32,33,		RT_HW_PGM_END};	// lcd1,lcd2,mcp1,mcp2;
//-------------------------------------------------------------------------------------------------
#endif
//*************************************************************************************************
//							3.Контроллер типа MEGA2560 [mega.variant]
//*************************************************************************************************
#if !defined(RT_HW_BOARD_SELECT) &&  defined(RT_HW_BOARD_AVR_MEGA2560)
#define      RT_HW_BOARD_SELECT 	              "BOARD AVR MEGA2560" 		//--Идентификатор выбора платы
//-------------------------------------------------------------------------------------------------
#define RT_HW_BOARD_MEMORY	"FLASH=256Kb,RAM=8Kb,EEPROM=4Kb"				//--Параметры памяти;
#define RT_HW_PERMIT_UART0													//--Разрешение работы с UART0;
#define RT_HW_PERMIT_UART1													//--Разрешение работы с UART1; 
#define RT_HW_PERMIT_UART2													//--Разрешение работы с UART2; 
#define RT_HW_PERMIT_UART3													//--Разрешение работы с UART3;  
#define RT_HW_PERMIT_UARTS													//--Разрешение работы с SoftSerial UART;
#define RT_HW_PERMIT_I2C0													//--Разрешение работы с i2c0; 
#define RT_HW_PERMIT_SPI0													//--Разрешение работы с spi0; 
//------Системные пины------------------------------------------------------------------------------
enum   {RT_HW_BOARD_CONTROL=42, RT_HW_BOARD_LED=13, RT_HW_BOARD_BUTTON=12};	//--Пины контроль,led,кнопка;
//------Параметры контроллера общие-------------------------------------------------------------------	
enum   {RT_HW_PIN_QNT_MAX=70,	RT_HW_FCPU=16, 		RT_HW_VCC=5000};
//-----Параметры UART------------------------------------------------------------------------------	
enum   {RT_HW_UART0_RX=0,  RT_HW_UART0_TX=1, 
		RT_HW_UART1_RX=19, RT_HW_UART1_TX=18, RT_HW_UART2_RX=17, RT_HW_UART2_TX=16, RT_HW_UART3_RX=15, RT_HW_UART3_TX=14};
enum   {RT_HW_UARTS_RX=68, RT_HW_UARTS_TX=69}; 
//-----Параметры I2C------------------------------------------------------------------------------	
enum   {RT_HW_I2C0_SDA=20, RT_HW_I2C0_SCL=21, RT_HW_I2C0_MODE_FM=RT_HW_I2C_MODE_FM};  
//-----Параметры SPI------------------------------------------------------------------------------	
enum   {RT_HW_SPI0_SCK=52, RT_HW_SPI0_MISO=50, RT_HW_SPI0_MOSI=51, RT_HW_SPI0_SS=53};
//-----Системные параметры-------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_SYS_PAR[]	={12,			   	RT_HW_PGM_END};  // SYS->depth;
const uint8_t PROGMEM RT_HW_PGM_SYS_PIN[] 	={RT_HW_BOARD_CONTROL, RT_HW_BOARD_LED, RT_HW_BOARD_BUTTON, RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_SYS_ADC[] 	={10,3,4,			RT_HW_PGM_END};  // ADC->depth,drift,null;
const uint8_t PROGMEM RT_HW_PGM_SYS_TCH[] 	={0,  				RT_HW_PGM_END};  // TCH->depth,drift,null; 
const uint8_t PROGMEM RT_HW_PGM_SYS_PWM[] 	={8,10,				RT_HW_PGM_END};  // PWM->depth,freq; 
const uint8_t PROGMEM RT_HW_PGM_SYS_DAC[]	={0,				RT_HW_PGM_END};  // DAC->depth; 
//-----Системные пины и параметры коммуникаций------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_I2C[]	={RT_HW_I2C0_SDA,  RT_HW_I2C0_SCL,	    				RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_SPI[]	={RT_HW_SPI0_SCK,  RT_HW_SPI0_MISO, RT_HW_SPI0_MOSI, RT_HW_SPI0_SS, RT_HW_PGM_END}; 
const uint8_t PROGMEM RT_HW_PGM_PIN_UHS[]	={RT_HW_UART0_RX,  RT_HW_UART0_TX,		
											  RT_HW_UART1_RX,  RT_HW_UART1_TX, 
											  RT_HW_UART2_RX,  RT_HW_UART2_TX,
											  RT_HW_UART3_RX,  RT_HW_UART3_TX,      				RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_USS[]	={RT_HW_UARTS_RX,  RT_HW_UARTS_TX,						RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_CAN[]	={														RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_BTH[]	={														RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_ETH[]	={														RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_WFI[]	={														RT_HW_PGM_END};

//-----Доступные пины контроллера------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_ALL[]	={ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,
											  16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,
											  32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,
											  48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,
										      64,65,66,67,68,69,								RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DIN[]	={       2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,
										      16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,
										      32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,
										      48,49,50,51,52,53,								RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_ADC[]	={54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,	RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_TCH[]	={													RT_HW_PGM_END};									
const uint8_t PROGMEM RT_HW_PGM_PIN_DOT[]	={       2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,
										      16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,
										      32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,
										      48,49,50,51,52,53, 								RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_PWM[]	={ 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,44,45,46,		RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DAC[]	={													RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_INT[]	={ 2, 3,18,19,20,21,								RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_N5V[]	={RT_HW_PGM_END};		
//-----Тестовые пины и адреса------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_DBG[]   ={43,44,45,						RT_HW_PGM_END};	// debug1,debug2,debug3;	
const uint8_t PROGMEM RT_HW_PGM_PIN_OUT[]	={ 5, 6,12,255,22,23,24,25, 	RT_HW_PGM_END};	// PWM0,PWM1,led1,led2, do1,do2,do3,do4;
const uint8_t PROGMEM RT_HW_PGM_PIN_INP[]	={54,55,12,      				RT_HW_PGM_END};	// A0,A1,btn1,btn2;
const uint8_t PROGMEM RT_HW_PGM_PIN_DCT[]	={          					RT_HW_PGM_END};	// DAC0,DAC1,TCH0;
const uint8_t PROGMEM RT_HW_PGM_PIN_DEV[]	={ 7,4,2,3,						RT_HW_PGM_END};	// DS1820,DHT22,HC-SR04(Echo,Trig);
const uint8_t PROGMEM RT_HW_PGM_PIN_CSS[]	={46,47,48,49,					RT_HW_PGM_END};	// CS SPI:595,LCD,NRF,DEVl 	
const uint8_t PROGMEM RT_HW_PGM_PIN_LC6[]   ={24,25,26,27,28,29,							// LCD HD44780 for bus4 (RS,E,DB4-DB7[]
                                              32,33,34,35,36,37,38,39,40,41,RT_HW_PGM_END}; // LCD HD44780 for bus8;(RS,E,DB0-DB7[]
const uint8_t PROGMEM RT_HW_PGM_PIN_TFT[] 	={26,27,28,29,30,				RT_HW_PGM_END};	// Пины(дополнительные) TFT дисплея(SPI)-CS,R/S,LED,RST,TOUCH;
const uint8_t PROGMEM RT_HW_PGM_PIN_SSP[] 	={ 8, 9,10,11,					RT_HW_PGM_END};	// Soft SPI(miso,mosi,sck,cs[];	
const uint8_t PROGMEM RT_HW_PGM_ADR_I2C[] 	={39,62,32,33,					RT_HW_PGM_END}; // lcd1,lcd2,mcp1,mcp2;
//-------------------------------------------------------------------------------------------------
#endif


//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
