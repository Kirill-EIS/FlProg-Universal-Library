//*************************************************************************************************
//							1.Контроллер типа_STM32F746G_DISCOVERY
//*************************************************************************************************



/*----------------------------------------------------------------------------
 *        Pins
 *----------------------------------------------------------------------------*/
/*
#define PC7  0
#define PC6  1
#define PG6  2
#define PB4  3
#define PG7  4
#define PI0  5
#define PH6  6
#define PI3  7
#define PI2  8
#define PA15 9
#define PA8  10
#define PB15 11
#define PB14 12
#define PI1  13
#define PB9  14
#define PB8  15
#define PA0  16 // A0
#define PF10 17 // A1
#define PF9  18 // A2
#define PF8  19 // A3
#define PF7  20 // A4
#define PF6  21 // A5
#define PI11 22 // User btn
#define PB7  23 // ST-Link Rx
#define PA9  24 // ST-Link Tx
#define PC13 25 // SD detect

// This must be a literal
#define NUM_DIGITAL_PINS        26
// This must be a literal with a value less than or equal to to MAX_ANALOG_INPUTS
#define NUM_ANALOG_INPUTS       6
#define NUM_ANALOG_FIRST        16

// On-board LED pin number
#define LED_BUILTIN             13
#define LED_GREEN               LED_BUILTIN

// On-board user button
#define USER_BTN                PI11

// Timer Definitions
// Use TIM6/TIM7 when possible as servo and tone don't need GPIO output pin
#define TIMER_TONE              TIM6
#define TIMER_SERVO             TIM7

// UART Definitions
#define SERIAL_UART_INSTANCE    1 //Connected to ST-Link
// Default pin used for 'Serial' instance (ex: ST-Link)
// Mandatory for Firmata
#define PIN_SERIAL_RX           PB7
#define PIN_SERIAL_TX           PA9

// SD detect signal
#define SD_DETECT_PIN           PC13
//=================================================================================================
*/