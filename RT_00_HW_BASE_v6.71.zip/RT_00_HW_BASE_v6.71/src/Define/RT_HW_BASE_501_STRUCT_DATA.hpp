
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//						1.Структуры системных параметров
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++				  
struct RT_HW_STRUCT_BUFF	{uint8_t arr[8]; uint8_t vu8; int8_t vi8; uint16_t vu16; uint32_t vu32;};
struct RT_HW_STRUCT_BOARD   {uint8_t  codeArch, codeBoard;};			//--Параметры контр.(архитектура и пр.);
struct RT_HW_STRUCT_PIN   	{uint8_t  control,led,button;};				//--Структура для пинов платы; 
struct RT_HW_STRUCT_DEBUG   {uint8_t  pinDebug,timeDebug;};				//--Структура для отладки; 
struct RT_HW_STRUCT_DEPTH 	{uint8_t  sys,adc,pwm,dac,tch,vNull,drift;};//--Разрешения устройств и дрейфы ADC; 
struct RT_HW_STRUCT_PWM   	{uint16_t channel; uint16_t freq;};			//--PWM; 
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//						2.Структуры для диспетчера планирования задач
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
struct RT_HW_STRUCT_SHAD  	{uint8_t  num,cnt,qnt;};	//--Регистры диспетчера;
struct RT_HW_STRUCT_SHED  	{RT_HW_STRUCT_SHAD quick, fast, slow, back, frdm; uint32_t timeStart10, timeStart25;
							 uint8_t gen250; uint8_t blink; uint8_t run; uint8_t cnt50:1, cnt100:3, cnt250:4;
							 uint16_t periodQuick; uint8_t periodBase;  uint8_t workSec=0; uint32_t cntSec=0;
							 uint8_t blinkSec; uint32_t cntCycle=0; uint32_t cycle=0;
							 };  	
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//						3.Структуры работы с UART
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
struct RT_HW_STRUCT_UART  	{uint16_t  begin, ready; uint32_t speed; uint32_t timeStart; uint16_t dir0;};	
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//						4.Структуры работы с i2с
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
struct RT_HW_STRUCT_I2C   	{uint8_t state; uint8_t sda,scl; int8_t adr; uint32_t speed;}; 
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//						5.Структуры работы с SPI
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
struct RT_HW_STRUCT_SPI   	{uint8_t state; uint8_t sck,miso,mosi,ss; uint16_t freq;};	

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
struct RT_HW_STRUCT_SSPI  {RT_HW_PIN_DIR_ID clk,miso,mosi,cs; 
  uint8_t checkPin=0; 
  uint8_t bitOrder     =RT_HW_SPI_BIT_ORDER; 
  uint8_t dataMode     =RT_HW_SPI_DATA_MODE; 
  uint8_t interruptMode=RT_HW_SPI_INTERRUPT_MODE;
};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//						6.Структуры работы с консолью
// dir  - этапы настройки консоли;
// ok 	- флаг готовности консоли;
// head - флаг разрешения вывода заголовков (включается на один цикл вместе с готовностью консоли); 
// numUart	 -номер Uart(0-8) - аппаратные UART; Uart=9 -программный UART; 
// speed 	 -скорость консоли;   
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
struct RT_HW_STRUCT_CONSOLE {uint8_t dir; uint8_t ok:1, head:1; uint8_t numUart; uint32_t speed;};	
struct RT_HW_STRUCT_CONSOLE_OUT{uint32_t timeBegin; uint8_t dir=0; char mode='A'; uint8_t agoEN:1, block:1, first:1, period:1, change:1, permit:1, run:1;}; //--Для  блоков вывода FLProg;
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//						10.Обобщенная структура для работы с устройствами контроллера
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 
struct RT_HW_STRUCT_DEVICE{
RT_HW_STRUCT_BOARD  board;	//--Данные для работы с общими параметрами контроллера (архитектура и пр.);
RT_HW_STRUCT_PIN  	pin;	//--Данные для работы с системными пинами control,led;
RT_HW_STRUCT_DEBUG  dbg;	//--Данные для отладочных функций (номер пина, задержка в mcs); 
RT_HW_STRUCT_DEPTH	depth;	//--Данные для работы с разрядностью (разрешениями) устройств;
RT_HW_STRUCT_PWM 	pwm;	//--Данные для работы с PWM;
RT_HW_STRUCT_UART 	uart; 	//--Данные для работы с UART;
//-----Шина i2c------------------------------------------------------------------------------------
#if defined(RT_HW_PERMIT_I2C0)			  
RT_HW_STRUCT_I2C 	i2c0;	//--Данные для работы с шиной i2c0;
#endif		  
#if defined(RT_HW_PERMIT_I2C1)			  
RT_HW_STRUCT_I2C 	i2c1;	//--Данные для работы с шиной i2c1;	
#endif
#if defined(RT_HW_PERMIT_I2C2)			  
RT_HW_STRUCT_I2C 	i2c2;	//--Данные для работы с шиной i2c2;
#endif
//-----Шина SPI------------------------------------------------------------------------------------
#if defined(RT_HW_PERMIT_SPI0)			  
RT_HW_STRUCT_SPI 	spi0;	//--Данные для работы с SPI0;
#endif		  
#if defined(RT_HW_PERMIT_SPI1)			  
RT_HW_STRUCT_SPI 	spi1;	//--Данные для работы с SPI1;	
#endif
#if defined(RT_HW_PERMIT_SPI2)			  
RT_HW_STRUCT_SPI 	spi2;	//--Данные для работы с SPI2;
#endif			  
};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//						5.Структуры работы с 1-WIRE
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
struct RT_HW_STRUCT_ONE_WIRE {
	RT_HW_PIN_DIR_ID dd; 
	uint8_t custom=0; uint8_t dir=0; uint8_t step=0; uint8_t state; uint8_t bus; uint32_t timeDelay;
	unsigned char ROM_NO[8];
    uint8_t LastDiscrepancy;
    uint8_t LastFamilyDiscrepancy;
    bool    LastDeviceFlag;	
	};	
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//						6.РАЗНЫЕ СТРУКТУРЫ
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
struct RT_HW_COUNTER_ID         {int16_t begin, step, top, bottom, cnt; uint8_t reset=1; uint8_t direct=0;}; //--Для счетчиков;
struct RT_HW_CHANGE_PINDI_ID    {uint32_t time; uint8_t dir=0; uint8_t ago=0;};						//--Для защиты от дребезга пина DI;
struct RT_HW_GENERATOR_EVENT_ID {uint32_t time; uint8_t dir=0; uint8_t meander:1, event:1;}; 		//--Для генератора меандров и событий;
struct RT_HW_GENERATOR_PULSE_ID {uint32_t time; int8_t  dir=0;};									//--Для генератора импульсов;
struct RT_HW_GENERATOR_PWM_ID   {uint32_t timeON; uint32_t timeFULL; uint8_t dir=0;};				//--Для генератора ШИМ;
struct RT_HW_GENERATOR_FRONT_ID {uint32_t time; uint8_t meander, event, ago; uint8_t cnt=1;};		//--Для генератора фронтов;
struct RT_HW_GENERATOR_GROUP_ID {uint32_t time; uint8_t dir=0;    uint8_t cnt=0; uint8_t ago=0; uint8_t meander=0;};	//--Для генератора пачки импульсов;
struct RT_HW_GENERATOR_DELAY_ID {uint32_t time; uint8_t dir=0;    uint8_t cnt=0; uint8_t ago=0;};	//--Для генератора задержек времени;
struct RT_HW_GENERATOR_TASK_ID  {uint32_t time; uint8_t event=0;  uint8_t cnt=0;};					//--Для генератора задач;
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							Структура для преобразования числа в символы
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
struct RT_HW_BASE_VAL_ID {uint32_t val; uint16_t len:4,index:4,num:4,mess:4; uint8_t mode:2,minus:1,point:2,pnt:1;};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							Структура для сенсора типа DHT22
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
struct RT_HW_STRUCT_DHT22{
uint8_t  debug=0;				//--Код состояния отладки. Изменяется внешними функциями;
uint8_t  custom=0;				//--Код настройки: =0 не настраивался; =1 успешно настроен; >1 код ошибки настройки; 
uint8_t  dir=0;					//--Этапы основной программы управления устройствами;
uint8_t  pin=255;				//--Номер пина - изменяется до вызова dht22_setID();
uint8_t  extEN=1;				//--Разрешение работы устройства - изменяется до вызова функции dht22_direct;
uint16_t period=2200;			//--Период опроса;
uint8_t  maxQntErr=3;			//--Максимальное допустимое подряд кол-во ошибочных измерений;
uint8_t  fresh=1;				//--Готовность данных;
uint16_t vH; 					//--Влажность;
int16_t  vT;					//--Температура;
uint8_t  codeErr;				//--Код последней ошибки измерения;
uint8_t  run;
uint8_t  error;
uint8_t  ok;
uint8_t  cntErr; 				//--Cчетчик ошибок;	
uint32_t timeBegin;				//--Рабочий регистр;	
uint32_t timeWait;				//--Рабочий регистр;	
};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							Структура для сенсора типа DHT22
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
struct RT_HW_STRUCT_DS1820{
uint8_t  debug=0;				//--Код состояния отладки. Изменяется внешними функциями;
uint8_t  custom=0;				//--Код настройки: =0 не настраивался; =1 успешно настроен; >1 код ошибки настройки; 
uint8_t  dir=0;					//--Этапы основной программы управления устройствами;
uint8_t  pin=255;				//--Номер пина - изменяется до вызова dht22_setID();
uint8_t  extEN=1;				//--Разрешение работы устройства - изменяется до вызова функции dht22_direct;
uint16_t period=1000;			//--Период опроса;
uint8_t  maxQntErr=3;			//--Максимальное допустимое подряд кол-во ошибочных измерений;
uint8_t  fresh=1;				//--Готовность данных;
uint8_t  typeSensor=0;			//--Модификация сенсора: =0 новая, =1 старая;
int16_t  vT=-2;					//--Температура;	
uint8_t  fault:1, error:1, ok:1, codeErr:3;
uint8_t  cntErr; 	//--Cчетчик ошибок;

uint32_t timePeriod;	//--Рабочий регистр;
uint32_t timeDelay;
uint8_t  data[8];		
};
//-------------------------------------------------------------------------------------------------
//		Структура для сенсора HC-SR04 (32 байта)
//-------------------------------------------------------------------------------------------------
struct RT_HW_STRUCT_HC_SR04{
RT_HW_PIN_DIR_ID ddEcho;
RT_HW_PIN_DIR_ID ddTrig; 
uint8_t 	dir=0;
uint8_t		custom=0;
uint16_t 	period;					//--Период опроса сенсора;
uint8_t		pinEcho, pinTrig;		//--Пины echo,trig;
int16_t     tAir;					//--Температура воздуха;
uint8_t		blockIRQ=0;				//--Блокировка режима с прерываниями;
int8_t 		numIRQ;					//--Номер аппаратного прерывания;
uint8_t     modeIRQ;				//--Режим работы: =0 -без прерываний; =1 -с прерываниями на пине Echo; 
uint8_t	    runIRQ;					//--Флаг запуска настройки функции прерывания handler();
uint8_t 	startIRQ;				//--Флаг разрешения прерываний - устанавливается при настройке handler(), сбрасывается handler();
uint8_t     begin,end;				//--Флаги для отслеживания прерываний;
uint8_t     fresh;					//--Флаг обновленных результатов; 
uint8_t     code;
uint8_t     ok;
uint8_t     cntErr;
uint16_t 	LenMcs, LenMm, LenMaxCm, LenMaxMcs; 
uint32_t	timeBegin, timeEnd, timePeriod; 
uint32_t	speedSoundAir; 
};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							Структура для преобразования числа в символы
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

