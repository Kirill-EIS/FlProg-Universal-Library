#include "RT_HW_BASE.h"
//=================================================================================================
//								ФУНКЦИИ РАБОТЫ СО ВРЕМЕНЕМ
//		timeBegin -время начала отсчета (определяется вне функции); timeEnd-время текущее. 
//=================================================================================================
uint32_t RT_HW_BASE:: getPastTime(uint32_t &timeBegin, uint32_t timeEnd) {					//==Возврат прошедшего времени (....->timeBrgin); 
if(timeEnd  >=timeBegin) return (timeEnd  -timeBegin); 						   else return (0xFFFFFFFF-timeBegin+timeEnd); }; 
uint32_t RT_HW_BASE:: getPastMs	 (uint32_t &timeBegin){										//==Возврат прошед.времени в ms(RT_HW_MILLIS->timeBegin);
//--Перед вызовом уставливается timeBegin=RT_HW_MILLIS; 
buff.vu32=RT_HW_MILLIS; if(buff.vu32>=timeBegin) return (buff.vu32-timeBegin); else return (0xFFFFFFFF-timeBegin+buff.vu32);};	
uint32_t RT_HW_BASE:: getPastMcs (uint32_t &timeBegin){										//==Возврат прошедшего времени в mcs;
//--Перед вызовом устанавливается timeBegin=RT_HW_MILLIS;
buff.vu32=RT_HW_MICROS; if(buff.vu32>=timeBegin) return (buff.vu32-timeBegin); else return (0xFFFFFFFF-timeBegin+buff.vu32);};			
uint8_t  RT_HW_BASE:: timeOut    (uint32_t &timeBegin, uint32_t timeEnd, uint16_t timeMax){	//==Возврат события по таймату;
//
if(timeEnd  >=timeBegin){if((timeEnd  -timeBegin)>=timeMax) return 1; else return 0;} else {if((timeBegin-timeEnd)  >timeMax) return 1; else return 0;}}; 
uint8_t  RT_HW_BASE:: timeOutMs  (uint32_t &timeBegin, uint16_t timeMax){					//==Возврат события по таймату в ms;
buff.vu32=RT_HW_MILLIS; 
      if(buff.vu32>=timeBegin){if((buff.vu32-timeBegin)>=timeMax) {return 1;} else {return 0;}} 
else {if((timeBegin-buff.vu32)>timeMax)                           {return 1;} else {return 0;}}}; 
uint8_t  RT_HW_BASE:: timeOutMcs (uint32_t &timeBegin, uint16_t timeMax){					//==Возврат события по таймату в mcs;
buff.vu32=RT_HW_MICROS; 
      if(buff.vu32>=timeBegin){if((buff.vu32-timeBegin)>=timeMax) {return 1;} else {return 0;}} 
else {if((timeBegin-buff.vu32)>timeMax)                           {return 1;} else {return 0;}}};
uint8_t  RT_HW_BASE:: period     (uint32_t &timeBegin, uint32_t timeEnd, uint32_t period){	//==Точный генератор события;  
//	Функция генерит событие с точным поддержанием периода и защитой от пропуска шага. Идея от https://alexgyver.ru/arduino-algorithms/
if((timeEnd-timeBegin)>=period) {
	do{timeBegin+=period; if(timeBegin<period) {break;}} while(timeBegin<(timeEnd-period)); return 1;} return 0;};
uint8_t  RT_HW_BASE:: periodMs   (uint32_t &timeBegin,  uint32_t period){					//==Точный генератор события ms;  
//	Функция генерит событие с точным поддержанием периода ms и защитой от пропуска шага. Идея от https://alexgyver.ru/arduino-algorithms/
if((RT_HW_MILLIS-timeBegin)>=period) {
	do{timeBegin+=period; if(timeBegin<period) {break;}} while(timeBegin<(RT_HW_MILLIS-period)); return 1;} return 0;};
uint8_t  RT_HW_BASE:: periodMcs  (uint32_t &timeBegin,  uint32_t period){					//==Точный генератор события mcs;  
//	Функция генерит событие с точным поддержанием периода ms и защитой от пропуска шага. Идея от https://alexgyver.ru/arduino-algorithms/
if((RT_HW_MICROS-timeBegin)>=period) {
	do{timeBegin+=period; if(timeBegin<period) {break;}} while(timeBegin<(RT_HW_MICROS-period)); return 1;} return 0;};	

//=================================================================================================
//								ФУНКЦИИ УПРАВЛЕНИЯ ЗАДАЧАМИ
//=================================================================================================
void 	RT_HW_BASE:: sheduler(){															//==Диспетчер задач----------
shed.quick.num=shed.fast.num=shed.slow.num=shed.back.num=shed.frdm.num=shed.blinkSec=0;
++shed.cntCycle;
												shed.blink^=1; 											//--бит 0 - loop()
if(period(shed.timeStart10,RT_HW_MICROS,10000)){shed.blink^=(1<<1); bitSet(shed.run,0);					//--бит 1 - 10мс 
							if(++shed.workSec>=100){shed.workSec=0; shed.cntSec++;						//--время работы в сек; 
												shed.blink^=(1<<7);	shed.blinkSec=1;					//--бит 7 - 1сек;
												shed.cycle=shed.cntCycle; shed.cntCycle=0;}}			//--быстродействие в циклах loop();																	//           10мс
if(period(shed.timeStart25,RT_HW_MILLIS,25))   {shed.blink^=(1<<2); bitSet(shed.run,1);					//--бит 2 - 25мс
 if(++shed.cnt250 >=10){shed.cnt250=0;          shed.blink^=(1<<5); bitSet(shed.run,2); shed.gen250++;}	//--бит 5 - 250мс	
 if(++shed.cnt100 >= 4){shed.cnt100=0;	 		shed.blink^=(1<<4); bitSet(shed.run,3);} 				//--бит 4 - 100мс
 if(shed.cnt50++  >= 1){shed.cnt50 =0;			shed.blink^=(1<<3);}} 									//--бит 3 -  50мс			
//---Обработка вызова задачshes
if(shed.run){
 if(bitRead(shed.run,0)) {if(++shed.quick.cnt>shed.quick.qnt){shed.quick.cnt=1;} shed.quick.num=shed.quick.cnt; bitClear(shed.run,0); return;}
 if(bitRead(shed.run,1)) {if(++shed.fast.cnt >shed.fast.qnt) {shed.fast.cnt =1;} shed.fast.num =shed.fast.cnt;  bitClear(shed.run,1); return;}
 if(bitRead(shed.run,2)) {if(++shed.slow.cnt >shed.slow.qnt) {shed.slow.cnt =1;} shed.slow.num =shed.slow.cnt;  bitClear(shed.run,2); return;}
 if(bitRead(shed.run,3)) {if(++shed.back.cnt >shed.back.qnt) {shed.back.cnt =1;} shed.back.num =shed.back.cnt;  bitClear(shed.run,3); return;}}
				    else {if(++shed.frdm.cnt >shed.frdm.qnt) {shed.frdm.cnt =1;} shed.frdm.num =shed.frdm.cnt;                        return;}};

uint8_t	RT_HW_BASE:: getBlinkSec(){return bitRead(shed.blink,7);};						//==Возвращает секундные импульсы;
uint8_t RT_HW_BASE:: timeToTick(uint16_t periodTick, uint16_t time){						//==Конвертация времени в кол-во тиков (max=255)->,один тик=periodTick;	
if(periodTick*255 >=time) {return time/periodTick;}	else {return 255;}};	

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++