//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//						1.Программная среда AVR
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#if !defined(RT_HW_CORE_DEFINED) && defined(RT_HW_CORE_AVR)
#define      RT_HW_CORE_DEFINED             RT_HW_CORE_AVR		//--Идентификатор программной среды;
//----------------------1.1.Основные параметры-----------------------------------------------------
#define RT_HW_ARCH_CODE        		RT_HW_CODE_ARCH_AVR			//--Код архитектуры;
#define RT_HW_ARCH_NAME        		"AVR"						//--Наименование архитектуры;
#define RT_HW_CORE_NAME        		"AVR"	 					//--Наименование программной среды
//----------------------1.2.Дополнительные параметры-----------------------------------------------
#define RT_HW_PIN_TXT_LEN 		 	2							//--Размер поля при выводе номеров пинов; 
#define RT_HW_PIN_QNT_LINE 		 	24							//--Кол-во пинов в строке при выводе таблицы; 
#define RT_HW_I2C_SPEED_DEFAULT  	RT_HW_I2C_SPEED_FM			//--Код скорости i2c по умолчанию (->400kHz);
//-------------------------------------------------------------------------------------------------
#define RT_HW_SPI_CLOCK				4000000UL					//--Скорость SPI в Гц; 
#define RT_HW_SPI_BIT_ORDER         MSBFIRST					//--Порядок следования битов в байте SPI;
#define RT_HW_SPI_DATA_MODE         SPI_MODE0					//--Режим для импульсов SPI;
#define RT_HW_SPI_INTERRUPT_MODE	0							//--Режим работы с прерываниями SPI;
//----------------------1.3.Дополнительные макросы-------------------------------------------------
#define RT_HW_IRAM_ATTR											//--Атрибут для совместимости c ESP8266;	
#define	RT_HW_BLOCK_SET_RESOLUTION_ADC							//--Блокировка функции установка разрешения ADC;
#define RT_HW_BLOCK_SET_RESOLUTION_PWM							//--Блокировка функции установка разрешения PWM;
//----------------------1.4.Дополнительные библиотеки----------------------------------------------
#include <avr/pgmspace.h>										//--Библиотека для работы с PROGMEM;
#include <Wire.h>												//--Подключение библиотеки i2c;	   	
#include <SPI.h>												//--Подключение библиотеки SPI	
#include <SoftwareSerial.h>										//--Библиотека программного UART;
//----------------------1.5.Макросы для работы c пинами через функции WIRING-----------------------  
#define RT_HW_PIN_MODE_INPUT  					INPUT			//--Дискретный вход;
#define RT_HW_PIN_MODE_OUTPUT  					OUTPUT			//--Дискретный выход;
#define RT_HW_PIN_MODE_INPUT_PULLUP  			INPUT_PULLUP 	//--Дискретный вход с подтяжкой к +Vcc;
//----------------------1.6.Макросы для совместимости с STM32--------------------------------------
#define RT_HW_PIN_MODE_INPUT_FLOATING  			INPUT			//--Дискретный вход - аналог INPUT;
#define RT_HW_PIN_MODE_INPUT_PULLDOWN  			INPUT			//--Дискретный вход с подтяжкой к GND;
#define RT_HW_PIN_MODE_INPUT_ANALOG  			INPUT			//--Аналоговый вход;
#define RT_HW_PIN_MODE_OUTPUT_OPEN_DRAIN  		OUTPUT			//--Дискретный выход с открытым выходом;
#define RT_HW_PIN_MODE_OUTPUT_PWM				OUTPUT			//--ШИМ выход;
#define RT_HW_PIN_MODE_OUTPUT_PWM_OPEN_DRAIN	OUTPUT			//--ШИМ выход с открытым коллектором;
//----------------------1.7.Базовый размер переменной и структура для GPIO---------------------------
#define RT_HW_DATE_TYPE 		uint8_t						
struct  RT_HW_PIN_DIR_ID {uint8_t pin; uint8_t dir=0; uint8_t bit; volatile uint8_t *base;};	
//----------------------1.8.Макросы прямого управления пинами----------------------------------------
#define RT_HW_PIN_DIR_SET_ID(id,p) 	    	id.pin=p; id.bit=digitalPinToBitMask(p);\
                                                      id.base=portInputRegister(digitalPinToPort(p));
#define RT_HW_PIN_DIR_MODE_INPUT(id)        *((id.base)+(1)) &=~id.bit; *((id.base)+(2))&=~id.bit; 
#define RT_HW_PIN_DIR_MODE_PULLUP(id) 	    *((id.base)+(1)) &=~id.bit; *((id.base)+(2))|= id.bit;
#define RT_HW_PIN_DIR_MODE_OUTPUT(id) 	    *((id.base)+(1)) |= id.bit;
#define RT_HW_PIN_DIR_READ(id)           (((*((id.base)+(0))) & id.bit) ? (1) : (0)) 
#define RT_HW_PIN_DIR_WRITE(id,val) if(val){*((id.base)+(2)) |= id.bit;}\
                                       else{*((id.base)+(2)) &=~id.bit;};
#define RT_HW_PIN_DIR_WRITE_LOW(id)         *((id.base)+(2)) &=~id.bit;
#define RT_HW_PIN_DIR_WRITE_HIGH(id)        *((id.base)+(2)) |= id.bit;
//-------------------------------------------------------------------------------------------------	
#endif			
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//						2.Программная среда ESP8266
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#if !defined(RT_HW_CORE_DEFINED) && defined(RT_HW_CORE_ESP8266)
#define RT_HW_CORE_DEFINED             RT_HW_CODE_CORE_ESP8266	//--Идентификатор программной среды;
//----------------------2.1.Основные параметры-----------------------------------------------------
#define	RT_HW_ARCH_CODE        		RT_HW_CODE_ARCH_ESP8266		//--Код архитектуры;
#define RT_HW_ARCH_NAME        		"ESP8266"					//--Наименование архитектуры;
#define RT_HW_CORE_NAME        		"ESP8266"	 				//--Наименование программной среды
//----------------------2.2.Дополнительные параметры-----------------------------------------------
#define RT_HW_PIN_TXT_LEN 			3 							//--Размер поля при выводе номеров пинов;
#define RT_HW_PIN_QNT_LINE 		 	18 							//--Кол-во пинов в строке при выводе таблицы; 
#define RT_HW_I2C_SPEED_DEFAULT  	RT_HW_I2C_SPEED_ST			//--Код скорости i2c по умолчанию (->100kHz);
//-------------------------------------------------------------------------------------------------
#define RT_HW_SPI_CLOCK				4000000UL					//--Скорость SPI в Гц; 
#define RT_HW_SPI_BIT_ORDER         MSBFIRST					//--Порядок следования битов в байте SPI;
#define RT_HW_SPI_DATA_MODE         SPI_MODE0					//--Режим для импульсов SPI;
#define RT_HW_SPI_INTERRUPT_MODE	0							//--Режим работы с прерываниями SPI;
//----------------------2.3.Дополнительные макросы-------------------------------------------------
#define RT_HW_IRAM_ATTR				IRAM_ATTR					//--Атрибут для совместимости c ESP8266;
#define	RT_HW_BLOCK_SET_RESOLUTION_ADC							//--Блокировка функции установка разрешения ADC;
#define RT_HW_BLOCK_SET_RESOLUTION_PWM							//--Блокировка функции установка разрешения PWM;
#define RT_HW_BLOCK_UART1_READ									//--Блокировка функций чтения с UART1;	
//----------------------2.4.Дополнительные библиотеки и макросы------------------------------------
#include <pgmspace.h>										//--Работа с PROGMEM;
#include <Wire.h>												//--Подключение библиотеки i2c;	   	
#include <SPI.h>												//--Подключение библиотеки SPI
#include <SoftwareSerial.h>										//--Библиотека программного UART;
//----------------------2.5.Макросы для работы c пинами через функции WIRING----------------------- 
#define RT_HW_PIN_MODE_INPUT  					INPUT			//--Дискретный вход;
#define RT_HW_PIN_MODE_OUTPUT  					OUTPUT			//--Дискретный выход;
#define RT_HW_PIN_MODE_INPUT_PULLUP  			INPUT_PULLUP 	//--Дискретный вход с подтяжкой к +Vcc;
//----------------------2.6.Макросы для совместимости с STM32--------------------------------------
#define RT_HW_PIN_MODE_INPUT_FLOATING  			INPUT			//--Дискретный вход - аналог INPUT;
#define RT_HW_PIN_MODE_INPUT_PULLDOWN  			INPUT			//--Дискретный вход с подтяжкой к GND;
#define RT_HW_PIN_MODE_INPUT_ANALOG  			INPUT			//--Аналоговый вход;
#define RT_HW_PIN_MODE_OUTPUT_OPEN_DRAIN  		OUTPUT			//--Дискретный выход с открытым выходом;
#define RT_HW_PIN_MODE_OUTPUT_PWM				OUTPUT			//--ШИМ выход;
#define RT_HW_PIN_MODE_OUTPUT_PWM_OPEN_DRAIN	OUTPUT			//--ШИМ выход с открытым коллектором;
//----------------------2.7.Базовый размер переменной и структура для GPIO---------------------------
#define RT_HW_DATE_TYPE 		uint32_t		 				//--Тип базовой переменной при прямом управлении пинами;
struct  RT_HW_PIN_DIR_ID{uint32_t pin; uint32_t dir=0; uint32_t GPFFS_pin; uint32_t LEFT_PIN;  uint32_t LEFT_GPCI; uint32_t LEFT_GPCD; uint32_t LEFT_GPFPU;};
//----------------------2.8.Макросы прямого управления пинами--------------------------------------
static inline __attribute__((always_inline))		//--Чтение дискретного пина
bool RT_HW_BASE_digitalReadFast(RT_HW_PIN_DIR_ID &id) {if(id.pin < 16){return GPIP(id.pin);} else if(id.pin == 16){return GP16I & 0x01;} return 0;};
#define RT_HW_PIN_DIR_SET_ID(id,p)        id.pin=p; id.GPFFS_pin=GPFFS(GPFFS_GPIO(id.pin)); id.LEFT_PIN=(1<<id.pin); id.LEFT_GPCI=(0xF<<GPCI);\
                                                    id.LEFT_GPCD=(1<<GPCD); id.LEFT_GPFPU=(1<<GPFPU);
#define RT_HW_PIN_DIR_MODE_INPUT(id)      GPF(id.pin) =id.GPFFS_pin; GPEC=id.LEFT_PIN; GPC(id.pin)=(GPC(id.pin) & id.LEFT_GPCI) | (id.LEFT_GPCD);
#define RT_HW_PIN_DIR_MODE_PULLUP(id)     GPF(id.pin) =id.GPFFS_pin; GPEC=id.LEFT_PIN; GPC(id.pin)=(GPC(id.pin) & id.LEFT_GPCI) | (id.LEFT_GPCD); GPF(id.pin)|=id.LEFT_GPFPU;
#define RT_HW_PIN_DIR_MODE_OUTPUT(id)     GPF(id.pin)=id.GPFFS_pin; GPC(id.pin)=GPC(id.pin) & id.LEFT_GPCI; GPES = id.LEFT_PIN;
#define RT_HW_PIN_DIR_READ(id)            RT_HW_BASE_digitalReadFast(id)
#define RT_HW_PIN_DIR_WRITE_LOW(id)       if(id.pin<16){GPOC=id.LEFT_PIN;} else if(id.pin==16){GP16O |=  1;}
#define RT_HW_PIN_DIR_WRITE_HIGH(id)      if(id.pin<16){GPOS=id.LEFT_PIN;} else if(id.pin==16){GP16O &= ~1;}
#define RT_HW_PIN_DIR_WRITE(id,val)       if(id.pin<16){if(val){GPOS=id.LEFT_PIN;} else{GPOC=id.LEFT_PIN;}} else if(id.pin==16){if(val){GP16O |= 1;} else{GP16O &= ~1;}}

#define DIRECT_WRITE_LOW(base, mask)    (GPOC = (mask))             //GPIO_OUT_W1TC_ADDRESS
#define DIRECT_WRITE_HIGH(base, mask)   (GPOS = (mask))             //GPIO_OUT_W1TS_ADDRESS

//-------------------------------------------------------------------------------------------------
#endif
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//						3.Программная среда ESP32
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#if !defined(RT_HW_CORE_DEFINED) && defined(RT_HW_CORE_ESP32) 
#define RT_HW_CORE_DEFINED             RT_HW_CODE_CORE_ESP32	//--Идентификатор программной среды;
//----------------------3.1.Основные параметры-----------------------------------------------------
#define	RT_HW_ARCH_CODE        		RT_HW_CODE_ARCH_ESP32		//--Код архитектуры;
#define RT_HW_ARCH_NAME        		"ESP32"						//--Наименование архитектуры;
#define RT_HW_CORE_NAME        		"ESP32"	 					//--Наименование программной среды
//----------------------3.2.Дополнительные параметры-----------------------------------------------
#define RT_HW_PIN_TXT_LEN 			2 							//--Размер поля при выводе номеров пинов; 
#define RT_HW_PIN_QNT_LINE 			20							//--Кол-во пинов в стройке таблицы; 
#define RT_HW_I2C_SPEED_DEFAULT  	RT_HW_I2C_SPEED_FM			//--Код скорости шины i2c (default 400kHz);
//-------------------------------------------------------------------------------------------------
#define RT_HW_SPI_CLOCK				4000000UL					//--Скорость SPI в Гц; 
#define RT_HW_SPI_BIT_ORDER         MSBFIRST					//--Порядок следования битов в байте SPI;
#define RT_HW_SPI_DATA_MODE         SPI_MODE0					//--Режим для импульсов SPI;
#define RT_HW_SPI_INTERRUPT_MODE	0							//--Режим работы с прерываниями SPI;
//----------------------3.3.Дополнительные макросы-------------------------------------------------
#define RT_HW_IRAM_ATTR											//--Атрибут для совместимости c ESP8266;	
//#define	RT_HW_BLOCK_SET_RESOLUTION_ADC							//--Блокировка функции установка разрешения ADC;
#define RT_HW_BLOCK_SET_RESOLUTION_PWM							//--Блокировка функции установка разрешения PWM;
#define RT_HW_BLOCK_I2C_SLAVE									//--Блокировка функций поддержки i2c Slave;
//-----------------------------------------------
#ifdef  interrupts													
#undef  interrupts
#endif
#ifdef  noInterrupts
#undef  noInterrupts
#endif
#define noInterrupts() {portMUX_TYPE mux = portMUX_INITIALIZER_UNLOCKED; portENTER_CRITICAL(&mux)
#define interrupts() portEXIT_CRITICAL(&mux);}
//----------------------3.4.Дополнительные библиотеки и макросы------------------------------------
#include <pgmspace.h>											//--Работа с PROGMEM;
#include "esp32-hal-ledc.h"										//--Библиотека для работы с PWM и LED;	
#include <driver/rtc_io.h>										//--Служебные функции;
#include <Wire.h>												//--Подключение библиотеки i2c;		   	
#include <SPI.h>												//--Подключение библиотеки SPI
//----------------------3.5.Макросы для работы c пинами через функции WIRING----------------------- 
#define RT_HW_PIN_MODE_INPUT  				INPUT				//--Дискретный вход;
#define RT_HW_PIN_MODE_OUTPUT  				OUTPUT				//--Дискретный выход;
#define RT_HW_PIN_MODE_INPUT_PULLUP  		INPUT_PULLUP 		//--Дискретный вход с подтяжкой к +Vcc;
//----------------------3.6.Макросы для совместимости с STM32--------------------------------------
#define RT_HW_PIN_MODE_INPUT_FLOATING  		INPUT				//--Дискретный вход - аналог INPUT;
#define RT_HW_PIN_MODE_INPUT_PULLDOWN  		INPUT_PULLDOWN		//--Дискретный вход с подтяжкой к GND;
#define RT_HW_PIN_MODE_INPUT_ANALOG  		INPUT				//--Аналоговый вход;
#define RT_HW_PIN_MODE_OUTPUT_OPEN_DRAIN  	OUTPUT_OPEN_DRAIN	//--Дискретный выход с открытым выходом;
#define RT_HW_PIN_MODE_OUTPUT_PWM				OUTPUT			//--ШИМ выход;
#define RT_HW_PIN_MODE_OUTPUT_PWM_OPEN_DRAIN	OUTPUT			//--ШИМ выход с открытым коллектором;
//----------------------3.7.Базовый размер переменной и структура для GPIO---------------------------
#define RT_HW_DATE_TYPE 		uint32_t						
struct  RT_HW_PIN_DIR_ID {uint32_t pin; uint32_t dir=0; uint32_t bit; uint32_t num; uint32_t freq;};
//----------------------3.8.Макросы прямого управления пинами--------------------------------------
#define RT_HW_PIN_DIR_SET_ID(id,p) 	        id.pin=p; id.bit=id.pin; 
#define RT_HW_PIN_DIR_MODE_INPUT(id)        pinMode(id.pin,INPUT);
#define RT_HW_PIN_DIR_MODE_PULLUP(id) 	    pinMode(id.pin,INPUT_PULLUP);
#define RT_HW_PIN_DIR_MODE_OUTPUT(id) 	    pinMode(id.pin,OUTPUT);
#define RT_HW_PIN_DIR_READ(id)              digitalRead(id.pin)
#define RT_HW_PIN_DIR_WRITE(id,val) 		digitalWrite(id.pin,val);
#define RT_HW_PIN_DIR_WRITE_LOW(id)         digitalWrite(id.pin,LOW);
#define RT_HW_PIN_DIR_WRITE_HIGH(id)        digitalWrite(id.pin,HIGH);
//-------------------------------------------------------------------------------------------------
#endif
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//						4.Программная среда Seeeduino
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#if !defined(RT_HW_CORE_DEFINED) && defined(RT_HW_CORE_SEEED)
#define RT_HW_CORE_DEFINED             RT_HW_CODE_CORE_SEEED 	//--Идентификатор программной среды;
//----------------------4.1.Основные параметры-----------------------------------------------------
#define RT_HW_ARCH_CODE        		RT_HW_CODE_ARCH_SEEED		//--Код архитектуры;
#define RT_HW_ARCH_NAME        		"SEEED"						//--Наименование архитектуры;
#define RT_HW_CORE_NAME        		"SEEED"	 					//--Наименование программной среды
//----------------------4.2.Дополнительные параметры-----------------------------------------------
#define RT_HW_PIN_TXT_LEN   		2 							//--Размер поля при выводе на консоль номеров пинов;
#define RT_HW_PIN_QNT_LINE  		24  						//--Кол-во пинов в стройке при выводе таблицы на консоль; 
#define RT_HW_I2C_SPEED_DEFAULT  	RT_HW_I2C_SPEED_FM			//--Код скорости шины i2c (default 400kHz);
//-------------------------------------------------------------------------------------------------
#define RT_HW_SPI_CLOCK				4000000UL					//--Скорость SPI в Гц; 
#define RT_HW_SPI_BIT_ORDER         MSBFIRST					//--Порядок следования битов в байте SPI;
#define RT_HW_SPI_DATA_MODE         SPI_MODE0					//--Режим для импульсов SPI;
#define RT_HW_SPI_INTERRUPT_MODE	0							//--Режим работы с прерываниями SPI;
//----------------------4.3.Дополнительные макросы-------------------------------------------------
#define RT_HW_IRAM_ATTR											//--Атрибут для совместимости c ESP8266;	
//----------------------4.4.Дополнительные библиотеки----------------------------------------------
#include <avr/pgmspace.h>										//--Работа с PROGMEM;
#include <Wire.h>												//--Подключение библиотеки i2c;	   	
#include <SPI.h>												//--Подключение библиотеки SPI;	 	
//----------------------4.5.Макросы для работы c пинами через функции WIRING----------------------- 
#define RT_HW_PIN_MODE_INPUT  					INPUT			//--Дискретный вход;
#define RT_HW_PIN_MODE_OUTPUT  					OUTPUT			//--Дискретный выход;
#define RT_HW_PIN_MODE_INPUT_PULLUP  			INPUT_PULLUP 	//--Дискретный вход с подтяжкой к +Vcc;
//----------------------4.6.Макросы для совместимости с STM32--------------------------------------
#define RT_HW_PIN_MODE_INPUT_FLOATING  			INPUT			//--Дискретный вход - аналог INPUT;
#define RT_HW_PIN_MODE_INPUT_PULLDOWN  			INPUT			//--Дискретный вход с подтяжкой к GND;
#define RT_HW_PIN_MODE_INPUT_ANALOG  			INPUT			//--Аналоговый вход;
#define RT_HW_PIN_MODE_OUTPUT_OPEN_DRAIN  		OUTPUT			//--Дискретный выход с открытым выходом;
#define RT_HW_PIN_MODE_OUTPUT_PWM				OUTPUT			//--ШИМ выход;
#define RT_HW_PIN_MODE_OUTPUT_PWM_OPEN_DRAIN	OUTPUT			//--ШИМ выход с открытым коллектором;
//----------------------4.7.Базовый размер переменной и структура для GPIO-------------------------
#define RT_HW_DATE_TYPE 		uint32_t						//--Тип базовой переменной при прямом управлении пинами;
struct  RT_HW_PIN_DIR_ID {uint32_t pin; uint32_t dir=0; uint32_t bit; volatile uint32_t *base;}; 
//----------------------4.8.Макросы прямого управления пинами--------------------------------------
#define RT_HW_PIN_DIR_SET_ID(id,p) 	    	id.pin=p; 
#define RT_HW_PIN_DIR_MODE_INPUT(id)        pinMode(id.pin,INPUT); 				
#define RT_HW_PIN_DIR_MODE_PULLUP(id) 	    pinMode(id.pin,INPUT_PULLUP);
#define RT_HW_PIN_DIR_MODE_OUTPUT(id) 	    pinMode(id.pin,OUTPUT);
#define RT_HW_PIN_DIR_READ(id)           	digitalRead(id.pin) 
#define RT_HW_PIN_DIR_WRITE(id,val) 		digitalWrite(id.pin,val);
#define RT_HW_PIN_DIR_WRITE_LOW(id)         digitalWrite(id.pin,LOW);
#define RT_HW_PIN_DIR_WRITE_HIGH(id)        digitalWrite(id.pin,HIGH);
//-------------------------------------------------------------------------------------------------
#endif
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//						5.Программная среда SAM
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#if !defined(RT_HW_CORE_DEFINED) && defined(RT_HW_CORE_SAM)
#define      RT_HW_CORE_DEFINED        RT_HW_CODE_CORE_SAM		//--Идентификатор программной среды;
//----------------------5.1.Основные параметры-----------------------------------------------------
#define RT_HW_ARCH_CODE        		RT_HW_CODE_ARCH_SAM			//--Код архитектуры;
#define RT_HW_ARCH_NAME        		"SAM"						//--Наименование архитектуры;
#define RT_HW_CORE_NAME        		"SAM"	 					//--Наименование программной среды
//----------------------5.2.Дополнительные параметры-----------------------------------------------
#define RT_HW_PIN_TXT_LEN 			2 							//--Размер поля при выводе на консоль номеров пинов;
#define RT_HW_PIN_QNT_LINE 			24  						//--Кол-во пинов в стройке при выводе таблицы на консоль; 
#define RT_HW_I2C_SPEED_DEFAULT  	RT_HW_I2C_SPEED_FM			//--Код скорости шины i2c (default 400kHz);
//-------------------------------------------------------------------------------------------------
#define RT_HW_SPI_CLOCK				4000000UL					//--Скорость SPI в Гц; 
#define RT_HW_SPI_BIT_ORDER         MSBFIRST					//--Порядок следования битов в байте SPI;
#define RT_HW_SPI_DATA_MODE         SPI_MODE0					//--Режим для импульсов SPI;
#define RT_HW_SPI_INTERRUPT_MODE	0							//--Режим работы с прерываниями SPI;
//----------------------5.3.Дополнительные макросы-------------------------------------------------
#define RT_HW_IRAM_ATTR											//--Атрибут для совместимости c ESP8266;	
//----------------------5.4.Дополнительные библиотеки----------------------------------------------
#include <avr/pgmspace.h>										//--Работа с PROGMEM;
#include <Wire.h>												//--Подключение библиотеки i2c;	   	
#include <SPI.h>												//--Подключение библиотеки SPI	
#define RT_HW_I2C_SPEED_DEFAULT  RT_HW_I2C_SPEED_FM				//--Код скорости шины i2c (default 400kHz);
//----------------------5.5.Макросы для работы c пинами через функции WIRING----------------------- 
#define RT_HW_PIN_MODE_INPUT  				INPUT				//--Дискретный вход;
#define RT_HW_PIN_MODE_OUTPUT  				OUTPUT				//--Дискретный выход;
#define RT_HW_PIN_MODE_INPUT_PULLUP  		INPUT_PULLUP 		//--Дискретный вход с подтяжкой к +Vcc;
//----------------------5.6.Макросы для совместимости с STM32--------------------------------------
#define RT_HW_PIN_MODE_INPUT_FLOATING  		INPUT				//--Дискретный вход - аналог INPUT;
#define RT_HW_PIN_MODE_INPUT_PULLDOWN  		INPUT				//--Дискретный вход с подтяжкой к GND;
#define RT_HW_PIN_MODE_INPUT_ANALOG  		INPUT				//--Аналоговый вход;
#define RT_HW_PIN_MODE_OUTPUT_OPEN_DRAIN  	OUTPUT				//--Дискретный выход с открытым выходом;
//----------------------5.7.Базовый размер переменной и структура для GPIO-------------------------
#define RT_HW_DATE_TYPE 		uint32_t						//--Тип базовой переменной при прямом управлении пинами;
struct  RT_HW_PIN_DIR_ID {uint32_t pin; uint32_t dir=0; uint32_t bit; volatile uint32_t *base;}; 
//----------------------5.8.Макросы прямого управления пинами--------------------------------------
#define RT_HW_PIN_DIR_SET_ID(id,p) 	    	id.pin=p; id.bit=digitalPinToBitMask(p); id.base=(&(digitalPinToPort(p)->PIO_PER));
#define RT_HW_PIN_DIR_MODE_INPUT(id)        pinMode(id.pin,INPUT); 				// *((id.base)+(5))= id.bit;   
#define RT_HW_PIN_DIR_MODE_PULLUP(id) 	    pinMode(id.pin,INPUT_PULLUP);		// *((id.base)+(6))= id.bit;  
#define RT_HW_PIN_DIR_MODE_OUTPUT(id) 	    *((id.base)+(4))= id.bit;
#define RT_HW_PIN_DIR_READ(id)           	(((*((id.base)+(15))) & id.bit) ? (1) : (0)) 
#define RT_HW_PIN_DIR_WRITE(id,val) 		if(val){*((id.base)+(12))= id.bit;} else{*((id.base)+(13))= id.bit;};
#define RT_HW_PIN_DIR_WRITE_LOW(id)         *((id.base)+(13))= id.bit;
#define RT_HW_PIN_DIR_WRITE_HIGH(id)        *((id.base)+(12))= id.bit;
//-------------------------------------------------------------------------------------------------
#endif


//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//						20.Программная среда (M) STM32F1
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#if !defined(RT_HW_CORE_DEFINED) && defined(RT_HW_CORE_M_STM32F1)
#define      RT_HW_CORE_DEFINED             RT_HW_CODE_M_STM32F1 //--Идентификатор программной среды;
//----------------------20.1.Основные параметры----------------------------------------------------
#define RT_HW_ARCH_CODE        		RT_HW_CODE_ARCH_STM32F1		//--Код архитектуры;
#define RT_HW_ARCH_NAME        		"STM32F1"					//--Наименование архитектуры;
#define RT_HW_CORE_NAME        		"(M) STM32F1"	 			//--Наименование программной среды
//----------------------20.2.Дополнительные параметры----------------------------------------------
#define RT_HW_PIN_TXT_LEN 			4  							//--Размер поля при выводе на консоль номеров пинов;
#define RT_HW_PIN_QNT_LINE 			16 							//--Кол-во пинов в строке при выводе таблицы на консоль; 
#define RT_HW_I2C_SPEED_DEFAULT  	RT_HW_I2C_SPEED_FM			//--Код скорости шины i2c (default 400kHz);
//-------------------------------------------------------------------------------------------------
#define RT_HW_SPI_CLOCK				4000000UL					//--Скорость SPI в Гц; 
#define RT_HW_SPI_BIT_ORDER         MSBFIRST					//--Порядок следования битов в байте SPI;
#define RT_HW_SPI_DATA_MODE         SPI_MODE0					//--Режим для импульсов SPI;
#define RT_HW_SPI_INTERRUPT_MODE	0							//--Режим работы с прерываниями SPI;
//----------------------20.3.Дополнительные макросы------------------------------------------------
#define RT_HW_IRAM_ATTR											//--Атрибут для совместимости c ESP8266;
#define	RT_HW_BLOCK_SET_RESOLUTION_ADC							//--Блокировка функции установка разрешения ADC;
#define RT_HW_BLOCK_SET_RESOLUTION_PWM							//--Блокировка функции установка разрешения PWM;
#define RT_HW_BLOCK_I2C_FLUSH									//--Блокировка функции Wirex.flush();
//----------------------20.4.Дополнительные библиотеки---------------------------------------------
#include <avr/pgmspace.h>										//--Работа с PROGMEM;
#include <Wire.h>												//--Подключение библиотеки i2c;	   	
#include <SPI.h>												//--Подключение библиотеки SPI;	
#include <usb_serial.h>											//--Библиотека поддержки USB;
//----------------------20.5.Макросы для работы c пинами через функции WIRING----------------------
#define RT_HW_PIN_MODE_INPUT  				INPUT				//--Дискретный вход;
#define RT_HW_PIN_MODE_OUTPUT  				OUTPUT				//--Дискретный выход;
#define RT_HW_PIN_MODE_INPUT_PULLUP  		INPUT_PULLUP 		//--Дискретный вход с подтяжкой к +Vcc;
//----------------------20.6.Макросы для совместимости с STM32-------------------------------------
#define RT_HW_PIN_MODE_INPUT_FLOATING  		INPUT				//--Дискретный вход - аналог INPUT;
#define RT_HW_PIN_MODE_INPUT_PULLDOWN  		INPUT_PULLDOWN		//--Дискретный вход с подтяжкой к GND;
#define RT_HW_PIN_MODE_INPUT_ANALOG  		INPUT_ANALOG		//--Аналоговый вход;
#define RT_HW_PIN_MODE_OUTPUT_OPEN_DRAIN  	OUTPUT_OPEN_DRAIN	//--Дискретный выход с открытым выходом;
#define RT_HW_PIN_MODE_OUTPUT_PWM			 PWM				//--ШИМ выход;
#define RT_HW_PIN_MODE_OUTPUT_PWM_OPEN_DRAIN PWM_OPEN_DRAIN		//--ШИМ выход с открытым коллектором;	
//----------------------20.7.Базовый размер переменной и структура для GPIO------------------------
#define RT_HW_DATE_TYPE 		uint32_t 						//--Тип базовой переменной при прямом управлении пинами;
struct  RT_HW_PIN_DIR_ID {uint32_t pin; uint32_t dir=0; uint32_t bit; volatile uint32_t *base;}; //--Структура для прямого управления пинами
//----------------------20.8.Макросы прямого управления пинами-------------------------------------
#define RT_HW_PIN_DIR_SET_ID(id,p)	  id.pin=p; id.bit=id.pin; 
#define RT_HW_PIN_DIR_MODE_INPUT(id)  pinMode(id.pin,INPUT);		//pin_function((PinName)id.pin, STM_PIN_DATA(STM_MODE_INPUT,     GPIO_NOPULL,0))
#define RT_HW_PIN_DIR_MODE_PULLUP(id) pinMode(id.pin,INPUT_PULLUP);	//pin_function((PinName)id.pin, STM_PIN_DATA(STM_MODE_INPUT,     GPIO_NOPULL,0))
#define RT_HW_PIN_DIR_MODE_OUTPUT(id) pinMode(id.pin,OUTPUT);		//pin_function((PinName)id.pin, STM_PIN_DATA(STM_MODE_OUTPUT_PP, GPIO_NOPULL,0))
#define RT_HW_PIN_DIR_READ(id)        digitalRead(id.pin)			//digitalReadFast((PinName)id.pin);  //digitalRead(id.pin);
#define RT_HW_PIN_DIR_WRITE(id,val)   digitalWrite(id.pin,val);		//if(val){digitalWriteFast((PinName)id.pin,HIGH);} else {digitalWriteFast((PinName)id.pin,LOW);} 
#define RT_HW_PIN_DIR_WRITE_LOW(id)   digitalWrite(id.pin,LOW);		//digitalWriteFast((PinName)id.pin, LOW); 	//digitalWrite(id.pin,0);
#define RT_HW_PIN_DIR_WRITE_HIGH(id)  digitalWrite(id.pin,HIGH);		//digitalWriteFast((PinName)id.pin, HIGH);	//digitalWrite(id.pin,1);
//-------------------------------------------------------------------------------------------------
#endif
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//						21.Программная среда (M) STM32F4
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#if !defined(RT_HW_CORE_DEFINED) && defined(RT_HW_CORE_M_STM32F4)
#define      RT_HW_CORE_DEFINED             RT_HW_CODE_CORE_M_STM32F4	//--Идентификатор программной среды;
//----------------------21.1.Основные параметры----------------------------------------------------
#define RT_HW_ARCH_CODE        		RT_HW_CODE_ARCH_M_STM32F4	//--Код архитектуры;
#define RT_HW_ARCH_NAME        		"STM32F4"					//--Наименование архитектуры;
#define RT_HW_CORE_NAME        		"(M) STM32F4"	 			//--Наименование программной среды
//----------------------21.2.Дополнительные параметры----------------------------------------------
#define RT_HW_PIN_TXT_LEN 			4  							//--Размер поля при выводе на консоль номеров пинов;
#define RT_HW_PIN_QNT_LINE 			16 							//--Кол-во пинов в строке при выводе таблицы на консоль; 
#define RT_HW_I2C_SPEED_DEFAULT  	RT_HW_I2C_SPEED_FM			//--Код скорости шины i2c (default 400kHz);
//-------------------------------------------------------------------------------------------------
#define RT_HW_SPI_CLOCK				4000000UL					//--Скорость SPI в Гц; 
#define RT_HW_SPI_BIT_ORDER         MSBFIRST					//--Порядок следования битов в байте SPI;
#define RT_HW_SPI_DATA_MODE         SPI_MODE0					//--Режим для импульсов SPI;
#define RT_HW_SPI_INTERRUPT_MODE	0							//--Режим работы с прерываниями SPI;
//----------------------21.3.Дополнительные макросы------------------------------------------------
#define RT_HW_IRAM_ATTR											//--Атрибут для совместимости c ESP8266;
#define	RT_HW_BLOCK_SET_RESOLUTION_ADC							//--Блокировка функции установка разрешения ADC;
#define RT_HW_BLOCK_SET_RESOLUTION_PWM							//--Блокировка функции установка разрешения PWM;
#define RT_HW_BLOCK_I2C_FLUSH									//--Блокировка функции Wirex.flush();
//----------------------21.4.Дополнительные библиотеки---------------------------------------------
#include <avr/pgmspace.h>										//--Работа с PROGMEM;
#include <Wire.h>												//--Подключение библиотеки i2c;	   	
#include <SPI.h>												//--Подключение библиотеки SPI	
//----------------------21.5.Макросы для работы c пинами через функции WIRING----------------------
#define RT_HW_PIN_MODE_INPUT  				INPUT				//--Дискретный вход;
#define RT_HW_PIN_MODE_OUTPUT  				OUTPUT				//--Дискретный выход;
#define RT_HW_PIN_MODE_INPUT_PULLUP  		INPUT_PULLUP 		//--Дискретный вход с подтяжкой к +Vcc;
//----------------------21.6.Макросы для совместимости с STM32-------------------------------------
#define RT_HW_PIN_MODE_INPUT_FLOATING  		INPUT				//--Дискретный вход - аналог INPUT;
#define RT_HW_PIN_MODE_INPUT_PULLDOWN  		INPUT_PULLDOWN		//--Дискретный вход с подтяжкой к GND;
#define RT_HW_PIN_MODE_INPUT_ANALOG  		INPUT_ANALOG		//--Аналоговый вход;
#define RT_HW_PIN_MODE_OUTPUT_OPEN_DRAIN  	OUTPUT_OPEN_DRAIN	//--Дискретный выход с открытым выходом;
#define RT_HW_PIN_MODE_OUTPUT_PWM			 PWM				//--ШИМ выход;
#define RT_HW_PIN_MODE_OUTPUT_PWM_OPEN_DRAIN PWM_OPEN_DRAIN		//--ШИМ выход с открытым коллектором;	
//----------------------21.7.Базовый размер переменной и структура для GPIO------------------------
#define RT_HW_DATE_TYPE 		uint32_t 						//--Тип базовой переменной при прямом управлении пинами;
struct  RT_HW_PIN_DIR_ID {uint32_t pin; uint32_t dir=0; uint32_t bit; volatile uint32_t *base;}; //--Структура для прямого управления пинами
//----------------------21.8.Макросы прямого управления пинами--------------------------------------
#define RT_HW_PIN_DIR_SET_ID(id,p)	  id.pin=p; id.bit=id.pin; 
#define RT_HW_PIN_DIR_MODE_INPUT(id)  pinMode(id.pin,INPUT);		//pin_function((PinName)id.pin, STM_PIN_DATA(STM_MODE_INPUT,     GPIO_NOPULL,0))
#define RT_HW_PIN_DIR_MODE_PULLUP(id) pinMode(id.pin,INPUT_PULLUP);	//pin_function((PinName)id.pin, STM_PIN_DATA(STM_MODE_INPUT,     GPIO_NOPULL,0))
#define RT_HW_PIN_DIR_MODE_OUTPUT(id) pinMode(id.pin,OUTPUT);		//pin_function((PinName)id.pin, STM_PIN_DATA(STM_MODE_OUTPUT_PP, GPIO_NOPULL,0))
#define RT_HW_PIN_DIR_READ(id)        digitalRead(id.pin)			//digitalReadFast((PinName)id.pin);  //digitalRead(id.pin);
#define RT_HW_PIN_DIR_WRITE(id,val)   digitalWrite(id.pin,val);		//if(val){digitalWriteFast((PinName)id.pin,HIGH);} else {digitalWriteFast((PinName)id.pin,LOW);} 
#define RT_HW_PIN_DIR_WRITE_LOW(id)   digitalWrite(id.pin,LOW);		//digitalWriteFast((PinName)id.pin, LOW); 	//digitalWrite(id.pin,0);
#define RT_HW_PIN_DIR_WRITE_HIGH(id)  digitalWrite(id.pin,HIGH);		//digitalWriteFast((PinName)id.pin, HIGH);	//digitalWrite(id.pin,1);
//-------------------------------------------------------------------------------------------------
#endif
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//						22.Программная среда (D) STM32
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#if !defined(RT_HW_CORE_DEFINED) && defined(RT_HW_CORE_D_STM32)
#define      RT_HW_CORE_DEFINED             RT_HW_CODE_D_STM32	//--Идентификатор программной среды;
//----------------------22.1.Основные параметры-----------------------------------------------------
#define RT_HW_ARCH_CODE        		RT_HW_CODE_ARCH_STM32		//--Код архитектуры;
#define RT_HW_ARCH_NAME        		"STM32"						//--Наименование архитектуры;
#define RT_HW_CORE_NAME        		"(D) STM32"	 				//--Наименование программной среды
//----------------------22.2.Дополнительные параметры-----------------------------------------------
#define RT_HW_PIN_TXT_LEN 		 	4  							//--Размер поля при выводе на консоль номеров пинов;
#define RT_HW_PIN_QNT_LINE 		 	16 							//--Кол-во пинов в строке при выводе таблицы на консоль; 
#define RT_HW_I2C_SPEED_DEFAULT  	RT_HW_I2C_SPEED_FM				//--Код скорости шины i2c (default 400kHz);
//-------------------------------------------------------------------------------------------------
#define RT_HW_SPI_CLOCK				4000000UL					//--Скорость SPI в Гц; 
#define RT_HW_SPI_BIT_ORDER         MSBFIRST					//--Порядок следования битов в байте SPI;
#define RT_HW_SPI_DATA_MODE         SPI_MODE0					//--Режим для импульсов SPI;
#define RT_HW_SPI_INTERRUPT_MODE	0							//--Режим работы с прерываниями SPI;
//----------------------22.3.Дополнительные макросы------------------------------------------------
#define RT_HW_IRAM_ATTR											//--Атрибут для совместимости c ESP8266;
//----------------------22.4.Дополнительные библиотеки---------------------------------------------
#include <avr/pgmspace.h>										//--Работа с PROGMEM;
#include <Wire.h>												//--Подключение библиотеки i2c;	   	
#include <SPI.h>												//--Подключение библиотеки SPI	
#include "usbd_cdc_if.h"										//--Для работы с USB_CDC в среде STM32duino
//----------------------22.5.Макросы для работы c пинами через функции WIRING----------------------
#define RT_HW_PIN_MODE_INPUT  				INPUT				//--Дискретный вход;
#define RT_HW_PIN_MODE_OUTPUT  				OUTPUT				//--Дискретный выход;
#define RT_HW_PIN_MODE_INPUT_PULLUP  		INPUT_PULLUP 		//--Дискретный вход с подтяжкой к +Vcc;
//----------------------22.6.Макросы для совместимости с STM32-------------------------------------
#define RT_HW_PIN_MODE_INPUT_FLOATING  		INPUT				//--Дискретный вход - аналог INPUT;
#define RT_HW_PIN_MODE_INPUT_PULLDOWN  		INPUT_PULLDOWN		//--Дискретный вход с подтяжкой к GND;
#define RT_HW_PIN_MODE_INPUT_ANALOG  		INPUT_ANALOG		//--Аналоговый вход;
#define RT_HW_PIN_MODE_OUTPUT_OPEN_DRAIN  	OUTPUT_OPEN_DRAIN	//--Дискретный выход с открытым выходом;
#define RT_HW_PIN_MODE_OUTPUT_PWM			OUTPUT				//--ШИМ выход;
#define RT_HW_PIN_MODE_OUTPUT_PWM_OPEN_DRAIN OUTPUT_OPEN_DRAIN	//--ШИМ выход с открытым коллектором;	
//----------------------22.7.Базовый размер переменной и структура для GPIO------------------------
#define RT_HW_DATE_TYPE 		uint32_t 						//--Тип базовой переменной при прямом управлении пинами;
struct  RT_HW_PIN_DIR_ID {uint32_t pin; uint32_t dir=0; uint32_t bit; volatile uint32_t *base;}; //--Структура для прямого управления пинами
//----------------------22.8.Макросы прямого управления пинами--------------------------------------
#define RT_HW_PIN_DIR_SET_ID(id,p)	  id.pin=p; id.bit=id.pin; 
#define RT_HW_PIN_DIR_MODE_INPUT(id)  pinMode(id.pin,INPUT);		//pin_function((PinName)id.pin, STM_PIN_DATA(STM_MODE_INPUT,     GPIO_NOPULL,0))
#define RT_HW_PIN_DIR_MODE_PULLUP(id) pinMode(id.pin,INPUT_PULLUP);	//pin_function((PinName)id.pin, STM_PIN_DATA(STM_MODE_INPUT,     GPIO_NOPULL,0))
#define RT_HW_PIN_DIR_MODE_OUTPUT(id) pinMode(id.pin,OUTPUT);		//pin_function((PinName)id.pin, STM_PIN_DATA(STM_MODE_OUTPUT_PP, GPIO_NOPULL,0))
#define RT_HW_PIN_DIR_READ(id)        digitalRead(id.pin)			//digitalReadFast((PinName)id.pin);  //digitalRead(id.pin);
#define RT_HW_PIN_DIR_WRITE(id,val)   digitalWrite(id.pin,val);		//if(val){digitalWriteFast((PinName)id.pin,HIGH);} else {digitalWriteFast((PinName)id.pin,LOW);} 
#define RT_HW_PIN_DIR_WRITE_LOW(id)   digitalWrite(id.pin,LOW);		//digitalWriteFast((PinName)id.pin, LOW); 	//digitalWrite(id.pin,0);
#define RT_HW_PIN_DIR_WRITE_HIGH(id)  digitalWrite(id.pin,HIGH);		//digitalWriteFast((PinName)id.pin, HIGH);	//digitalWrite(id.pin,1);
//-------------------------------------------------------------------------------------------------
#endif
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//							90. Идентификация контроллера ANON (неопознанный контроллер)
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#if !defined(RT_HW_CORE_DEFINED) 								//--Плата ANON;
#define      RT_HW_CORE_DEFINED           RT_HW_CORE_ANON		//--Идентификатор программной среды;
//----------------------90.1.Основные параметры----------------------------------------------------
#define RT_HW_ARCH_CODE        RT_HW_CODE_ARCH_ANON				//--Код архитектуры;
#define RT_HW_ARCH_NAME        "ANON"							//--Наименование архитектуры;
#define RT_HW_CORE_NAME        "ANON"	 						//--Наименование программной среды
//----------------------90.2.Дополнительные параметры-----------------------------------------------
#define RT_HW_PIN_TXT_LEN 		2								//--Размер поля при выводе на консоль номеров пинов; 
#define RT_HW_PIN_QNT_LINE 		24								//--Кол-во пинов в стройке при выводе таблицы на консоль; 
#define RT_HW_I2C_SPEED_DEFAULT  RT_HW_I2C_SPEED_FM				//--Код скорости шины i2c (default 400kHz);	
//-------------------------------------------------------------------------------------------------
#define RT_HW_SPI_CLOCK				4000000UL					//--Скорость SPI в Гц; 
#define RT_HW_SPI_BIT_ORDER         0							//--Порядок следования битов в байте SPI;
#define RT_HW_SPI_DATA_MODE         0							//--Режим для импульсов SPI;
#define RT_HW_SPI_INTERRUPT_MODE	0							//--Режим работы с прерываниями SPI;					
//----------------------90.3.Дополнительные макросы------------------------------------------------
#define RT_HW_IRAM_ATTR											//--Атрибут для совместимости c ESP8266;
#define	RT_HW_BLOCK_SET_RESOLUTION_ADC							//--Блокировка функции установка разрешения ADC;
#define RT_HW_BLOCK_SET_RESOLUTION_PWM							//--Блокировка функции установка разрешения PWM;
#define RT_HW_BLOCK_UART1_READ									//--Блокировка функций чтения с UART1 (ESP8266);	
#define RT_HW_BLOCK_UART_AVAILABLE_FOR_WRITE	 				//--Блокировка функций Serialx.availableForWrite;
#define RT_HW_BLOCK_I2C_FLUSH									//--Блокировка функций Wirex.flush();
#define RT_HW_BLOCK_I2C_SLAVE									//--Блокировка функций подддержки i2c Slave;
//----------------------90.4.Дополнительные библиотеки---------------------------------------------
#include <avr/pgmspace.h>										//--Работа с PROGMEM;
#include <Wire.h>												//--Подключение библиотеки i2c;	   	
#include <SPI.h>												//--Подключение библиотеки SPI	
//----------------------90.5.Макросы для работы c пинами через функции WIRING---------------------- 
#define RT_HW_PIN_MODE_INPUT  					INPUT			//--Дискретный вход;
#define RT_HW_PIN_MODE_OUTPUT  					OUTPUT			//--Дискретный выход;
#define RT_HW_PIN_MODE_INPUT_PULLUP  			INPUT_PULLUP 	//--Дискретный вход с подтяжкой к +Vcc;
//----------------------90.6.Макросы для совместимости с STM32-------------------------------------
#define RT_HW_PIN_MODE_INPUT_FLOATING  			INPUT			//--Дискретный вход - аналог INPUT;
#define RT_HW_PIN_MODE_INPUT_PULLDOWN  			INPUT			//--Дискретный вход с подтяжкой к GND;
#define RT_HW_PIN_MODE_INPUT_ANALOG  			INPUT			//--Аналоговый вход;
#define RT_HW_PIN_MODE_OUTPUT_OPEN_DRAIN  	 	OUTPUT			//--Дискретный выход с открытым выходом;
#define RT_HW_PIN_MODE_OUTPUT_PWM				OUTPUT			//--ШИМ выход;
#define RT_HW_PIN_MODE_OUTPUT_PWM_OPEN_DRAIN	OUTPUT			//--ШИМ выход с открытым коллектором;
//----------------------90.7.Базовый размер переменной и структура для GPIO------------------------
#define RT_HW_DATE_TYPE 		uint8_t							//--Тип базовой переменной при прямом управлении пинами;
struct  RT_HW_PIN_DIR_ID {uint8_t pin; uint8_t dir=0; uint8_t bit; volatile uint8_t *base;};	
//----------------------90.8.Макросы прямого управления пинами-------------------------------------	
#define RT_HW_PIN_DIR_SET_ID(id,p) 	        id.pin=p; id.bit=id.pin; 
#define RT_HW_PIN_DIR_MODE_INPUT(id)        pinMode(id.pin,INPUT);			
#define RT_HW_PIN_DIR_MODE_PULLUP(id) 	    pinMode(id.pin,INPUT_PULLUP);
#define RT_HW_PIN_DIR_MODE_OUTPUT(id)       pinMode(id.pin,OUTPUT);
#define RT_HW_PIN_DIR_READ(id)              digitalRead(id.pin)
#define RT_HW_PIN_DIR_WRITE(id,val) 		digitalWrite(id.pin,val); 
#define RT_HW_PIN_DIR_WRITE_LOW(id)         digitalWrite(id.pin,LOW);
#define RT_HW_PIN_DIR_WRITE_HIGH(id)        digitalWrite(id.pin,HIGH);
//-------------------------------------------------------------------------------------------------
#endif
//=================================================================================================
