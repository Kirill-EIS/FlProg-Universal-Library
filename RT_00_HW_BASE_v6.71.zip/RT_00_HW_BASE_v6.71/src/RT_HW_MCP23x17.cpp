#include "RT_HW_MCP23x17.h"
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
//		Настройка (корректировка) ID
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void	RT_HW_MCP23x17:: setID(RT_HW_STRUCT_MCP23x17 &id, uint8_t vA, uint8_t vB){		//==Настройка (корректировка) ID;
if(id.custom==0){
//----------------------------Сохранение(коректировка) основных параметров-------------------------
id.cnfgA=vA; id.cnfgB=vB;					//--Настройка побитовой конфигурации регистров A,B;	
id.inFlagA =id.outFlagA =id.inFlagB =id.outFlagB =false;	//--Очистка флагов конфигурации      (вход/выход) регистров PA,PB;
id.inFreshA=id.outFreshA=id.inFreshB=id.outFreshB=false; 	//--Очистка флагов готовности данных (вход/выход) регистров PA,PB;
if(id.cnfgA!=0)    {id.inFlagA =id.inFreshA =true;}			//--PA как вход;
if(id.cnfgA!=0xFF) {id.outFlagA=id.outFreshA=true;}			//--PA как выход;
if(id.cnfgB!=0)    {id.inFlagB =id.inFreshB =true;}			//--PA как вход;
if(id.cnfgB!=0xFF) {id.outFlagB=id.outFreshB=true;}			//--PA как выход;
//--------------------------------Настройка шин----------------------------------------------------
if(id.link=='I'){		//==Настройка шины i2c как Master------------------------------------------
if(id.adr<8) {id.adr=0x20+id.adr;}	//--Корректировка адресов i2c для диапазона 0-7;
RT_HW_Base.i2cBegin(255,255,0, id.bus); 												//--Настройка i2c. Функция выполняет действия, если шина раньше не настраивалась;
if(!RT_HW_Base.i2cCheckBusState(RT_HW_I2C_STATE_MASTER,id.bus)){id.custom=90; return;}}	//--Если шина не настроена, выход  по состоянию =90; 	
else if(id.link=='S'){	//==Настройка шины SPI как Master------------------------------------------
//if(!RT_HW_Base.checkPinPGM( RT_HW_PGM_PIN_DOT_ID,id.adr)){id.custom=91; return;}		//--Проверка пина cs на дискретный вывод;
//RT_HW_PIN_DIR_SET_ID(id.ddCS,id.adr);													//--Настройка ID пина 
//RT_HW_PIN_DIR_WRITE_HIGH(id.ddCS); RT_HW_PIN_DIR_MODE_OUTPUT(id.ddCS); 					//--Настройка пина CS;
//RT_HW_Base.spiBegin(255,255,255,255,id.bus);											//--Настройка SPI. Функция выполняет действия, если шина раньше не настраивалась;
//if(!RT_HW_Base.spiCheckBusState(RT_HW_SPI_STATE_MASTER,id.bus)) {id.custom=92; return;}	//--Если шина не настроена, выход  по состоянию =94; 	
//RT_HW_PIN_DIR_WRITE_LOW(id.ddCS); RT_HW_Base.spiSendByte(0,id.bus); RT_HW_PIN_DIR_WRITE_HIGH(id.ddCS);
} //--Очистка SPI;
else {					//==Если не определен тип шины---------------------------------------------
	id.custom=93; return;}															//--Выход по ошибке;
//----------------------------------------------------------------------------------------
id.custom=1;}									//--Код успешного завершения настройки ID;
};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//		Управление устройством
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void RT_HW_MCP23x17:: direct(RT_HW_STRUCT_MCP23x17 &id, bool EN){
if(EN){id.EN=1;}								//==Фиксация события по входу EN;
if(id.dir== 0) {								//==Стартовая идентификация устройства;
	if(id.custom!=1) {return;} 						//--Ожидание настройки ID;
	if(!id.EN)       {return;}						//--Ожидание разрешения работы;
	id.timePeriod=millis();							//--Установка параметров;
	if      (id.link=='I'){id.bu16=0; id.dir= 1;}	//--Переход на инициализацию i2c;
	else if (id.link=='S') 			 {id.dir= 2;}	//--Переход на инициализацию SPI;
	else                  {id.custom=96; return;}	//--Выход при ошибочном id.link;
	return;}
if(id.dir== 1) {								//==Для i2c поиск устройства на шине;
	if(RT_HW_Base.i2cFindAdr(id.timePeriod,id.bu16,id.adr,id.bus,3,10,2000)){id.dir=5;} return;} //--Поиск устройства на шине i2c;
if(id.dir== 2) {id.dir=5;}						//==Проверка наличия устройства на SPI (ЗАГЛУШКА);					
if(id.dir== 5) {								//==Инициализация устройства;
	init(id); id.timePeriod=millis(); 				//--Вызов функции настройки и настройка параметра времени;
	if(id.errLink==0){id.dir=10;} else {id.dir=40;} return;}//--Продолжение или  переход по ошибке обмена;
if(id.dir==10) {								//==Проверка id.EN(EN) в каждом цикле запуска;
	if(!id.EN) {return;} id.dir++; return;}
if(id.dir==11) {
	if((++id.cntPeriod)>=id.divPeriod){id.cntPeriod=0; devRead(id);		//==Чтение из устройства;
       if(id.errLink==0){id.freshInput=id.getOutput=1; id.dir=12;} 		//--Продолжение или  переход по ошибке обмена;
	else {id.dir=40;} return;} else id.dir=12;}
if(id.dir==12) {devWrite(id);					//==Запись в устройство;
	if(id.errLink==0){id.dir=20;} else {id.dir=40;} return;}//--Продолжение или  переход по ошибке обмена;
if(id.dir==20) {								//==Ожидание завершения периода;
	if(RT_HW_Base.periodMs(id.timePeriod,id.period)) {id.EN=0; id.dir=10;} return;}
if(id.dir==40) {								//==Обработка ошибки связи (программная задержка и переход на перезапуск);
	if(RT_HW_Base.getPastMs(id.timePeriod)<1000) {return;} else {id.dir=00;}}
}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
// 		Запись в устройство
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
void RT_HW_MCP23x17:: write (RT_HW_STRUCT_MCP23x17 &id, uint8_t qnt){
//------Отправка через интерфейс i2c-----------------------
     if(id.link=='I'){id.errLink=RT_HW_Base.i2cSendBytes(id.arr,qnt,id.adr,id.bus); return;}
//------Отправка через интерфейс SPI-----------------------
else if(id.link=='S'){
//	for(uint8_t i=0; i<qnt; i++){
//					  RT_HW_PIN_DIR_WRITE_LOW(id.ddCS); RT_HW_Base.spiSendByte(id.arr[i],id.bus);	RT_HW_PIN_DIR_WRITE_HIGH(id.ddCS);}
//					  id.errLink=0; 
					  return;}
//---------------------------------------------------------	
else   {id.errLink=50;}
//---------------------------------------------------------		
}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
// 		Чтение из устройства
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
void RT_HW_MCP23x17:: read  (RT_HW_STRUCT_MCP23x17 &id, uint8_t reg, uint8_t qnt){ 
//------Отправка через интерфейс i2c-----------------------
     if(id.link=='I'){id.errLink=RT_HW_Base.i2cReadRegs(reg,qnt,id.adr,id.bus); return;}
//------Отправка через интерфейс SPI-----------------------
else if(id.link=='S'){id.errLink=40;}
//---------------------------------------------------------	
else                 {id.errLink=50;}
//--------------------------------------------------------
}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
// 		Настройка устройства
//--Режимы входов:=0 инвер.+подтяжка к Vcc; =1 инвер.;=2 - подтяжка к Vcc; =3-как есть;
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
void RT_HW_MCP23x17:: init(RT_HW_STRUCT_MCP23x17 &id) {
//-------------------------------------------------------------------------------------------------
id.arr[0]=RT_HW_MCP23x17_IODIRA; 			//--Адрес начального регистра;
id.arr[1]=id.cnfgA;							//--Установка направление регистра A (ввод=0xff/вывод=0x00);
id.arr[2]=id.cnfgB;							//--Установка направление регистра B (ввод=0xff/вывод=0x00); 
id.arr[3]=id.cnfgIPOLA;						//--Побитовая полярность входов регистра PA (0-как есть, 1-с инверсией); 
id.arr[4]=id.cnfgIPOLB;    					//--Побитовая полярность входов регистра PB (0-как есть, 1-с инверсией);  				
write(id,5);								//--Запись в устройство;
if(id.errLink!=0) {return;}					//--Выход, если ошибка обмена;
//-------------------------------------------------------------------------------------------------
id.arr[0]=RT_HW_MCP23x17_GPPUA; 			//--Адрес начального регистра;
id.arr[1]=id.cnfgGPPUA;						//--Побитовая подтяжка входов регистра PA к Vсс(0-нет, 1-есть подтяжка 100кОм к Vcc); 
id.arr[2]=id.cnfgGPPUB;						//--Побитовая подтяжка входов регистра PB к Vсс(0-нет, 1-есть подтяжка 100кОм к Vcc); 	
write(id,3);								//--Запись в устройство;
};	
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//            			 Чтение из устройства	
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void RT_HW_MCP23x17:: devRead(RT_HW_STRUCT_MCP23x17 &id){		//==Чтение из устройства;	
//if( !id.inFlagA  && !id.inFlagB){;}
if( id.inFlagA   && !id.inFlagB){ id.inFreshA=1; 
								  if(id.inFreshA){id.inFreshA=0; 
                                  read(id,RT_HW_MCP23x17_GPIOA,1); id.inA=RT_HW_Base.i2cReadBuff(id.bus); id.setInputA=1;}}
if(!id.inFlagA   &&  id.inFlagB){ id.inFreshB=1; 
								  if(id.inFreshB){id.inFreshB=0; 
                                  read(id,RT_HW_MCP23x17_GPIOB,1); id.inB=RT_HW_Base.i2cReadBuff(id.bus); id.setInputB=1;}}
if( id.inFlagA   &&  id.inFlagB){ id.inFreshA=id.inFreshB=1; 
								  if((id.inFreshA)||(id.inFreshB)){id.inFreshA=id.inFreshB=0; 
							      read(id,RT_HW_MCP23x17_GPIOA,2); id.inA=RT_HW_Base.i2cReadBuff(id.bus); id.inB=RT_HW_Base.i2cReadBuff(id.bus); id.setInputA=id.setInputB=1;}} 
};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//            			 Запись в устройство
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void RT_HW_MCP23x17:: devWrite(RT_HW_STRUCT_MCP23x17 &id){
//arr[0]=id.agoA; arr[1]=id.outA;
//arr[2]=id.agoB; arr[3]=id.outB;
//if(!id.outFlagA && !id.outFlagB){;}
if( id.outFlagA && !id.outFlagB){if(id.agoA!=id.outA){id.agoA=id.outA; id.outFreshA=1;} if(id.outFreshA){id.outFreshA=0; 
							                                    id.arr[0]=RT_HW_MCP23x17_GPIOA; id.arr[1]=id.outA;                    write(id,2); id.getOutputA=1;}}	
if(!id.outFlagA &&  id.outFlagB){if(id.agoB!=id.outB){id.agoB=id.outB; id.outFreshB=1;} if(id.outFreshB){id.outFreshB=0; 
								                                id.arr[0]=RT_HW_MCP23x17_GPIOB; id.arr[1]=id.outA;                    write(id,3); id.getOutputB=1;}}	 	
if( id.outFlagA &&  id.outFlagB){if(id.agoA!=id.outA){id.agoA=id.outA; id.outFreshA=1;} if(id.agoB!=id.outB){id.agoB=id.outB; id.outFreshB=1;} 
//if(!id.outFlagA && !id.outFlagB){;}	
if( id.outFreshA && !id.outFreshB){id.outFreshA=0; 			    id.arr[0]=RT_HW_MCP23x17_GPIOA; id.arr[1]=id.outA;                    write(id,2); id.getOutputA=1;}	
if(!id.outFreshA &&  id.outFreshB){id.outFreshB=0; 			    id.arr[0]=RT_HW_MCP23x17_GPIOB; id.arr[1]=id.outB;                    write(id,2); id.getOutputB=1;}	
if( id.outFreshA &&  id.outFreshB){id.outFreshA=id.outFreshB=0; id.arr[0]=RT_HW_MCP23x17_GPIOA; id.arr[1]=id.outA; id.arr[2]=id.outB; write(id,3); id.getOutputA=1; id.getOutputB=1; }
								}
};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
RT_HW_MCP23x17 RT_HW_mcp23x17;//--Создание внешнего объекта	
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++



