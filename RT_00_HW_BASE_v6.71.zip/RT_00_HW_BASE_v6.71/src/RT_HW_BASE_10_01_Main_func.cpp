#include "RT_HW_BASE.h"
//=================================================================================================
//							СИСТЕМНЫЕ ФУНКЦИИ
//=================================================================================================
bool 	 RT_HW_BASE:: checkArch (uint8_t codeArch) {									//==Проверка соответствия кода архитектуры(codeArch) подключенному контроллеру;
	if(device.board.codeArch ==codeArch) {return 1;} else {return 0;}};
bool 	 RT_HW_BASE:: checkBoard(uint8_t codeBoard){									//==Проверка соответствия кода платы     (codeBoard) подключенному контроллеру;
	if(device.board.codeBoard==codeBoard){return 1;} else {return 0;}};		
int8_t   RT_HW_BASE:: getFistFreeBit    (uint16_t &reg, uint8_t maxNum){				//==Возвращает номер первого свободного бита (0:15) или -1;	
 if(maxNum>16) {return -1;} for(uint8_t i=0;i<maxNum;i++){if(!bitRead(reg,i)) return i;} return -1;};
int8_t   RT_HW_BASE:: setFirstFreeBit   (uint16_t &reg, uint8_t maxNum){				//==Занимает первый свободный бит и возвращает его номер(0:15) или -1; 
 if(maxNum>16) {return -1;}
 for(uint8_t i=0;i<maxNum;i++){if(!bitRead(reg,i)) {bitSet(reg,i); return i;}} return -1;};	
bool     RT_HW_BASE:: checkBusyNumBit   (uint16_t &reg, uint8_t num, uint8_t maxNum){	//==Проверяет занятость в reg номера бита num(0:15) при ограничении его номера maxNum(if(num>max){return 0;}; 
 if(maxNum>16) {return 0;} return bitRead(reg,num);};		
uint8_t  RT_HW_BASE:: setFistFreeDevice (uint16_t &reg, uint8_t maxNum){				//==Занимает в reg номер первого свободного устройства(1:16) и возращает его номер или 0; 	
 if((maxNum>16) || (maxNum==0)) {return 0;}
 for(uint8_t i=1;i<=maxNum;i++){if(!bitRead(reg,(i-1))) {bitSet(reg,(i-1)); return i;}} return 0;};	
bool     RT_HW_BASE:: checkBusyNumDevice(uint16_t &reg, uint8_t num, uint8_t maxNum) {	//==Проверяет занятость номера устройства(1:16); 
  if((maxNum>16) || (num==0)) {return 0;}
  return bitRead(reg,(num-1));};		
uint16_t RT_HW_BASE:: maxBitDepth (uint8_t  v){											//==Возвращает max для  разрядности=v(0:16);
	if(v>=16) {return 0xFFFF;} if(v==0){return 0;} return ((1<<v)-1);};	
uint16_t RT_HW_BASE:: normADC  	  (uint16_t v){											//==Нормализация значения ADC до системного значения SYS;
	return map(v,0,maxBitDepth(device.depth.adc),0,maxBitDepth(device.depth.sys));};
uint16_t RT_HW_BASE:: normPWM  	  (uint16_t v){											//==Нормализация системного значения SYS до значения для PWM;
	return map(v,0,maxBitDepth(device.depth.sys),0,maxBitDepth(device.depth.pwm));};
uint16_t RT_HW_BASE:: normDAC  	  (uint16_t v){											//==Нормализация системного значения SYS до значения для DAC;
 return map(v,0,maxBitDepth(device.depth.sys),0,maxBitDepth(device.depth.dac));};
uint16_t RT_HW_BASE:: makeDelta   (uint16_t ago, uint16_t cur, uint8_t delta){			//==Гистерезис. Меняет ago на val при его отклонение на delta.  Возвращает ago;
if(cur>ago) {if((cur-ago)>delta) {ago=cur; return ago;}} 
if(cur<ago) {if((ago-cur)>delta) {ago=cur; return ago;}} 
return ago;}  
uint8_t  RT_HW_BASE:: getNumberVal(uint32_t val, char mode, uint8_t len, uint8_t n){	//==Возвращает цифру из val(форматы mode=D,H,B) ее номеру(1:10) (начиная со старшей позиции);
uint32_t buff32=0;
if((n>len) || (n>10)) n=0; 
if(mode=='B') {buff32=(val>>(len-n))&1;}
if(mode=='H') {buff32=(val>>(len-n)*4)&0xf;}
if(mode=='D') {n=len-n+1; while(n!=0) {buff32=val; val/=10; buff32=buff32-(val*10); n--;};}
//if(buff32<=9) {buff32=buff32 +'0';} else {buff32=buff32-10+(upper ? 'A' : 'a') ;}
return (uint8_t)buff32;};
//=================================================================================================
//			ФУНКЦИИ ДЛЯ РАБОТЫ МАССИВАМИ PGM БИБЛИОТЕКИ RT_HW_BASE.h(kind - тип массива)
//=================================================================================================	
String   RT_HW_BASE:: getNameKindPin(uint8_t kind){										//==Возвращает обозначения массива в текстовой форме;
//-------------------------------------------------------------------------------------------------
if(kind==RT_HW_PGM_SYS_PAR_ID) {return String(F("par"));}	
if(kind==RT_HW_PGM_SYS_ADC_ID) {return String(F("adc"));}
if(kind==RT_HW_PGM_SYS_TCH_ID) {return String(F("tch"));}	
if(kind==RT_HW_PGM_SYS_PWM_ID) {return String(F("pwm"));}
if(kind==RT_HW_PGM_SYS_DAC_ID) {return String(F("dac"));}
//-------------------------------------------------------------------------------------------------
if(kind==RT_HW_PGM_SYS_PIN_ID) {return String(F("pin"));}
if(kind==RT_HW_PGM_PIN_I2C_ID) {return String(F("I2C"));}
if(kind==RT_HW_PGM_PIN_SPI_ID) {return String(F("SPI"));}
if(kind==RT_HW_PGM_PIN_UHS_ID) {return String(F("UHS"));}	
if(kind==RT_HW_PGM_PIN_USS_ID) {return String(F("USS"));}	
if(kind==RT_HW_PGM_PIN_CAN_ID) {return String(F("CAN"));}
if(kind==RT_HW_PGM_PIN_BTH_ID) {return String(F("BTH"));}
if(kind==RT_HW_PGM_PIN_ETH_ID) {return String(F("ETH"));}
if(kind==RT_HW_PGM_PIN_WFI_ID) {return String(F("WFI"));}
//-------------------------------------------------------------------------------------------------
if(kind==RT_HW_PGM_PIN_ALL_ID) {return String(F("ALL"));}	
if(kind==RT_HW_PGM_PIN_DIN_ID) {return String(F("DIN"));}
if(kind==RT_HW_PGM_PIN_ADC_ID) {return String(F("ADC"));}
if(kind==RT_HW_PGM_PIN_TCH_ID) {return String(F("TCH"));}	
if(kind==RT_HW_PGM_PIN_DOT_ID) {return String(F("DOT"));}
if(kind==RT_HW_PGM_PIN_PWM_ID) {return String(F("PWM"));}
if(kind==RT_HW_PGM_PIN_DAC_ID) {return String(F("DAC"));}
if(kind==RT_HW_PGM_PIN_INT_ID) {return String(F("INT"));} 
if(kind==RT_HW_PGM_PIN_N5V_ID) {return String(F("N5V"));}
//-------------------------------------------------------------------------------------------------
if(kind==RT_HW_PGM_PIN_DBG_ID) {return String(F("DBG"));}
if(kind==RT_HW_PGM_PIN_OUT_ID) {return String(F("OUT"));}
if(kind==RT_HW_PGM_PIN_INP_ID) {return String(F("INP"));} 
if(kind==RT_HW_PGM_PIN_DCT_ID) {return String(F("DCT"));}
if(kind==RT_HW_PGM_PIN_DEV_ID) {return String(F("DEV"));}
if(kind==RT_HW_PGM_PIN_CSS_ID) {return String(F("CSS"));}	
if(kind==RT_HW_PGM_PIN_LC6_ID) {return String(F("LC6"));}
if(kind==RT_HW_PGM_PIN_TFT_ID) {return String(F("TFT"));}		
if(kind==RT_HW_PGM_PIN_SSP_ID) {return String(F("SSP"));}
if(kind==RT_HW_PGM_ADR_I2C_ID) {return String(F("ADR"));}
//-------------------------------------------------------------------------------------------------	
return String(F(" - "));  };
uint8_t  RT_HW_BASE:: getFromArrPGM (uint8_t kind, uint8_t n){							//==Возвращает из массива элемент с индексом;
//-----Системные параметры-------------------------------------------------------------------------
if(kind==RT_HW_PGM_SYS_PAR_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_SYS_PAR,n);}
if(kind==RT_HW_PGM_SYS_ADC_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_SYS_ADC,n);}
if(kind==RT_HW_PGM_SYS_TCH_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_SYS_TCH,n);}
if(kind==RT_HW_PGM_SYS_PWM_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_SYS_PWM,n);}
if(kind==RT_HW_PGM_SYS_DAC_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_SYS_DAC,n);}
//-----Системные пины------------------------------------------------------------------------------
if(kind==RT_HW_PGM_SYS_PIN_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_SYS_PIN,n);}
//-----Пины интерфейсов связи----------------------------------------------------------------------
if(kind==RT_HW_PGM_PIN_I2C_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_PIN_I2C,n);}
if(kind==RT_HW_PGM_PIN_SPI_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_PIN_SPI,n);}
if(kind==RT_HW_PGM_PIN_UHS_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_PIN_UHS,n);}
if(kind==RT_HW_PGM_PIN_USS_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_PIN_USS,n);}
if(kind==RT_HW_PGM_PIN_CAN_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_PIN_CAN,n);}
if(kind==RT_HW_PGM_PIN_BTH_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_PIN_BTH,n);}
if(kind==RT_HW_PGM_PIN_ETH_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_PIN_ETH,n);}
if(kind==RT_HW_PGM_PIN_WFI_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_PIN_WFI,n);}
//-----Пины контроллера----------------------------------------------------------------------------
if(kind==RT_HW_PGM_PIN_ALL_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_PIN_ALL,n);}
if(kind==RT_HW_PGM_PIN_DIN_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_PIN_DIN,n);}
if(kind==RT_HW_PGM_PIN_ADC_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_PIN_ADC,n);}
if(kind==RT_HW_PGM_PIN_TCH_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_PIN_TCH,n);}
if(kind==RT_HW_PGM_PIN_DOT_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_PIN_DOT,n);}
if(kind==RT_HW_PGM_PIN_PWM_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_PIN_PWM,n);}
if(kind==RT_HW_PGM_PIN_DAC_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_PIN_DAC,n);}
if(kind==RT_HW_PGM_PIN_INT_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_PIN_INT,n);}
if(kind==RT_HW_PGM_PIN_N5V_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_PIN_N5V,n);}
//-----Тестовые пины-------------------------------------------------------------------------------
if(kind==RT_HW_PGM_PIN_DBG_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_PIN_DBG,n);}
if(kind==RT_HW_PGM_PIN_OUT_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_PIN_OUT,n);}
if(kind==RT_HW_PGM_PIN_INP_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_PIN_INP,n);}
if(kind==RT_HW_PGM_PIN_DCT_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_PIN_DCT,n);}
if(kind==RT_HW_PGM_PIN_DEV_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_PIN_DEV,n);}
if(kind==RT_HW_PGM_PIN_CSS_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_PIN_CSS,n);}
if(kind==RT_HW_PGM_PIN_LC6_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_PIN_LC6,n);}
if(kind==RT_HW_PGM_PIN_TFT_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_PIN_TFT,n);}
if(kind==RT_HW_PGM_PIN_SSP_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_PIN_SSP,n);}
//-----Тестовые адреса устройств i2c---------------------------------------------------------------
if(kind==RT_HW_PGM_ADR_I2C_ID)	{return RT_HW_READ_BYTE_PGM(RT_HW_PGM_ADR_I2C,n);}
//-------------------------------------------------------------------------------------------------
return 0;}	
uint8_t  RT_HW_BASE:: readArrPGM    (uint8_t kind, uint8_t n){	//==Возвращает из массива элемент с контролем размера массива. Иначе возвращает 255;
uint8_t len=0;
for(uint8_t i=0;i<255;i++){if(getFromArrPGM(kind,i)==RT_HW_PGM_END){break;} len++;} ;
if(n>=len) {return 255;} 
return getFromArrPGM(kind,n);
};
bool     RT_HW_BASE:: checkPinPGM   (uint8_t kind, uint8_t n){							//==Проверяет наличие в массиве пина равным n; 
for(uint8_t i=0;i<255;i++){uint8_t k=getFromArrPGM(kind,i); if(k==RT_HW_PGM_END) {return  0;} if(k==n){return 1;}} return 0;};
uint8_t  RT_HW_BASE:: getLenFullPGM (uint8_t kind){uint8_t cnt=0;						//==Возвращает размер массива;
for(uint8_t i=0;i<255;i++){uint8_t k=getFromArrPGM(kind,i); if(k==RT_HW_PGM_END){break;}                  cnt++;} return cnt;};
uint8_t  RT_HW_BASE:: getLenPosPGM  (uint8_t kind){uint8_t cnt=0;						//==Возвращает кол-во действительных значений(0-253) в массиве;
for(uint8_t i=0;i<255;i++){uint8_t k=getFromArrPGM(kind,i); if(k==RT_HW_PGM_END){break;}     if(k!=255) {cnt++;}} return cnt;};
//=================================================================================================
//							ФУНКЦИИ КОНТРОЛЯ ИЗМЕНЕНИЯ ЗНАЧЕНИЙ ПЕРЕМЕННЫХ И МАССИВОВ
//=================================================================================================	
bool	 RT_HW_BASE:: checkVarV8    (uint8_t  &valAgo, uint8_t  &valCur){				//==Проверка на изменение uint8_t;
	if(valAgo!=valCur){valAgo=valCur; return 1;} return 0;};
bool	 RT_HW_BASE:: checkVarV16   (uint16_t &valAgo, uint16_t &valCur){				//==Проверка на изменение uint16_t;
	if(valAgo!=valCur){valAgo=valCur; return 1;} return 0;};
bool	 RT_HW_BASE:: checkVarV32   (uint32_t &valAgo, uint32_t &valCur){				//==Проверка на изменение uint32_t;
	if(valAgo!=valCur){valAgo=valCur; return 1;} return 0;};
bool	 RT_HW_BASE:: checkVarFloat (float    &valAgo, float    &valCur){				//==Проверка на изменение float;
	if(valAgo!=valCur){valAgo=valCur; return 1;} return 0;};
bool	 RT_HW_BASE:: checkVarChar  (char     &valAgo, char     &valCur){				//==Проверка на изменение char;
	if(valAgo!=valCur){valAgo=valCur; return 1;} return 0;};
bool	 RT_HW_BASE:: checkVarStr   (String   &valAgo, String   &valCur){				//==Проверка на изменение String;
	if(valAgo!=valCur){valAgo=valCur; return 1;} return 0;};
bool  	 RT_HW_BASE:: checkArrV8    (uint8_t  *arrAgo, uint8_t  *arrCur, uint8_t qnt){	//==Проверка изменения значений в arrAgo[] относительно arrV8; 
	bool ok=LOW; for(uint8_t i=0; i<qnt; i++) {if(arrAgo[i]!=arrCur[i])   {arrAgo[i]=arrCur[i]; ok=HIGH;}} return ok;};
bool  	 RT_HW_BASE:: checkArrV16   (uint16_t *arrAgo, uint16_t *arrCur, uint8_t qnt){	//==Проверка изменения значений в arrAgo[] относительно arrV16; 
	bool ok=LOW; for(uint8_t i=0; i<qnt; i++) {if(arrAgo[i]!=arrCur[i])   {arrAgo[i]=arrCur[i]; ok=HIGH;}} return ok;};
bool  	 RT_HW_BASE:: checkArrV32   (uint32_t *arrAgo, uint32_t *arrCur, uint8_t qnt){	//==Проверка изменения значений в arrAgo[] относительно arrV32; 
	bool ok=LOW; for(uint8_t i=0; i<qnt; i++) {if(arrAgo[i]!=arrCur[i])   {arrAgo[i]=arrCur[i]; ok=HIGH;}} return ok;};
bool  	 RT_HW_BASE:: checkArrFloat (float    *arrAgo, float    *arrCur, uint8_t qnt){	//==Проверка изменения значений в arrAgo[] относительно arrFloat; 
	bool ok=LOW; for(uint8_t i=0; i<qnt; i++) {if(arrAgo[i]!=arrCur[i])   {arrAgo[i]=arrCur[i]; ok=HIGH;}} return ok;};
bool 	 RT_HW_BASE:: checkArrPin   (uint8_t  *arrPin, uint8_t qnt){						//==Возвращает 1, если хотя бы одно значение в массиве пинов >0;
for(uint8_t i=0; i<qnt; i++) {if(arrPin[i]<254){return 1;}} return 0;}; 
bool 	 RT_HW_BASE:: checkArrAdrI2C(uint8_t *arrPin, uint8_t qnt){						//==Возвращает 1, если хотя бы одно значение в массиве пинов >0;
bool ok=0;
for(uint8_t i=0; i<qnt; i++) {if(arrPin[i]<254){ok=1;}}
return ok;}; 
//=================================================================================================	
// 							ФУНКЦИИ ДЛЯ РАБОТЫ СО СТРОКОВЫМИ ПЕРЕМЕННЫМИ И СИМВОЛАМИ
//=================================================================================================	
char    RT_HW_BASE:: boolToChar (bool val, char sign_0,char sign_1){				//==Конвертация bool в char;
	if(val) return sign_1; else return sign_0;};
char 	RT_HW_BASE:: getSignBool(char mode, bool v){								//==Возвращает символы для отображения битовой переменной;
if(mode=='1') {if(v) {return '*';}  else  {return ' ';}} 	
if(mode=='2') {if(v) {return '#';}  else  {return ' ';}} 	
if(mode=='3') {if(v) {return '+';}  else  {return '-';}} 	
if(mode=='4') {if(v) {return '1';}  else  {return '0';}}
if(mode=='5') {if(v) {return '<';}  else  {return '>';}} 
if(mode=='6') {if(v) {return '+';}  else  {return '_';}} 	
if(mode=='7') {if(v) {return '*';}  else  {return '_';}} 
if(mode=='8') {if(v) {return '#';}  else  {return '_';}}  
if(mode=='9') {if(v) {return '.';}  else  {return '_';}}	
if(mode=='0') {if(v) {return 0xFF;} else  {return ' ';}} 
if(v) {return '*';} else  {return ' ';} 	
};
uint8_t RT_HW_BASE:: getLenBegin(uint8_t len,uint8_t src,char alig){				//==Возвращает кол-во заполнителей спереди для выравнивания строк(alig=L,C,R,N, len=длина строки, src=длина заполняемого поля);
if(len<=src) return 0; 
switch(alig){default:return 0; case 'C':return (len-src-(len-src)/2); case 'R':return (len-src);}};  
uint8_t RT_HW_BASE:: getLenEnd  (uint8_t len,uint8_t src,char alig){//==Получение кол-ва заполнителей сзади--	
if(len<=src) return 0;
switch(alig){default:return 0; case 'C':return (len-src-getLenBegin(len,src,alig)); case 'L':return (len-src);}}
uint8_t RT_HW_BASE:: getLenVal  (char mode, int32_t val){			//==Получение кол-ва знаков в числе------
//--Получение кол-ва знаков в числах  с оcнованиями 10,16,2 (DEC(I,U),HEX,BIN):
uint32_t v, buff; uint8_t len=0; uint8_t bs;
if(mode=='I') {if(val<0) {v=-val;} else {v=val;}	
								buff=bs=10;  len=1; for(int8_t i=0;i<10;i++) {if(v<buff){break;} buff=buff*bs; len++;} if(val<0) {len++;}} 
if(mode=='U') {v=(uint32_t)val; buff=bs=10;  len=1; for(int8_t i=0;i<10;i++) {if(v<buff){break;} buff=buff*bs; len++;}} 
if(mode=='H') {v=(uint32_t)val;	buff=bs=0xF; len=1; for(int8_t i=0;i<10;i++) {if(v<buff){break;} buff=buff*bs; len++;}} 
if(mode=='B') {v=(uint32_t)val;	buff=bs=0x1; len=1; for(int8_t i=0;i<10;i++) {if(v<buff){break;} buff=buff*bs; len++;}} 
return len;};
String  RT_HW_BASE:: getTextFromString  (String val, uint8_t n, char separator) {  	//==Возвращает тексты (через разделители) из строки (DEBUG !!!);
//--n позиция в строке начиная с 1. Если значения нет или пробел, возвращает один пробел;
String x;
//int16_t findPoint; uint8_t startPoint,endPoint,endString,len; String x,s; 
//startPoint=endPoint=findPoint=0;  s=val; x="";
//len=val.length(); 									//--Длина строки;
/*
for(uint8_t i=0; i<n; i++){							//--Начало поиска;
	if(startPoint>len) {endString=1; break;}		//--Выход, если 	 
	findPoint=val.indexOf(separator, startPoint);  //--Поиск разделителя;
	if(findPoint==-1) {endPoint=len;} else {endPoint=findPoint;}
 }
do{if(i>n) break;
    if(startPoint>len) break;
	findPoint=val.indexOf(',', startPoint);   
	if (findPoint==-1) {endPoint=len;} else {endPoint=findPoint;}
	if (n==i) {s=val.substring(startPoint,endPoint); s.trim(); if(s=="") {break;} x=s; break;}  
	if (findPoint==-1)  break;
	startPoint=findPoint+1;	i++; 	
   } while (1);
     // Serial.println("text- start=>"+String(startPoint) + " end=" +String(endPoint) + " find=" + String(findPoint) + " x=" + String(x));
*/  
return x;}
//=================================================================================================	
// 							ФУНКЦИИ ДЛЯ КОНВЕРТАЦИИ Float
//=================================================================================================	
float   RT_HW_BASE:: normFloatToFloat(char mode, float var){			//==Возращает отформатированное float: если mode=0,1,2,3,4 - кол-во знаков после точки или вывод как есть;
	 if(mode=='0'){return (int32_t)(var)      /1.0;}
else if(mode=='1'){return (int32_t)(var*10)   /10.0;}
else if(mode=='2'){return (int32_t)(var*100)  /100.0;}
else if(mode=='3'){return (int32_t)(var*1000) /1000.0;}	
else if(mode=='4'){return (int32_t)(var*10000)/10000.0;}	
else if(mode=='9'){return var;}		
else {return var;}	
}
int16_t RT_HW_BASE:: normFloatToInt16(char mode, float var){						//==Возращает отформатированное int: если mode=1 return (int16_t)var*10, =2 ...var*100, или вывод var;
	 if(mode=='A'){return (int16_t)(var);}
else if(mode=='B'){return (int16_t)(var*10);}
else if(mode=='C'){return (int16_t)(var*100);}
else if(mode=='D'){return (int16_t)(var*1000);}			
else {return (int16_t)var;}	
}
float   RT_HW_BASE:: normBoolToFloat(bool v){if(v) {return 1;} else {return 0;}}
//=================================================================================================	
// 							ФУНКЦИИ ДЛЯ РАБОТЫ СО СТРОКОВЫМИ ПЕРЕМЕННЫМИ И СИМВОЛАМИ
//=================================================================================================	
int16_t RT_HW_BASE:: getNumberFromString(String val, uint8_t n, char separator) {	//==Возвращает число int16 из строки с разделителями(DEBUG !!!);
//--n позиция в строке начиная с 1. Если значения нет или =0, возвращает -32768;
int16_t x; int16_t findPoint; uint8_t startPoint,endPoint, len,i; String s;
 startPoint=endPoint=findPoint=0;  s=val; len=val.length();
 x=-32768;
 if(n==0) {return x;} i=1;
 do{if(i>n) break;
    if(startPoint>len) break;
	findPoint=val.indexOf(separator, startPoint);   
	if (findPoint==-1) {endPoint=len;} else {endPoint=findPoint;}
	if (n==i) {s=val.substring(startPoint,endPoint); s.trim(); if(s=="") {break;} x=s.toInt(); break;}  
	if (findPoint==-1)  break;
	startPoint=findPoint+1;	i++; 	
   } while (1);
return x;}	
uint8_t RT_HW_BASE:: getPinFromString   (String val, uint8_t n, char separator) {	//==Возвращает номер пина из строки с разделителями(DEBUG !!!);
//--n позиция в строке начиная с 1. Если значения нет или =0, возвращает -32768;
int16_t x=getNumberFromString(val,n,separator);
if ((x<0)|| (x>253)) {x=255;}
return (uint8_t)x;
}

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//uint16_t RT_HW_BASE:: getValPGM	    (uint8_t kind, uint8_t n){							//==Возвращает uint16_t из массива по индексу. Если n>длины массива,то 0;
//uint8_t len;
//len=getLenFullPGM(kind); if((n+1)>=len) {return 0;} 
//return (((uint8_t)readArrPGM(kind,n)<<8) + ((uint8_t)readArrPGM(kind,n+1)));} 