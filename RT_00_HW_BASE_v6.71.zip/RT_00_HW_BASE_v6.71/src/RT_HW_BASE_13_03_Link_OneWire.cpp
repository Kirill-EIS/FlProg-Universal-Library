 #include "RT_HW_BASE.h"

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//		Инициализация шины;
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void RT_HW_BASE:: oneWireBegin(RT_HW_STRUCT_ONE_WIRE &id, uint8_t pin){
id.dir=0; id.step=0;
if(id.custom==0){
	if(!checkPinPGM( RT_HW_PGM_PIN_DIN_ID,pin)) {id.custom=90; return;}	//--Проверка пина на дискретный ввод;
	if(!checkPinPGM( RT_HW_PGM_PIN_DOT_ID,pin)) {id.custom=91; return;}	//--Проверка пина на дискретный вывод;	
	RT_HW_PIN_DIR_SET_ID(id.dd,pin); 													//--Настройка параметров пина;
	RT_HW_PIN_DIR_MODE_INPUT(id.dd);
	id.step=0; id.custom=1;}
};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//		Сброс шины. Выход id.state: =0 в работе;  =1 -на шине есть устройства; =2 устройства не обнаружены; =3 -обрыв шины; =4-шина не настроено;
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void RT_HW_BASE:: oneWireReset(RT_HW_STRUCT_ONE_WIRE &id){
if(id.step==0) {id.state=0; if(id.custom!=1) {id.state=4; return;} 													//--Проверка настройки шины; 
				noInterrupts(); RT_HW_PIN_DIR_MODE_INPUT(id.dd); interrupts(); id.timeDelay=micros(); id.step++;} 	//--Настройка шины на чтение;
if(id.step==1) {id.bus=RT_HW_PIN_DIR_READ(id.dd); if(id.bus){id.step++; return;}	
				if(getPastMcs(id.timeDelay)>300){id.state=3; id.step=0; return;}}	//--Ожидание на шине HIGH с тайм-аутом;
if(id.step==2) {noInterrupts(); RT_HW_PIN_DIR_WRITE_LOW(id.dd); RT_HW_PIN_DIR_MODE_OUTPUT(id.dd); 
				  interrupts(); id.timeDelay=micros(); id.step++;}													//--Установка на шине  LOW; 
if(id.step==3) {if(getPastMcs(id.timeDelay)>500)    {id.step++;} return;} 											//--Удержание на шине LOW;
if(id.step==4) {noInterrupts(); RT_HW_PIN_DIR_MODE_INPUT(id.dd); delayMicroseconds(70); id.bus=RT_HW_PIN_DIR_READ(id.dd); 
				  interrupts(); if(!id.bus){id.timeDelay=micros(); id.step++;} else{id.state=2; id.step=0; return;}}//--Проверка обнаружения устр-ва;				 
if(id.step==5) {if(getPastMcs(id.timeDelay)<420) {return;}  id.state=1; id.step=0; return;}							//--Задержка 420mcs для завершения операции сброса.
}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//		Очистка регистров и буферов;
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void RT_HW_BASE:: oneWireClear(RT_HW_STRUCT_ONE_WIRE &id) {
  id.LastDiscrepancy = 0; id.LastDeviceFlag = false; id.LastFamilyDiscrepancy = 0;
  for(uint8_t i=0; i<8; i++) {id.ROM_NO[i]=0;}}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//		Отключение питания от шины
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void RT_HW_BASE:: oneWireDepower(RT_HW_STRUCT_ONE_WIRE &id){
	noInterrupts(); RT_HW_PIN_DIR_MODE_INPUT(id.dd); interrupts();}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//		Запись бита
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void RT_HW_BASE:: oneWireWriteBit(RT_HW_STRUCT_ONE_WIRE &id, uint8_t v){
  if(v & 1) {noInterrupts(); RT_HW_PIN_DIR_WRITE_LOW(id.dd); RT_HW_PIN_DIR_MODE_OUTPUT(id.dd);	delayMicroseconds(10); 
						     RT_HW_PIN_DIR_WRITE_HIGH(id.dd);  interrupts();                    delayMicroseconds(55);} 
	   else {noInterrupts(); RT_HW_PIN_DIR_WRITE_LOW(id.dd); RT_HW_PIN_DIR_MODE_OUTPUT(id.dd);	delayMicroseconds(65);
		                     RT_HW_PIN_DIR_WRITE_HIGH(id.dd);  interrupts();                    delayMicroseconds(5);}
}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//		Запись байта
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void RT_HW_BASE:: oneWireWrite(RT_HW_STRUCT_ONE_WIRE &id, uint8_t v, uint8_t power) { 
uint8_t bitMask;
  for(bitMask=0x01; bitMask; bitMask <<= 1) {oneWireWriteBit(id,(bitMask & v)?1:0);}
  if (!power) {noInterrupts(); RT_HW_PIN_DIR_MODE_INPUT(id.dd); RT_HW_PIN_DIR_WRITE_LOW(id.dd);  interrupts();}}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//		Запись байтов
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void RT_HW_BASE:: oneWireWriteBytes(RT_HW_STRUCT_ONE_WIRE &id, const uint8_t *buf, uint16_t count, bool power) {
  for(uint16_t i=0 ; i<count; i++) {oneWireWrite(id,buf[i]);}
  if (!power) {noInterrupts();  RT_HW_PIN_DIR_MODE_INPUT(id.dd); RT_HW_PIN_DIR_WRITE_LOW(id.dd); interrupts();}}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//		Чтение бита
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
uint8_t RT_HW_BASE:: oneWireReadBit(RT_HW_STRUCT_ONE_WIRE &id){
  uint8_t v;
  noInterrupts(); RT_HW_PIN_DIR_MODE_OUTPUT(id.dd); RT_HW_PIN_DIR_WRITE_LOW(id.dd); delayMicroseconds(3);
	              RT_HW_PIN_DIR_MODE_INPUT(id.dd);	                          		delayMicroseconds(10);
				  v = RT_HW_PIN_DIR_READ(id.dd);   interrupts();                    delayMicroseconds(53);
return v;}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//		Чтение байта
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
uint8_t RT_HW_BASE:: oneWireRead(RT_HW_STRUCT_ONE_WIRE &id) {
 uint8_t bitMask; uint8_t v=0;
  for (bitMask=0x01; bitMask; bitMask <<= 1) {if(oneWireReadBit(id)) {v |= bitMask;}}
  return v;}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//		Чтение байтов
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void   RT_HW_BASE:: oneWireReadBytes(RT_HW_STRUCT_ONE_WIRE &id, uint8_t *buf, uint16_t count) {
  for (uint16_t i=0 ; i<count ; i++) {buf[i]=oneWireRead(id);}}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//		Выбор по  адресу
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void 	RT_HW_BASE:: oneWireSelect(RT_HW_STRUCT_ONE_WIRE &id, const uint8_t rom[8]){
  oneWireWrite(id,0x55);           //--Запись адреса
  for (uint8_t i = 0; i < 8; i++) {oneWireWrite(id, rom[i]);} }
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//		Пропуск адреса
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void 	RT_HW_BASE:: oneWireSkip(RT_HW_STRUCT_ONE_WIRE &id){ 
	oneWireWrite(id,0xCC);}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//		Подготовка для поиска устройств одного семейства
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void 	RT_HW_BASE:: oneWireTargetSearch(RT_HW_STRUCT_ONE_WIRE &id, uint8_t family_code) {
	id.ROM_NO[0] = family_code;	for (uint8_t i=1; i<8; i++) {id.ROM_NO[i]=0;}
	id.LastDiscrepancy=64; id.LastFamilyDiscrepancy=0; id.LastDeviceFlag=false;}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//		Поиск устройств по номеру 
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
bool 	RT_HW_BASE:: oneWireSearch(RT_HW_STRUCT_ONE_WIRE &id, uint8_t *newAddr, bool search_mode){
 bool  search_result=0;
/*
 uint8_t id_bit_number; uint8_t last_zero, rom_byte_number; 
  uint8_t id_bit, cmp_id_bit;  unsigned char rom_byte_mask, search_direction;
   id_bit_number = 1; last_zero = 0; rom_byte_number = 0;  rom_byte_mask = 1; search_result = false;
  if (!id.LastDeviceFlag) {
      oneWireReset(id);
	  
	  
	  if(id.state==1) {id.LastDiscrepancy = 0; id.LastDeviceFlag = false; id.LastFamilyDiscrepancy = 0; return false;}
      if (search_mode == true) {oneWireWrite(id,0xF0);} 
	                      else {oneWireWrite(id,0xEC);}
//-----------------------------------------------------------------------------					  
      do {id_bit = oneWireReadBit(id); cmp_id_bit = oneWireReadBit(id);
          if ((id_bit == 1) && (cmp_id_bit == 1)) {break;} 
		  else { if (id_bit != cmp_id_bit) { search_direction = id_bit; } 
		                              else { if (id_bit_number < id.LastDiscrepancy) {search_direction = ((id.ROM_NO[rom_byte_number] & rom_byte_mask) > 0);} 
		                                                                     else {search_direction = (id_bit_number == id.LastDiscrepancy);}
                                                                                    if (search_direction == 0) {last_zero = id_bit_number;
                                                                                    if (last_zero < 9) {id.LastFamilyDiscrepancy = last_zero;}}}
            if (search_direction == 1) {id.ROM_NO[rom_byte_number] |= rom_byte_mask;} else {id.ROM_NO[rom_byte_number] &= ~rom_byte_mask;}
            oneWireWriteBit(id,search_direction);
            id_bit_number++;
            rom_byte_mask <<= 1;
            if (rom_byte_mask == 0) {rom_byte_number++; rom_byte_mask = 1;}
         }
        }while(rom_byte_number < 8); 
//-----------------------------------------------------------------------------
      if (!(id_bit_number < 65)) {id.LastDiscrepancy = last_zero; if (id.LastDiscrepancy == 0) {id.LastDeviceFlag = true;} search_result = true;}
//-----------------------------------------------------------------------------	  
   }
//-----------------------------------------------------------------------------
  if (!search_result || !id.ROM_NO[0]) { id.LastDiscrepancy = 0; id.LastDeviceFlag = false; id.LastFamilyDiscrepancy = 0; search_result = false;} 
                               else { for (int i = 0; i < 8; i++) newAddr[i] = id.ROM_NO[i];}
//-----------------------------------------------------------------------------							   
*/
return search_result;}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

