//*************************************************************************************************
//							1.Контроллер типа Generic ESP8266 Module [generic.variani]
//*************************************************************************************************
#if !defined(RT_HW_BOARD_SELECT) && defined(RT_HW_BOARD_ESP8266_GENERIC) 					
#define      RT_HW_BOARD_SELECT 	             "BOARD ESP8266 GENERIC"	//--Идентификатор выбора платы;
//-------------------------------------------------------------------------------------------------
#define RT_HW_BOARD_MEMORY	 "FLASH=FS:(max)2Mb,OTA:(max)1019Kb; RAM=80Kb"	//--Параметры памяти;
#define RT_HW_PERMIT_UART0													//--Разрешение работы с UART0; 
#define RT_HW_PERMIT_UARTS													//--Разрешение работы с SoftSerial UART;
#define RT_HW_PERMIT_I2C0													//--Разрешение работы с i2c0; 
#define RT_HW_PERMIT_SPI0													//--Разрешение работы с spi0; 
//------Системные пины------------------------------------------------------------------------------
enum   {RT_HW_BOARD_CONTROL=D0, RT_HW_BOARD_LED=D4, RT_HW_BOARD_BUTTON=D3};//--Пины контроль,led,кнопка;
//-----Параметры контроллера общие-----------------------------------------------------------------	
enum   {RT_HW_PIN_QNT_MAX=18,	RT_HW_FCPU=80, RT_HW_VCC=3300};
//-----Параметры UART------------------------------------------------------------------------------	
enum   {RT_HW_UART0_RX=RX,  RT_HW_UART0_TX=TX,
							RT_HW_UART1_TX=TX1};
enum   {RT_HW_UARTS_RX=RX2, RT_HW_UARTS_TX=TX2};		
//-----Параметры I2C------------------------------------------------------------------------------	
enum   {RT_HW_I2C0_SDA=SDA,  RT_HW_I2C0_SCL=SCL};   
//-----Параметры SPI------------------------------------------------------------------------------	
enum   {RT_HW_SPI0_SCK=D5, RT_HW_SPI0_MISO=D6, RT_HW_SPI0_MOSI=D7};
//-----Системные параметры-------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_SYS_PAR[]	={12,			RT_HW_PGM_END};  	//--SYS->depth;
const uint8_t PROGMEM RT_HW_PGM_SYS_PIN[]	={RT_HW_BOARD_CONTROL, RT_HW_BOARD_LED, RT_HW_BOARD_BUTTON, RT_HW_PGM_END}; //--Пины->control,led,button;
const uint8_t PROGMEM RT_HW_PGM_SYS_ADC[]	={10,3,4, 		RT_HW_PGM_END};  	//--ADC->depth,drift,null;
const uint8_t PROGMEM RT_HW_PGM_SYS_TCH[] 	={          	RT_HW_PGM_END};  	//--TCH->depth,drift,null; 
const uint8_t PROGMEM RT_HW_PGM_SYS_PWM[] 	={10,10,      	RT_HW_PGM_END};  	//--PWM->depth,freq; 
const uint8_t PROGMEM RT_HW_PGM_SYS_DAC[] 	={         		RT_HW_PGM_END};  	//--DAC->depth; 
//-----Системные пины и параметры коммуникаций------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_I2C[]	={RT_HW_I2C0_SDA, RT_HW_I2C0_SCL,		RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_SPI[]	={RT_HW_SPI0_SCK, RT_HW_SPI0_MISO, RT_HW_SPI0_MOSI,	RT_HW_PGM_END}; 
const uint8_t PROGMEM RT_HW_PGM_PIN_UHS[]	={RT_HW_UART0_RX, RT_HW_UART0_TX, 
													     255, RT_HW_UART1_TX,	RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_USS[]	={RT_HW_UARTS_RX, RT_HW_UARTS_TX,		RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_CAN[]	={										RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_BTH[]	={										RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_ETH[]	={										RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_WFI[]	={192,									RT_HW_PGM_END};	
//-----Доступные пины контроллера------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_ALL[]	={D0, D1,D2,D3,D4,D5,D6,D7,D8,D9,D10,A0,RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DIN[]	={255,D1,D2,D3,D4,D5,D6,D7,D8,D9,D10,	RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_ADC[]	={A0,									RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_TCH[]	={										RT_HW_PGM_END};									
const uint8_t PROGMEM RT_HW_PGM_PIN_DOT[]	={D0, D1,D2,D3,D4,D5,D6,D7,D8,			RT_HW_PGM_END}; 
const uint8_t PROGMEM RT_HW_PGM_PIN_PWM[]	={255,D1,D2,D3,D4,D5,D6,D7,D8,			RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DAC[]	={										RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_INT[]	={255,D1,D2,D3,D4,D5,D6,D7,D8,			RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_N5V[]	={D0, D1,D2,D3,D4,D5,D6,D7,D8,D9,D10,A0,RT_HW_PGM_END};	
//-----Тестовые пины и адреса------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_DBG[] 	={	    		RT_HW_PGM_END};		//--debug1,debug2,debug3;	
const uint8_t PROGMEM RT_HW_PGM_PIN_OUT[]	={D8,     		RT_HW_PGM_END};		//--PWM0, PWM1,led,dev;
const uint8_t PROGMEM RT_HW_PGM_PIN_INP[]	={A0,255,D5,    RT_HW_PGM_END};		//--A0,   A1, btn1,btn2;
const uint8_t PROGMEM RT_HW_PGM_PIN_DCT[]	={          	RT_HW_PGM_END};		//--DAC0,DAC1,TCH0;
const uint8_t PROGMEM RT_HW_PGM_PIN_DEV[]	={D5,D6,D7,		RT_HW_PGM_END};		//--DS1820,DHT22,HC-SR04
const uint8_t PROGMEM RT_HW_PGM_PIN_CSS[]	={D4,			RT_HW_PGM_END};		//--CS SPI:595,LCD,NRF,DEVl 
const uint8_t PROGMEM RT_HW_PGM_PIN_LC6[] 	={				RT_HW_PGM_END};		//--Пины для подключения LCD по 4-х битной шине;
const uint8_t PROGMEM RT_HW_PGM_PIN_TFT[] 	={				RT_HW_PGM_END};		//--Пины TFT дисплея;
const uint8_t PROGMEM RT_HW_PGM_PIN_SSP[] 	={				RT_HW_PGM_END};		//--Пины программного SPI;		
const uint8_t PROGMEM RT_HW_PGM_ADR_I2C[] 	={39,62,32,33,	RT_HW_PGM_END};		//--lcd1,lcd2,mcp1,mcp2;
//-------------------------------------------------------------------------------------------------
#endif
//*************************************************************************************************
//							2.Контроллеры типа LOLIN(WEMOS) D1 mini Lite, LOLIN(WEMOS) D1 mini Lite [d1_mini.variant]
//*************************************************************************************************
#if !defined(RT_HW_BOARD_SELECT) && (defined(RT_HW_BOARD_ESP8266_WEMOS_D1MINILITE) || defined(RT_HW_BOARD_ESP8266_WEMOS_D1MINIPRO))								
#define      RT_HW_BOARD_SELECT                   "BOARD ESP8266_WEMOS_D1 MINI"	//--Идентификатор выбора платы;
//-------------------------------------------------------------------------------------------------
#define RT_HW_BOARD_MEMORY	 "FLASH=FS:(max)2Mb,OTA:(max)1019Kb; RAM=80Kb"	//--Параметры памяти;
#define RT_HW_PERMIT_UART0													//--Разрешение работы с UART0; 
#define RT_HW_PERMIT_UARTS													//--Разрешение работы с SoftSerial UART;
#define RT_HW_PERMIT_I2C0													//--Разрешение работы с i2c0; 
#define RT_HW_PERMIT_SPI0													//--Разрешение работы с spi0; 
//------Системные пины------------------------------------------------------------------------------
enum    {RT_HW_BOARD_CONTROL=D0, RT_HW_BOARD_LED=D4, RT_HW_BOARD_BUTTON=D3};//--Пины контроль,led,кнопка;
//-----Параметры контроллера общие-----------------------------------------------------------------	
enum{RT_HW_PIN_QNT_MAX=18,	RT_HW_FCPU=80, RT_HW_VCC=3300};
//-----Параметры UART------------------------------------------------------------------------------	
enum   {RT_HW_UART0_RX=RX,  RT_HW_UART0_TX=TX,
							RT_HW_UART1_TX=TX1};
enum   {RT_HW_UARTS_RX=RX2, RT_HW_UARTS_TX=TX2};		
//-----Параметры I2C------------------------------------------------------------------------------	
enum   {RT_HW_I2C0_SDA=SDA,  RT_HW_I2C0_SCL=SCL};  
//-----Параметры SPI------------------------------------------------------------------------------	
enum   {RT_HW_SPI0_SCK=D5, RT_HW_SPI0_MISO=D6, RT_HW_SPI0_MOSI=D7};
//-----Системные параметры-------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_SYS_PAR[] 	={12,			RT_HW_PGM_END};  //--SYS->depth;
const uint8_t PROGMEM RT_HW_PGM_SYS_PIN[] 	={RT_HW_BOARD_CONTROL, RT_HW_BOARD_LED, RT_HW_BOARD_BUTTON, RT_HW_PGM_END}; //--Пины->control,led,button;
const uint8_t PROGMEM RT_HW_PGM_SYS_ADC[] 	={10,3,4, 		RT_HW_PGM_END};  //--ADC->depth,drift,null;
const uint8_t PROGMEM RT_HW_PGM_SYS_TCH[]	={         		RT_HW_PGM_END};  //--TCH->depth,drift,null; 
const uint8_t PROGMEM RT_HW_PGM_SYS_PWM[] 	={10,10,       	RT_HW_PGM_END};  //--PWM->depth,freq; 
const uint8_t PROGMEM RT_HW_PGM_SYS_DAC[] 	={          	RT_HW_PGM_END};  //--DAC->depth; 
//-----Системные пины и параметры коммуникаций------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_I2C[]	={RT_HW_I2C0_SDA, RT_HW_I2C0_SCL,		RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_SPI[]	={RT_HW_SPI0_SCK, RT_HW_SPI0_MISO, RT_HW_SPI0_MOSI,	RT_HW_PGM_END}; 
const uint8_t PROGMEM RT_HW_PGM_PIN_UHS[]	={RT_HW_UART0_RX, RT_HW_UART0_TX,  
														 255, RT_HW_UART1_TX,		RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_USS[]	={RT_HW_UARTS_RX, RT_HW_UARTS_TX,		RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_CAN[]	={										RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_BTH[]	={										RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_ETH[]	={										RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_WFI[]	={192,									RT_HW_PGM_END};	
//-----Доступные пины контроллера------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_ALL[]	={D0, D1,D2,D3,D4,D5,D6,D7,D8,D9,D10,A0,RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DIN[]	={255,D1,D2,D3,D4,D5,D6,D7,D8,D9,D10,	RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_ADC[]	={A0,									RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_TCH[]	={										RT_HW_PGM_END};									
const uint8_t PROGMEM RT_HW_PGM_PIN_DOT[]	={D0, D1,D2,D3,D4,D5,D6,D7,D8,			RT_HW_PGM_END}; 
const uint8_t PROGMEM RT_HW_PGM_PIN_PWM[]	={255,D1,D2,D3,D4,D5,D6,D7,D8,			RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DAC[]	={										RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_INT[]	={255,D1,D2,D3,D4,D5,D6,D7,D8,			RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_N5V[]	={D0, D1,D2,D3,D4,D5,D6,D7,D8,D9,D10,A0,RT_HW_PGM_END};	
//-----Тестовые пины и адреса------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_DBG[] 	={	    		RT_HW_PGM_END};	// debug1,debug2,debug3;	
const uint8_t PROGMEM RT_HW_PGM_PIN_OUT[]	={D8,     		RT_HW_PGM_END};	// PWM0, PWM1,led,dev;
const uint8_t PROGMEM RT_HW_PGM_PIN_INP[]	={A0,255,D5,    RT_HW_PGM_END};	// A0,   A1, btn1,btn2;
const uint8_t PROGMEM RT_HW_PGM_PIN_DCT[]	={          	RT_HW_PGM_END};	// DAC0,DAC1,TCH0;
const uint8_t PROGMEM RT_HW_PGM_PIN_DEV[]	={D5,D6,D7,		RT_HW_PGM_END};	// DS1820,DHT22,HC-SR04
const uint8_t PROGMEM RT_HW_PGM_PIN_CSS[]	={D4,			RT_HW_PGM_END};	// CS SPI:595,LCD,NRF,DEVl 
const uint8_t PROGMEM RT_HW_PGM_PIN_LC6[] 	={				RT_HW_PGM_END};	// Пины для подключения LCD по 4-х битной шине;
const uint8_t PROGMEM RT_HW_PGM_PIN_TFT[] 	={				RT_HW_PGM_END};	// Пины(дополнительные[] TFT дисплея(SPI[];
const uint8_t PROGMEM RT_HW_PGM_PIN_SSP[] 	={				RT_HW_PGM_END};	// Пины программного SPI;		
const uint8_t PROGMEM RT_HW_PGM_ADR_I2C[] 	={39,62,32,33,	RT_HW_PGM_END};	// lcd1,lcd2,mcp1,mcp2;
//-------------------------------------------------------------------------------------------------
#endif
//*************************************************************************************************
//							3.Контроллеры типа NodeMCU 0.9 (ESP12), NodeMCU 1.0 (ESP12E) [nodemcu.variant]
//*************************************************************************************************
#if !defined(RT_HW_BOARD_SELECT) && (defined(RT_HW_BOARD_ESP8266_NODEMCU_ESP12) || defined(RT_HW_BOARD_ESP8266_NODEMCU_ESP12E))								
#define      RT_HW_BOARD_SELECT 	              "BOARD_ESP8266 NODEMCU ESP12"	//--Идентификатор выбора платы;
//-------------------------------------------------------------------------------------------------
#define RT_HW_BOARD_MEMORY	 "FLASH=FS:(max)2Mb,OTA:(max)1019Kb; RAM=80Kb"	//--Параметры памяти;
#define RT_HW_PERMIT_UART0													//--Разрешение работы с UART0; 
#define RT_HW_PERMIT_UARTS													//--Разрешение работы с SoftSerial UART;
#define RT_HW_PERMIT_I2C0													//--Разрешение работы с i2c0; 
#define RT_HW_PERMIT_SPI0													//--Разрешение работы с spi0; 
//=================================================================================================
//------Системные пины------------------------------------------------------------------------------
enum    {RT_HW_BOARD_CONTROL=D0, RT_HW_BOARD_LED=D4, RT_HW_BOARD_BUTTON=D3};//--Пины контроль,led,кнопка;
//-----Параметры контроллера общие-----------------------------------------------------------------	
enum{RT_HW_PIN_QNT_MAX=18,	RT_HW_FCPU=80, RT_HW_VCC=3300};
//-----Параметры UART------------------------------------------------------------------------------	
enum   {RT_HW_UART0_RX=RX,  RT_HW_UART0_TX=TX, 
							RT_HW_UART1_TX=TX1};
enum   {RT_HW_UARTS_RX=RX2, RT_HW_UARTS_TX=TX2};		
//-----Параметры I2C------------------------------------------------------------------------------	
enum   {RT_HW_I2C0_SDA=SDA,  RT_HW_I2C0_SCL=SCL};   
//-----Параметры SPI------------------------------------------------------------------------------	
enum   {RT_HW_SPI0_SCK=D5, RT_HW_SPI0_MISO=D6, RT_HW_SPI0_MOSI=D7};
//-----Системные параметры-------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_SYS_PAR[] 	={12,			RT_HW_PGM_END};  //--SYS->depth;
const uint8_t PROGMEM RT_HW_PGM_SYS_PIN[] 	={RT_HW_BOARD_CONTROL, RT_HW_BOARD_LED, RT_HW_BOARD_BUTTON, RT_HW_PGM_END}; //--Пины->control,led,button;
const uint8_t PROGMEM RT_HW_PGM_SYS_ADC[] 	={10,3,4, 		RT_HW_PGM_END};  //--ADC->depth,drift,null;
const uint8_t PROGMEM RT_HW_PGM_SYS_TCH[] 	={          	RT_HW_PGM_END};  //--TCH->depth,drift,null; 
const uint8_t PROGMEM RT_HW_PGM_SYS_PWM[] 	={10,10,        RT_HW_PGM_END};  //--PWM->depth,freq; 
const uint8_t PROGMEM RT_HW_PGM_SYS_DAC[] 	={          	RT_HW_PGM_END};  //--DAC->depth; 
//-----Системные пины и параметры коммуникаций------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_I2C[]	={RT_HW_I2C0_SDA, RT_HW_I2C0_SCL,		RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_SPI[]	={RT_HW_SPI0_SCK, RT_HW_SPI0_MISO, RT_HW_SPI0_MOSI,	RT_HW_PGM_END}; 
const uint8_t PROGMEM RT_HW_PGM_PIN_UHS[]	={RT_HW_UART0_RX, RT_HW_UART0_TX,  
														 255, RT_HW_UART1_TX,	RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_USS[]	={RT_HW_UARTS_RX, RT_HW_UARTS_TX,		RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_CAN[]	={										RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_BTH[]	={										RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_ETH[]	={										RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_WFI[]	={192,									RT_HW_PGM_END};	
//-----Доступные пины контроллера------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_ALL[]	={D0, D1,D2,D3,D4,D5,D6,D7,D8,D9,D10,A0,RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DIN[]	={255,D1,D2,D3,D4,D5,D6,D7,D8,D9,D10,	RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_ADC[]	={A0,									RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_TCH[]	={										RT_HW_PGM_END};									
const uint8_t PROGMEM RT_HW_PGM_PIN_DOT[]	={D0, D1,D2,D3,D4,D5,D6,D7,D8,			RT_HW_PGM_END}; 
const uint8_t PROGMEM RT_HW_PGM_PIN_PWM[]	={255,D1,D2,D3,D4,D5,D6,D7,D8,			RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DAC[]	={										RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_INT[]	={255,D1,D2,D3,D4,D5,D6,D7,D8,			RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_N5V[]	={D0, D1,D2,D3,D4,D5,D6,D7,D8,D9,D10,A0,RT_HW_PGM_END};	
//-----Тестовые пины и адреса------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_DBG[] 	={	    		RT_HW_PGM_END};	// debug1,debug2,debug3;	
const uint8_t PROGMEM RT_HW_PGM_PIN_OUT[]	={D8,     		RT_HW_PGM_END};	// PWM0, PWM1,led,dev;
const uint8_t PROGMEM RT_HW_PGM_PIN_INP[]	={A0,255,D5,    RT_HW_PGM_END};	// A0,   A1, btn1,btn2;
const uint8_t PROGMEM RT_HW_PGM_PIN_DCT[]	={          	RT_HW_PGM_END};	// DAC0,DAC1,TCH0;
const uint8_t PROGMEM RT_HW_PGM_PIN_DEV[]	={D5,D6,D7,		RT_HW_PGM_END};	// DS1820,DHT22,HC-SR04
const uint8_t PROGMEM RT_HW_PGM_PIN_CSS[]	={D4,			RT_HW_PGM_END};	// CS SPI:595,LCD,NRF,DEVl 
const uint8_t PROGMEM RT_HW_PGM_PIN_LC6[]	={				RT_HW_PGM_END};	// Пины для подключения LCD по 4-х битной шине;
const uint8_t PROGMEM RT_HW_PGM_PIN_TFT[] 	={				RT_HW_PGM_END};	// Пины TFT дисплея;
const uint8_t PROGMEM RT_HW_PGM_PIN_SSP[] 	={				RT_HW_PGM_END};	// Пины программного SPI;		
const uint8_t PROGMEM RT_HW_PGM_ADR_I2C[] 	={39,62,32,33,	RT_HW_PGM_END};	// lcd1,lcd2,mcp1,mcp2;
//-------------------------------------------------------------------------------------------------
#endif