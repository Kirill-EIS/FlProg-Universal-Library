//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//						     Контроллер ANON (не опознанный контроллер)
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#if !defined(RT_HW_BOARD_SELECT) 									
#define RT_HW_BOARD_SELECT   "BOARD_ANON"   
#define RT_HW_BLOCK_AVAILABLE_FOR_WRITE
//=================================================================================================
#define RT_HW_BOARD_MEMORY	 "FLASH=xxKb, RAM=xxKb, EEPROM=xxKb"			//--Параметры памяти;
//-------------------------------------------------------------------------------------------------	
#define RT_HW_PERMIT_UART0													//--Разрешение работы с UART0; 
//=================================================================================================	 									
//------Системные пины-----------------------------------------------------------------------------
enum   {RT_HW_BOARD_CONTROL=255, RT_HW_BOARD_LED=255, RT_HW_BOARD_BUTTON=255};	//--Пины контроль,led,кнопка;
//------Параметры контроллера общие----------------------------------------------------------------	
enum{RT_HW_PIN_QNT_MAX=2,	RT_HW_FCPU=16, 		RT_HW_VCC=5000};
enum{RT_HW_MEM_ROM=32,  	RT_HW_MEM_RAM=2, 	RT_HW_MEM_EEPROM=0, RT_HW_MEM_RTC=0, RT_HW_MEM_EXT_RAM=0};
//------Параметры i2c------------------------------------------------------------------------------	
//---ОПРЕДЕЛЕНИЕ МАССИВОВ--------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_SYS_PAR[] 	={12,  RT_HW_PGM_END};  //--SYS->depth;
const uint8_t PROGMEM RT_HW_PGM_SYS_PIN[] 	={RT_HW_BOARD_CONTROL, RT_HW_BOARD_LED, RT_HW_BOARD_BUTTON,RT_HW_PGM_END};  //--Пины->control,led; 
const uint8_t PROGMEM RT_HW_PGM_SYS_ADC[] 	={10,0,0,	RT_HW_PGM_END};  //--ADC->depth,drift,null;
const uint8_t PROGMEM RT_HW_PGM_SYS_TCH[] 	={			RT_HW_PGM_END};  //--TCH->depth,drift,null; 
const uint8_t PROGMEM RT_HW_PGM_SYS_PWM[]	={			RT_HW_PGM_END};  //--PWM->depth,freq; 
const uint8_t PROGMEM RT_HW_PGM_SYS_DAC[] 	={			RT_HW_PGM_END};  //--DAC->depth; 
//-----------------------------------------------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_I2C[] 	={		RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_SPI[] 	={		RT_HW_PGM_END}; 
const uint8_t PROGMEM RT_HW_PGM_PIN_UHS[] 	={		RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_USS[] 	={		RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_CAN[] 	={		RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_BTH[] 	={		RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_ETH[] 	={ 		RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_WFI[] 	={		RT_HW_PGM_END};
//------------------------------------------------------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_ALL[] 	={		RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DIN[] 	={		RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_ADC[] 	={		RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_TCH[] 	={		RT_HW_PGM_END};									
const uint8_t PROGMEM RT_HW_PGM_PIN_DOT[] 	={		RT_HW_PGM_END}; 
const uint8_t PROGMEM RT_HW_PGM_PIN_PWM[] 	={		RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_DAC[] 	={		RT_HW_PGM_END};
const uint8_t PROGMEM RT_HW_PGM_PIN_INT[] 	={		RT_HW_PGM_END};	
const uint8_t PROGMEM RT_HW_PGM_PIN_N5V[] 	={		RT_HW_PGM_END};	
//------------------------------------------------------------------------------------------------------------------------
const uint8_t PROGMEM RT_HW_PGM_PIN_DBG[] 	={		RT_HW_PGM_END};	// debug1,debug2,debug3;	
const uint8_t PROGMEM RT_HW_PGM_PIN_OUT[] 	={		RT_HW_PGM_END};	// PWM0, PWM1, led, dev;							                  
const uint8_t PROGMEM RT_HW_PGM_PIN_INP[] 	={		RT_HW_PGM_END};	// A0,   A1, btn1,btn2;
const uint8_t PROGMEM RT_HW_PGM_PIN_DCT[] 	={		RT_HW_PGM_END};	// DAC0,DAC1,TCH0;
const uint8_t PROGMEM RT_HW_PGM_PIN_DEV[] 	={		RT_HW_PGM_END};	// DS1820,DHT22,HC-SR04;
const uint8_t PROGMEM RT_HW_PGM_PIN_CSS[] 	={		RT_HW_PGM_END};	// CS SPI:595,LCD,NRF,DEVl;
const uint8_t PROGMEM RT_HW_PGM_PIN_LC6[] 	={		RT_HW_PGM_END};	// Пины для подключения LCD по 4-х битной шине;
const uint8_t PROGMEM RT_HW_PGM_PIN_TFT[] 	={  	RT_HW_PGM_END};	// Пины(дополнительные[]  TFT дисплея(SPI[] -CS,R/S,LED,RST,TOUCH;
const uint8_t PROGMEM RT_HW_PGM_PIN_SSP[] 	={		RT_HW_PGM_END};	// Пины программного SPI; 	
const uint8_t PROGMEM RT_HW_PGM_ADR_I2C[] 	={		RT_HW_PGM_END};	// lcd1,lcd2;												   
//-------------------------------------------------------------------------------------------------
#endif
//=================================================================================================

