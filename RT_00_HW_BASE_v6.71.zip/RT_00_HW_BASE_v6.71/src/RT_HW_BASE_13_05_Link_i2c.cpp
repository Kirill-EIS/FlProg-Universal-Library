 #include "RT_HW_BASE.h"
//=================================================================================================
// AVR  	- одна шина i2c(Wire),  объединенная библиотека master/slave;
// ESP8266  - одна шина i2c(Wire),  объединенная библиотека master/slave;
// ESP32    - две  шины i2c master(Wire1,Wire2), библиотека master - Wire.h, 
//            при использовании библиотеки slave - ESP32_I2C_Slave (требуется загрузка)
//            две шины i2с slave(WireSlave1, WireSlave2.
//            *** одновременно можно использовать только две шины в разном сочетании master/slave; 
// SAM3     - одна шина i2c(Wire),  объединенная библиотека master/slave;
// Seeeduino- до 6 шин  i2c(Wire,Wire1-5), объединенная библиотека master/slave;
// STM32    - до 3 шин  i2c(Wire определена, 
//                          Wire1 нужно определять TwoWire Wire1(RT_HW_I2C1_SDA,  RT_HW_I2C1_SCL),
//                          Wire2 нужно определять TwoWire Wire2(RT_HW_I2C2_SDA,  RT_HW_I2C2_SCL);
//			  для STM32duino     - объединенная библиотека master/slave;
//			  для STM32master_F1 - библиотека master - Wire.h, библиотека slave - Wire_slave.h (в core STM32master), 
//			  для STM32master_F4 - библиотека master - Wire.h, библиотека slave - отсутствует;
//	номера битов device.i2cx.state:RT_HW_I2C_STATE_INIT,RT_HW_I2C_STATE_MASTER,RT_HW_I2C_STATE_SLAVE,RT_HW_I2C_STATE_BUSY;					 
//------------------------------------------------------------------------------------------------- 
// Функция i2cFindDevice() Осуществляет поиск устройства по его адресу на шине i2c.
//  Поиск принимается успешным при многократном (подряд) обнаружении устройства с периодом 50мс. 
//  Вход: addr-адрес устройств; bus -номер щины i2c;
//  	  id.custom - состояние функции. Перед вызовом функции установить =0;
//		  id.maxOk  - кол-во успешных повторов, после которого устройство считается обнаруженным (1-15) (default=3); 
//		  id.maxErr - максимальное количество ошибок (1-255) (default).
//                    При ошибках оределяет период повторного поиска (=100*id.cntErr); 	
//  Если устройство с заданным адресом не найдено, то период поиска увеличается от 100мс до (100 х cntMax).
//	Если устройство найдено, то делаются дополнительные запросы через 50мс (всего должно быть успешных подряд поисков >id.maxOk);
//  Выход: id.custom;
//struct RT_HW_STRUCT_I2C_FIND{uint8_t custom=0; uint8_t maxErr=20; uint8_t maxOk=3; uint8_t cntErr:5, cntOk:3; uint32_t timeDelay;};
//=================================================================================================
//---------------------------1.ОПРЕДЕЛЕНИЕ ДОПОЛНИТЕЛЬНЫХ ШИН------------------------------------------------
#if defined(RT_HW_PERMIT_I2C1) && (defined(RT_HW_CORE_M_STM32F1) || defined(RT_HW_CORE_M_STM32F4) || defined(RT_HW_CORE_D_STM32))	
  TwoWire Wire1(RT_HW_I2C1_SDA,  RT_HW_I2C1_SCL);
#endif
#if defined(RT_HW_PERMIT_I2C2) && (defined(RT_HW_IDE_SOFT_STM32master_F1) || defined(RT_HW_IDE_SOFT_STM32master_F4) || defined(RT_HW_IDE_SOFT_STM32duino))	
  TwoWire Wire2(RT_HW_I2C2_SDA, RT_HW_I2C2_SСL);
#endif
//---------------------------2.ФУНКЦИИ ПРОВЕРКА И УСТАНОВКА СОСТОЯНИЯ ШИН I2C--------------------------------
bool     RT_HW_BASE:: i2cCheckBusNum(uint8_t bus){							//==Проверка доступности шины;
#if defined(RT_HW_PERMIT_I2C0)	
if(bus==0) {return 1;}
#endif
#if defined(RT_HW_PERMIT_I2C1)	
if(bus==1) {return 1;}
#endif
#if defined(RT_HW_PERMIT_I2C2)	
if(bus==2) {return 1;}
#endif	
return 0;};	//++END i2cCheckBusNum()
bool     RT_HW_BASE:: i2cCheckBusState(uint8_t numBitState, uint8_t bus){	//==Проверка бита состояния шины;
#if defined(RT_HW_PERMIT_I2C0)	
if(bus==0) {return bitRead(device.i2c0.state,numBitState);}
#endif
#if defined(RT_HW_PERMIT_I2C1)	
if(bus==1) {return bitRead(device.i2c1.state,numBitState);}
#endif
#if defined(RT_HW_PERMIT_I2C2)	
if(bus==2) {return bitRead(device.i2c2.state,numBitState);}
#endif
return 0;};	//++END i2cCheckBusState()
void     RT_HW_BASE:: i2cSetBusState  (uint8_t numBitState, uint8_t bus){	//==Установка бита состояния шины;
#if defined(RT_HW_PERMIT_I2C0)	
if(bus==0) {bitSet(device.i2c0.state,numBitState);}
#endif
#if defined(RT_HW_PERMIT_I2C1)	
if(bus==1) {bitSet(device.i2c1.state,numBitState);}
#endif
#if defined(RT_HW_PERMIT_I2C2)	
if(bus==2) {bitSet(device.i2c2.state,numBitState);}
#endif
};			//++END i2cCheckBusSet()
void     RT_HW_BASE:: i2cClearBusState(uint8_t numBitState, uint8_t bus){	//==Сброс бита состояния шины;
#if defined(RT_HW_PERMIT_I2C0)	
if(bus==0) {bitClear(device.i2c0.state,numBitState);}
#endif
#if defined(RT_HW_PERMIT_I2C1)	
if(bus==1) {bitClear(device.i2c1.state,numBitState);}
#endif
#if defined(RT_HW_PERMIT_I2C2)	
if(bus==2) {bitClear(device.i2c2.state,numBitState);}
#endif
};			//++END i2cCheckBusClear()
uint8_t  RT_HW_BASE:: i2cGetBusState  (uint8_t bus){							//==Возращает регистр состояния шины;
#if defined(RT_HW_PERMIT_I2C0)	
if(bus==0) {return device.i2c0.state;}
#endif
#if defined(RT_HW_PERMIT_I2C1)	
if(bus==1) {return device.i2c1.state;}
#endif
#if defined(RT_HW_PERMIT_I2C2)	
if(bus==2) {return device.i2c2.state;}
#endif
return 0;};	//++END i2cGetBusState()
//===============================================================================================================
void     RT_HW_BASE:: i2cSetParamFreq(uint16_t freq, uint8_t bus){			//==Запись в регистр частоты(кГц) шины i2c;
#if defined(RT_HW_PERMIT_I2C0)	
if(bus==0) {if(freq>=10) {device.i2c0.speed=freq*1000L;}}
#endif
#if defined(RT_HW_PERMIT_I2C1)	
if(bus==1) {if(freq>=10) {device.i2c1.speed=freq*1000L;}}
#endif
#if defined(RT_HW_PERMIT_I2C2)	
if(bus==2) {if(freq>=10) {device.i2c2.speed=freq*1000L;}}
#endif
};			//++END i2cSetParamFreq()
uint16_t RT_HW_BASE:: i2cGetParamFreq(uint8_t bus){							//==Читает из регистра частоты(кГц) шины i2c;
#if defined(RT_HW_PERMIT_I2C0)	
if(bus==0) {return device.i2c0.speed/1000L;}
#endif
#if defined(RT_HW_PERMIT_I2C1)	
if(bus==1) {return device.i2c1.speed/1000L;}
#endif
#if defined(RT_HW_PERMIT_I2C2)	
if(bus==2) {return device.i2c2.speed/1000L;}
#endif
return 0;};	//++END i2cGetParamFreq()
void     RT_HW_BASE:: i2cSetPin(uint8_t sda, uint8_t scl, uint8_t bus){		//==Запись в регистры номера пинов шины i2c;
#if defined(RT_HW_PERMIT_I2C0)	
if(bus==0) {if((sda<254) && (scl<254) && (sda!=scl)){device.i2c0.sda=sda; device.i2c0.scl=scl;}}
#endif
#if defined(RT_HW_PERMIT_I2C1)	
if(bus==1) {if((sda<254) && (scl<254) && (sda!=scl)){device.i2c1.sda=sda; device.i2c1.scl=scl;}}
#endif
#if defined(RT_HW_PERMIT_I2C2)	
if(bus==2) {if((sda<254) && (scl<254) && (sda!=scl)){device.i2c2.sda=sda; device.i2c2.scl=scl;}}
#endif
};			//++END i2cSetPin()
void     RT_HW_BASE:: i2cSetAdr(uint8_t adr, uint8_t bus){					//==Запись в регистр адреса устройства;
#if defined(RT_HW_PERMIT_I2C0)	
if(bus==0) {if(adr<254) {device.i2c0.adr=adr;}}
#endif
#if defined(RT_HW_PERMIT_I2C1)	
if(bus==1) {if(adr<254) {device.i2c1.adr=adr;}}
#endif
#if defined(RT_HW_PERMIT_I2C2)	
if(bus==2) {if(adr<254) {device.i2c2.adr=adr;}}
#endif
};			//++END i2cSetAdr()
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//					3.ФУНКЦИИ ИНИЦИАЛИЗАЦИИ И НАСТРОЙКИ ШИН I2C
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void    RT_HW_BASE:: i2cBegin(uint8_t sda, uint8_t scl, uint8_t adr,uint8_t bus){	//==Инициализация шины i2c;
if(i2cCheckBusState(RT_HW_I2C_STATE_INIT,bus)) {return;};	//--Выход, если шина инициализирована;
i2cSetAdr(adr,bus);											//--Измененение adr в регистрe устройства;
i2cSetPin(sda,scl,bus);										//--Измененение пинов sda,scl в регистрах устройства
//======================Инициализация как MASTER======================================================
#if defined(RT_HW_PERMIT_I2C0)								//==Инициализация bus=0 как Master;
	if((bus==0) && (device.i2c0.adr==0)){									
		//consoleText(String(F("test 1->sda,scl")),':'); ConsoleV8('U',3,',',device.i2c0.sda); ConsoleV8('U',3,'E',device.i2c0.scl);
	#if defined(RT_HW_CORE_D_STM32) 									
		Wire.setSDA  (device.i2c0.sda);						//--Аппаратная настройка пина SDA;	
 		Wire.setSCL  (device.i2c0.scl);						//--Аппаратная настройка пина SCL;		
		Wire.begin(); 										//--Инициализация как master; 
		Wire.setClock(device.i2c0.speed);					//--Установка частоты шины i2c;  
		i2cSetBusState(RT_HW_I2C_STATE_MASTER,bus);			//--Установка флага MASTER; 
		i2cSetBusState(RT_HW_I2C_STATE_INIT,  bus);			//--Установка флага INIT и выход; 		
return;
    #elif defined(RT_HW_CORE_ESP32) 											
		Wire.begin   (device.i2c0.sda,device.i2c0.scl);		//--Инициализация как master;
		Wire.setClock(device.i2c0.speed);					//--Установка частоты шины i2c;
		Wire.setTimeOut(50); 								//--По умолчанию  тайм-аут на транзакцию =50ms;	
		i2cSetBusState(RT_HW_I2C_STATE_MASTER,bus);			//--Установка флага MASTER; 
		i2cSetBusState(RT_HW_I2C_STATE_INIT,  bus);			//--Установка флага INIT и выход; 		
return;
    #elif  defined(RT_HW_CORE_ESP8266)
		Wire.begin   (device.i2c0.sda,	device.i2c0.scl);  	//--Инициализация как master
		Wire.setClock(device.i2c0.speed);					//--Установка частоты шины i2c;	
		Wire.setClockStretchLimit(260);						//--Ограничение лимита по времени;
		i2cSetBusState(RT_HW_I2C_STATE_MASTER,bus);			//--Установка флага MASTER; 
		i2cSetBusState(RT_HW_I2C_STATE_INIT,  bus);			//--Установка флага INIT и выход; 
return;
    #else		
		Wire.begin();										//--Инициализация как master;	
		Wire.setClock(device.i2c0.speed);					//--Установка частоты шины i2c;
		i2cSetBusState(RT_HW_I2C_STATE_MASTER,bus);			//--Установка флага MASTER; 
		i2cSetBusState(RT_HW_I2C_STATE_INIT,  bus);			//--Установка флага INIT и выход; 					
return;
    #endif 
return;
	}  //+++END if((bus==0) && (device.i2c0.adr==0));
#endif
#if defined(RT_HW_PERMIT_I2C1)								//==Инициализация bus=0 как Master;
	if((bus==1) && (device.i2c1.adr==0)){									
    #if defined(RT_HW_CODE_D_STM32) 									
		Wire1.setSDA (device.i2c1.sda);						//--Аппаратная настройка пина SDA;	
		Wire1.setSCL (device.i2c1.scl);						//--Аппаратная настройка пина SCL;
		Wire1.begin(); 										//--Инициализация как master; 
		Wire1.setClock(device.i2c0.speed);					//--Установка частоты шины i2c;  
    #elif defined(RT_HW_CORE_ESP32) 											
		Wire1.begin   (device.i2c1.sda,device.i2c1.scl);	//--Инициализация как master;
		Wire1.setClock(device.i2c1.speed);					//--Установка частоты шины i2c;
		Wire1.setTimeOut(50); 								//--По умолчанию  тайм-аут на транзакцию =50ms;	
    #else 
		Wire.begin();										//--Инициализация как master;	
		Wire.setClock(device.i2c0.speed);					//--Установка частоты шины i2c;
    #endif 
		i2cSetBusState(RT_HW_I2C_STATE_MASTER,bus);			//--Установка флага MASTER; 
		i2cSetBusState(RT_HW_I2C_STATE_INIT,  bus);			//--Установка флага INIT и выход; 
	return;}  //+++END if((bus==0) && (device.i2c0.adr==0));
#endif
#if defined(RT_HW_PERMIT_I2C2)								//==Инициализация bus=0 как Master;
	if((bus==2) && (device.i2c2.adr==0)){									
    #if defined(RT_HW_CODE_D_STM32) 									
		Wire2.setSDA (device.i2c2.sda);						//--Аппаратная настройка пина SDA;	
		Wire2.setSCL (device.i2c2.scl);						//--Аппаратная настройка пина SCL;
		Wire2.begin(); 										//--Инициализация как master; 
		Wire2.setClock(device.i2c2.speed);					//--Установка частоты шины i2c;  	
    #else 
		Wire2.begin();										//--Инициализация как master;	
		Wire2.setClock(device.i2c2.speed);					//--Установка частоты шины i2c;
    #endif 
		i2cSetBusState(RT_HW_I2C_STATE_MASTER,bus);			//--Установка флага MASTER; 
		i2cSetBusState(RT_HW_I2C_STATE_INIT,  bus);			//--Установка флага INIT и выход; 
	return;}  //+++END if((bus==0) && (device.i2c0.adr==0));
#endif
//======================Инициализация как SLAVE====================================================
#if !defined(RT_HW_BLOCK_I2C_SLAVE)
#if defined(RT_HW_PERMIT_I2C0)								//==Инициализация bus=0 как Master;
	if((bus==0) && (device.i2c0.adr>=8)){									
    #if defined(RT_HW_CODE_D_STM32) 									
		Wire.setSDA  (device.i2c0.sda);						//--Аппаратная настройка пина SDA;		
		Wire.setSCL  (device.i2c0.scl);						//--Аппаратная настройка пина SCL;	;
		Wire.begin   (device.i2c0.adr);						//--Инициализация как Slave;   								
    #elif  defined(RT_HW_CORE_ESP8266)
		Wire.begin(device.i2c0.sda,device.i2c0.scl,device.i2c0.adr);//--Инициализация как Slave; 
		//Wire.setClockStretchLimit(260);					//--Ограничение лимита по времени;
    #else 
		Wire.begin   (device.i2c0.adr);						//--Инициализация как Slave;  
    #endif 
		i2cSetBusState(RT_HW_I2C_STATE_SLAVE,bus);			//--Установка флага MASTER; 
		i2cSetBusState(RT_HW_I2C_STATE_INIT,  bus);			//--Установка флага INIT и выход; 
	return;}  //+++END if((bus==0) && (device.i2c0.adr==0));
#endif
#if defined(RT_HW_PERMIT_I2C1)								//==Инициализация bus=0 как Master;
	if((bus==1) && (device.i2c1.adr>=8)){									
    #if defined(RT_HW_CODE_D_STM32) 									
		Wire1.setSDA  (device.i2c1.sda);						//--Аппаратная настройка пина SDA;		
		Wire1.setSCL  (device.i2c1.scl);						//--Аппаратная настройка пина SCL;	;
		Wire1.begin   (device.i2c1.adr);						//--Инициализация как Slave;   								
    #else 
		Wire1.begin   (device.i2c1.adr);						//--Инициализация как Slave;  
    #endif 
		i2cSetBusState(RT_HW_I2C_STATE_SLAVE,bus);			//--Установка флага MASTER; 
		i2cSetBusState(RT_HW_I2C_STATE_INIT,  bus);			//--Установка флага INIT и выход; 
	return;}  //+++END if((bus==0) && (device.i2c0.adr==0));
#endif
#if defined(RT_HW_PERMIT_I2C2)								//==Инициализация bus=0 как Master;
	if((bus==2) && (device.i2c2.adr>=8)){									
    #if defined(RT_HW_CODE_D_STM32) 									
		Wire2.setSDA  (device.i2c2.sda);						//--Аппаратная настройка пина SDA;		
		Wire2.setSCL  (device.i2c2.scl);						//--Аппаратная настройка пина SCL;	;
		Wire2.begin   (device.i2c2.adr);						//--Инициализация как Slave;   								
    #else 
		Wire2.begin   (device.i2c2.adr);						//--Инициализация как Slave;  
    #endif 
		i2cSetBusState(RT_HW_I2C_STATE_SLAVE,bus);			//--Установка флага MASTER; 
		i2cSetBusState(RT_HW_I2C_STATE_INIT,  bus);			//--Установка флага INIT и выход; 
	return;}  //+++END if((bus==0) && (device.i2c0.adr==0));
#endif
#endif
//===========================================================================================
};       	//++END i2cBegin()
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//					4.Функция настройки частоты шин i2c
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void    RT_HW_BASE:: i2cSetClock(uint32_t speed, uint8_t bus){	//==Установка частоты i2c для Master;
#if defined(RT_HW_PERMIT_I2C0) 
if(bus==0){buff.vu32=RT_HW_I2C_SPEED_LOW*1000UL; if(speed>=buff.vu32) {device.i2c0.speed=speed;} Wire.setClock(device.i2c0.speed);}
#endif	
#if defined(RT_HW_PERMIT_I2C1)
if(bus==1){buff.vu32=RT_HW_I2C_SPEED_LOW*1000UL; if(speed>=buff.vu32) {device.i2c1.speed=speed;} Wire1.setClock(device.i2c1.speed);};
#endif
#if defined(RT_HW_PERMIT_I2C2)
if(bus==2){buff.vu32=RT_HW_I2C_SPEED_LOW*1000UL; if(speed>=buff.vu32) {device.i2c2.speed=speed;} Wire2.setClock(device.i2c2.speed);};
#endif			
};			//++END i2cSetClock()

//---------------------------4.ФУНКЦИИ ОБМЕНА ДЛЯ ШИН I2C----------------------------------------------------
void    RT_HW_BASE:: i2cBeginTransmission(uint8_t adr,uint8_t bus){							//==Начало передачи от Master к Slave;
#if defined(RT_HW_PERMIT_I2C0)
if(bus==0){if(i2cCheckBusState(RT_HW_I2C_STATE_MASTER,bus) && (adr<254)) {Wire.beginTransmission(adr);}  return;};
#endif	
#if defined(RT_HW_PERMIT_I2C1)
if(bus==1){if(i2cCheckBusState(RT_HW_I2C_STATE_MASTER,bus) && (adr<254)) {Wire1.beginTransmission(adr);} return;};
#endif	
#if defined(RT_HW_PERMIT_I2C2)
if(bus==2){if(i2cCheckBusState(RT_HW_I2C_STATE_MASTER,bus) && (adr<254)) {Wire2.beginTransmission(adr);} return;};
#endif	
};			//++END  i2cBeginTransmission(int8_t adr, int8_t bus)
uint8_t RT_HW_BASE:: i2cEndTransmission(uint8_t bus){										//==Завершение передачи данных от Master к Slave;
#if defined(RT_HW_PERMIT_I2C0)
if(bus==0){if(i2cCheckBusState(RT_HW_I2C_STATE_MASTER,bus)) {return Wire.endTransmission();}};
#endif	
#if defined(RT_HW_PERMIT_I2C1)
if(bus==1){if(i2cCheckBusState(RT_HW_I2C_STATE_MASTER,bus)) {return Wire1.endTransmission();}};
#endif	
#if defined(RT_HW_PERMIT_I2C2)
if(bus==2){if(i2cCheckBusState(RT_HW_I2C_STATE_MASTER,bus)) {return Wire2.endTransmission();}};
#endif
return 4;}	//++END i2cEndTransmission(int8_t bus)
void    RT_HW_BASE:: i2cFlush(uint8_t bus){													//==Очистка буферов и индексов;
#if !defined(RT_HW_BLOCK_I2C_FLUSH)
#if defined(RT_HW_PERMIT_I2C0)
if(bus==0){Wire.flush();}
#endif	
#if defined(RT_HW_PERMIT_I2C1)
if(bus==1){Wire1.flush();}
#endif	
#if defined(RT_HW_PERMIT_I2C2)
if(bus==2){Wire2.flush();}
#endif	
#endif
}			//++END i2cFlash()
uint8_t RT_HW_BASE:: i2cAvailable(uint8_t bus){												//==Проверка данных в приемном буфере;
#if defined(RT_HW_PERMIT_I2C0)
if(bus==0){if(i2cCheckBusState(RT_HW_I2C_STATE_MASTER,bus))  {return Wire.available();}};
#endif	
#if defined(RT_HW_PERMIT_I2C1)
if(bus==1){if(i2cCheckBusState(RT_HW_I2C_STATE_MASTER,bus))  {return Wire1.available();}};
#endif	
#if defined(RT_HW_PERMIT_I2C2)
if(bus==2){if(i2cCheckBusState(RT_HW_I2C_STATE_MASTER,bus))  {return Wire2.available();}};
#endif		
return 0;}	//++END i2cAvailable()
void    RT_HW_BASE:: i2cWrite(uint8_t val,uint8_t bus){										//==Запись байта для отправки в i2c;
#if defined(RT_HW_PERMIT_I2C0)
if(bus==0){if(i2cCheckBusState(RT_HW_I2C_STATE_MASTER,bus))  {Wire.write(val);}};
#endif	
#if defined(RT_HW_PERMIT_I2C1)
if(bus==1){if(i2cCheckBusState(RT_HW_I2C_STATE_MASTER,bus))  {Wire1.write(val);}};
#endif	
#if defined(RT_HW_PERMIT_I2C2)
if(bus==2){if(i2cCheckBusState(RT_HW_I2C_STATE_MASTER,bus))  {Wire2.write(val);}};
#endif	
}			//++END i2cWrite()
void    RT_HW_BASE:: i2cWrite(const uint8_t *arr, uint8_t qnt,                 uint8_t bus){//==Запись байтов из массива для отправки в i2c;
#if defined(RT_HW_PERMIT_I2C0)
if(bus==0){ if(qnt>32) {qnt=32;} if(i2cCheckBusState(RT_HW_I2C_STATE_MASTER,bus))  {Wire.write(arr,qnt);}};
#endif	
#if defined(RT_HW_PERMIT_I2C1)
if(bus==1){ if(qnt>32) {qnt=32;} if(i2cCheckBusState(RT_HW_I2C_STATE_MASTER,bus))  {Wire1.write(arr,qnt);}};
#endif	
#if defined(RT_HW_PERMIT_I2C2)
if(bus==2){ if(qnt>32) {qnt=32;} if(i2cCheckBusState(RT_HW_I2C_STATE_MASTER,bus))  {Wire2.write(arr,qnt);}};
#endif	
}			//++END i2cWrite(uint8_t *arr)
void    RT_HW_BASE:: i2cWrite(const char *str,    uint8_t qnt, 				   uint8_t bus){//==Запись символов из массива для отправки в i2c;
#if defined(RT_HW_PERMIT_I2C0)
if(bus==0){ if(qnt>32) {qnt=32;} for(uint8_t i = 0; i < qnt; ++i) {Wire.write(str[i]);}}
#endif	
#if defined(RT_HW_PERMIT_I2C1)
if(bus==1){ if(qnt>32) {qnt=32;} for(uint8_t i = 0; i < qnt; ++i) {Wire1.write(str[i]);}}
#endif	
#if defined(RT_HW_PERMIT_I2C2)
if(bus==2){ if(qnt>32) {qnt=32;} for(uint8_t i = 0; i < qnt; ++i) {Wire2.write(str[i]);}}
#endif	
}			//++END i2cWrite(char *arr)
uint8_t RT_HW_BASE:: i2cRequestFrom(bool sendStop,uint8_t qnt,    uint8_t adr, uint8_t bus){//==Запрос данных из Slave;
#if defined(RT_HW_PERMIT_I2C0)
if(bus==0){
if(adr>=254) {return 0;}	//--Выход, если недопустимый адрес устройтсва;
if(i2cCheckBusState(RT_HW_I2C_STATE_MASTER,bus))  {//Wire.flush(); 
return Wire.requestFrom((uint8_t)adr,qnt,(uint8_t)sendStop);}};
#endif	
#if defined(RT_HW_PERMIT_I2C1)
if(bus==1){
if(adr>=254) {return 0;}	//--Выход, если недопустимый адрес устройтсва;
if(i2cCheckBusState(RT_HW_I2C_STATE_MASTER,bus))  {//Wire1.flush();
return Wire1.requestFrom((uint8_t)adr,qnt,(uint8_t)sendStop);}};
#endif	
#if defined(RT_HW_PERMIT_I2C2)
if(bus==2){if(i2cCheckBusState(RT_HW_I2C_STATE_MASTER,bus))  {//Wire2.flush();
if(adr>=254) {return 0;}	//--Выход, если недопустимый адрес устройтсва;
return Wire2.requestFrom((uint8_t)adr,qnt,(uint8_t)sendStop);}};
#endif	
return 0;}//++END i2cRequest()
uint8_t RT_HW_BASE:: i2cReadBuff(uint8_t bus){ 												//==Чтение байта из буфера i2c;
#if defined(RT_HW_PERMIT_I2C0)
if(bus==0){if(i2cCheckBusState(RT_HW_I2C_STATE_MASTER,bus))  {return Wire.read();}};
#endif	
#if defined(RT_HW_PERMIT_I2C1)
if(bus==1){if(i2cCheckBusState(RT_HW_I2C_STATE_MASTER,bus))  {return Wire1.read();}};
#endif	
#if defined(RT_HW_PERMIT_I2C2)
if(bus==2){if(i2cCheckBusState(RT_HW_I2C_STATE_MASTER,bus))  {return Wire2.read();}};
#endif		
return 0;}; //++END i2cReadBuff()
uint8_t RT_HW_BASE:: i2cSendByte (uint8_t val,                    uint8_t adr, uint8_t bus){//==Отправка байта в шину i2c; Возвращает 0 при успешном обмене;
#if defined(RT_HW_PERMIT_I2C0)
if(bus==0){ Wire.beginTransmission(adr);  Wire.write(val);   return Wire.endTransmission();}
#endif	
#if defined(RT_HW_PERMIT_I2C1)
if(bus==1){ Wire1.beginTransmission(adr); Wire1.write(val);  return Wire1.endTransmission();}
#endif	 
#if defined(RT_HW_PERMIT_I2C2)
if(bus==2){ Wire2.beginTransmission(adr); Wire2.write(val);  return Wire2.endTransmission();}
#endif	
return 1;}; 
uint8_t RT_HW_BASE:: i2cSendBytes(const uint8_t *arr,uint8_t qnt, uint8_t adr, uint8_t bus){//==Отправка qnt байт из arr[] в i2c; Возвращает 0 при успешном обмене;
#if defined(RT_HW_PERMIT_I2C0)
if(bus==0){if(qnt>32) {qnt=32;}; Wire.beginTransmission(adr);  Wire.write(arr,qnt);  return Wire.endTransmission();}
#endif	
#if defined(RT_HW_PERMIT_I2C1)
if(bus==1){if(qnt>32) {qnt=32;}; Wire1.beginTransmission(adr); Wire1.write(arr,qnt); return Wire1.endTransmission();}
#endif	 
#if defined(RT_HW_PERMIT_I2C2)
if(bus==2){if(qnt>32) {qnt=32;}; Wire2.beginTransmission(adr); Wire2.write(arr,qnt); return Wire2.endTransmission();}
#endif	 
return 1;}
uint8_t RT_HW_BASE:: i2cGetByte  (                 			      uint8_t adr, uint8_t bus){//==Прием байта из i2c в буфер i2c; Возвращает 0 при успешном приеме;
return i2cGetBytes(1,adr, bus);}	    											//--Запрос 1 байта в буфер i2c; 
uint8_t RT_HW_BASE:: i2cGetBytes (                   uint8_t qnt, uint8_t adr, uint8_t bus){//==Прием байтов из i2c в буфер i2c;  Возвращает 0 при успешном приеме;
	uint8_t i2cErrCode=0;												//--Очистка кода ошибки;	
	uint8_t cnt=RT_HW_Base.i2cRequestFrom(true,qnt,adr,bus);			//--Запрос qnt байтов в буфер; 	
	if(cnt!=qnt) {return 5;}											//--Выход, ошибка запроса;
	uint32_t timeOut=micros()+150*qnt;	cnt=0;							//--Тайм-аут на получение запрошенных данных;
	do{cnt=RT_HW_Base.i2cAvailable(bus); 								//--Чтение 
	   if(cnt>=qnt){break;}												//--Ожидание  заполнения буфера
       if(RT_HW_Base.getPastMcs(timeOut)>150*qnt) {i2cErrCode=6; break;}
	  }while(1);	//                       запрошенными байтами;	
	return i2cErrCode; 													//--Нормальный выход;
};	//--Возвращает код ошибки(=0 -нет ошибок);
uint8_t RT_HW_BASE:: i2cReadRegs(uint8_t reg,        uint8_t qnt, uint8_t adr, uint8_t bus){//==Чтение из регистров начиная с reg в буфер i2c;
	uint8_t i2cErrCode;
	i2cErrCode=RT_HW_Base.i2cSendByte(reg,adr,bus); if(i2cErrCode)      {return i2cErrCode;}
	i2cErrCode=RT_HW_Base.i2cGetBytes(qnt,adr,bus);	if(i2cErrCode)      {return i2cErrCode;}		
return 0;}

//---------------------------5.ФУНКЦИИ СКАНИРОВАНИЯ И ПОИСКА АДРЕСА ДЛЯ ШИН I2C-------------------------------
void    RT_HW_BASE:: i2cScanDevice(char mode, uint8_t bus){						//==Сканирование устройств на шине i2c;
#if defined(RT_HW_PERMIT_I2C0)
if(bus==0){ if(RT_HW_Base.console.ok){
if( bitRead(device.i2c0.state,RT_HW_I2C_STATE_SLAVE)){consoleText(String(F("i2c0->Slave,no scan")),'E'); return;}			   	//---Проверка на настройку в режиме Slave--
if(!bitRead(device.i2c0.state,RT_HW_I2C_STATE_INIT)) {consoleText(String(F("i2c0->init Master")),  'E'); 
i2cBegin(255,255,0,bus);
}//---Проверка на инициализацию шины i2c----
consoleText(String(F("i2c0->"))); buff.vu8=0;	
for(int i=1;i<=127;i++){
	Wire.beginTransmission(i);  if(Wire.endTransmission()==0) {if(buff.vu8){consoleChar(',');} buff.vu8++; ConsoleAdrI2C(mode,0,'~',i);}
	} 
consoleText(String(F("; qnt="))); consoleUint8(buff.vu8,'E');}
}
#endif		//++END #if defined(RT_HW_PERMIT_I2C0)
#if defined(RT_HW_PERMIT_I2C1)
if(bus==1){ if(RT_HW_Base.console.ok){
if( bitRead(device.i2c1.state,RT_HW_I2C_STATE_SLAVE)){consoleText(String(F("i2c1->Slave,no scan")),'E'); return;}			  	//---Проверка на настройку в режиме Slave--
if(!bitRead(device.i2c1.state,RT_HW_I2C_STATE_INIT)) {consoleText(String(F("i2c1->init Master")),  'E'); i2cBegin(-1,-1,0,bus);}//---Проверка на инициализацию шины i2c----
consoleText(String(F("i2c1->"))); buff.vu8=0;	
for(int i=1;i<=127;i++){Wire1.beginTransmission(i); if(Wire1.endTransmission()==0){if(buff.vu8){consoleChar(',');} buff.vu8++; ConsoleAdrI2C(mode,0,'~',i);}} 
consoleText(String(F("; qnt="))); consoleUint8(buff.vu8,'E');}}
#endif		//--END #if defined(RT_HW_PERMIT_I2C1)
#if defined(RT_HW_PERMIT_I2C2)
if(bus==2){ if(RT_HW_Base.console.ok){
if( bitRead(device.i2c2.state,RT_HW_I2C_STATE_SLAVE)){consoleText(String(F("i2c2->Slave,no scan")),'E'); return;}			  	//---Проверка на настройку в режиме Slave--
if(!bitRead(device.i2c2.state,RT_HW_I2C_STATE_INIT)) {consoleText(String(F("i2c2->init Master")),  'E'); i2cBegin(-1,-1,0,bus);}//---Проверка на инициализацию шины i2c---- 
consoleText(String(F("i2c2->"))); buff.vu8=0;	
for(int i=1;i<=127;i++){Wire2.beginTransmission(i); if(Wire2.endTransmission()==0){if(buff.vu8){consoleChar(',');} buff.vu8++;  ConsoleAdrI2C(mode,0,'~',i);}} 
consoleText(String(F("; qnt="))); consoleUint8(buff.vu8,'E');}}
#endif		//--END #if defined(RT_HW_PERMIT_I2C2)
//-------------------------------------------------------------------------------------------------
};			//--END i2cScanDevice(uint8_t bus)
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//  	Функция поиска устройства по адресу на шине i2c
// Вход: рабочие регистры: uint32_t timeDelay, uint8_t custom, uint8_t errCnt, uint8_t okCnt;
//		 передаваемые параметры: int8_t adr - адрес устройства,uint8_t bus - номер шины i2c;
//		 настроечные  параметры: uint8_t okMax - количество успешных повторов (по умолчанию=3),
//		 						 uint8_t period - период повторов (по умолчанию=50), 
//								 uint16_t periodMax - максимальный период повторов при ошибках((по умолчанию=2000);
// Алгоритм: перед началом работы следует установить custom=0;
//			 после успешного подряд в кол-ве okMax поиска, возвращается значение custom=50;
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
uint8_t  RT_HW_BASE:: i2cFindAdr(uint32_t &timeDelay, uint16_t &custom, uint8_t adr, uint8_t bus, //==Поиск адреса на шине i2c;
                                    uint8_t okMax, uint8_t period, uint16_t periodMax){			
uint8_t step=custom & 0x0F; uint8_t cntOk=(custom>>4)&0x0F; uint8_t cntErr=(custom>>8)&0xFF;
if(step==0) {timeDelay=millis();
#if defined(RT_HW_PERMIT_I2C0)
	if(bus==0){Wire.beginTransmission(adr);  if(Wire.endTransmission()==0) {cntErr=0; step=1; if(++cntOk >=okMax){step=7;}} else{cntOk=0; step=2;}}
#endif
#if defined(RT_HW_PERMIT_I2C1)
	if(bus==1){Wire1.beginTransmission(adr); if(Wire1.endTransmission()==0){cntErr=0; step=1; if(++cntOk >=okMax){step=7;}} else{cntOk=0; step=2;}}
#endif
#if defined(RT_HW_PERMIT_I2C2)
	if(bus==2){Wire2.beginTransmission(adr); if(Wire2.endTransmission()==0){cntErr=0; step=1; if(++cntOk >=okMax){step=7;}} else{cntOk=0; step=2;}}
#endif
			}
if(step==1)	{if(getPastMs(timeDelay)>=period)  		 {step=0;}}		 
if(step==2) {cntOk=0; cntErr+=2; if((cntErr*period) > periodMax) {cntErr-=2;}; step=3;}
if(step==3)	{if(getPastMs(timeDelay)>=cntErr*period) {step=0;}}	
custom=(cntErr<<8) & 0xFF00; custom|= (cntOk & 0x0F)<<4;  custom|=step & 0x0F; 
if(step==7) {custom=0; return 1;} else {return 0;}
}

//############################################################################################################
//---------------------------10.ФУНКЦИИ ДЛЯ ОБМЕНА С ШИНАМИ---------------------------------------------------

/*
uint8_t RT_HW_BASE:: busSendByte (char modeLink, uint8_t val,                    uint8_t adr,uint8_t bus,uint8_t miso,uint8_t mosi){ 
if(modeLink=='I') {return RT_HW_Base.i2cSendByte(val, adr, bus);}				//----Аппаратный интерфейс  i2c;	
if(modeLink=='S') {return 7;}													//----Аппаратный интерфейс  SPI;
if(modeLink=='P') {if((miso<0)|| (mosi<0)) {return 7;}} 						//----Программный интерфейс SPI;
return 8;}	
uint8_t RT_HW_BASE:: busSendBytes(char modeLink, const uint8_t *arr, uint8_t qnt,uint8_t adr,uint8_t bus,uint8_t miso,uint8_t mosi){
if(modeLink=='I') {return RT_HW_Base.i2cSendBytes(arr, qnt, adr, bus);}			//----Аппаратный интерфейс  i2c;	
if(modeLink=='S') {return 7;}													//----Аппаратный интерфейс  SPI;
if(modeLink=='P') {if((miso=-1)|| (mosi=-1)) {return 7;}} 						//----Программный интерфейс SPI;
return 8;} 
uint8_t RT_HW_BASE:: busGetByte  (char modeLink,                                 uint8_t adr,uint8_t bus,uint8_t miso,uint8_t mosi){
if(modeLink=='I') {return RT_HW_Base.i2cGetByte(adr, bus);}						//----Аппаратный интерфейс  i2c;	
if(modeLink=='S') {return 8;}													//----Аппаратный интерфейс  SPI;
if(modeLink=='P') {if((miso=-1)|| (mosi=-1)) {return 7;}} 						//----Программный интерфейс SPI;
return 8;}
uint8_t RT_HW_BASE:: busGetBytes (char modeLink,                     uint8_t qnt,uint8_t adr,uint8_t bus,uint8_t miso,uint8_t mosi){
if(modeLink=='I') {return RT_HW_Base.i2cGetBytes(qnt, adr, bus);}				//----Аппаратный интерфейс  i2c;	
if(modeLink=='S') {return 8;}													//----Аппаратный интерфейс  SPI;
if(modeLink=='P') {if((miso=-1)|| (mosi=-1)) {return 7;} } 						//----Программный интерфейс SPI;	
return 8;}		
uint8_t RT_HW_BASE:: busReadRegs (char modeLink, uint8_t reg,        uint8_t qnt,uint8_t adr,uint8_t bus,uint8_t miso,uint8_t mosi){
if(modeLink=='I') {return RT_HW_Base.i2cReadRegs(reg, qnt, adr, bus);}			//----Аппаратный интерфейс  i2c;	
if(modeLink=='S') {return 7;}													//----Аппаратный интерфейс  SPI;
if(modeLink=='P') {if((miso=-1)|| (mosi=-1)) {return 7;} } 						//----Программный интерфейс SPI;	
return 8;}
uint8_t RT_HW_BASE:: busReadBuff (char modeLink,		                         uint8_t adr,uint8_t bus,uint8_t miso,uint8_t mosi){
if(modeLink=='I') {return i2cReadBuff(bus);}									//----Аппаратный  интерфейс  i2c;	
if(modeLink=='S') {return 7;}													//----Аппаратный  интерфейс  SPI;
if(modeLink=='P') {if((adr=-1)|| (bus=-1)|| (miso=-1)|| (mosi=-1)) {return 7;} }//----Программный интерфейс SPI;
return 0;};

//RT_HW_Base.busReadRegs (id.modeLink,CHIP_ID,1,id.adr,id.bus,id.pinMISO,id.pinMOSI);
*/
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
