#include "RT_HW_NEXT.h"
//------Конструктор--------------------------------------------------------------------------------
RT_HW_NEXT:: RT_HW_NEXT(){
//---Заполнение указателей ссылкой на непустое устройство;
for(int8_t i=0; i<=RT_HW_NEXT_MAX_DEVICE;i++){
 ptr[i]=&zN; 										//--Запись указателя;
 ptr[i]->custom=0; ptr[i]->num=0;  ptr[i]->ready=0;  ptr[i]->uart=255;
//	ptr[i]->ban=ptr[i]->permit=

 ptr[i]->lenArrByte=sizeof(hive.arrByte)/1; ptr[i]->ptrArrByte=hive.arrByte;	//--Начальная запись параметров массива v8;
 ptr[i]->lenArrWord=sizeof(hive.arrWord)/2; ptr[i]->ptrArrWord=hive.arrWord;	//--Начальная запись параметров массива v16;   
 ptr[i]->lenArrLong=sizeof(hive.arrLong)/4; ptr[i]->ptrArrLong=hive.arrLong;	//--Начальная запись параметров массива v32;
	} 
	hive.set=0x00; hive.qnt=0;};
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//------Функции блока управления устройством-------------------------------------------------------												
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void RT_HW_NEXT:: setZ     (RT_HW_STRUCT_NEXT_DEVICE &z,					//==setting параметров для обмена с Nextion; 
 uint8_t   *arrByte,uint16_t  *arrWord, uint32_t *arrLong, uint8_t lenArrByte,uint8_t lenArrWord,uint8_t lenArrLong){
if(z.custom==0) {		//==Для исключения повторной инициализации;
z.num=z.dir=z.ready=0;												//--clear регистров;
if(!RT_HW_Base.uartCheckNum(z.uart)) {z.custom=90; return;}			//--check допустимости номера uart;
z.num=RT_HW_Base.setFistFreeDevice(hive.set,RT_HW_NEXT_MAX_DEVICE);	//--getting номера свободного устройства;
if(z.num==0) 		                 {z.custom=91; return;}			//--check полученного номера  устройства;
ptr[z.num]=&z;														//--reservation pointer ID;
z.ptrArrByte=arrByte; 												//--reservation pointer byte массива;  
z.ptrArrWord=arrWord; 												//--reservation pointer word массива;    
z.ptrArrLong=arrLong; 												//--reservation pointer long массива; 
z.lenArrByte=lenArrByte; 											//--reservation size    byte массива;  
z.lenArrWord=lenArrWord;											//--reservation size    word массива;    
z.lenArrLong=lenArrLong;											//--reservation size    long массива; 
z.periodPack=(115200 *1000)/115200;								//--Расчетное время на одну транзакцию;
z.custom=1;}};	//--END	deviceSetID()
void RT_HW_NEXT:: generator(RT_HW_STRUCT_NEXT_DEVICE &z){					//==generator tick;
z.event=z.eventReboot=0;
if(z.cntPack>0){
	if(RT_HW_Base.getPastMcs(z.timePack)>z.periodPack) {z.cntPack--; z.timePack=micros();}} //--Уменьшение счетчика транзакций с периодичностью=f(speed UART);
if(RT_HW_Base.periodMs(z.timeStart, RT_HW_NEXT_PERIOD_BLINK)){
	z.blink=!z.blink;  z.event=1; 
	if(z.cntPack==0){z.timePack=micros();}
	if(++z.cntReboot>20){z.blinkReboot=!z.blinkReboot; z.eventReboot=1; z.cntReboot=1;}}};
void RT_HW_NEXT:: direct   (RT_HW_STRUCT_NEXT_DEVICE &z){					//==direct Nextion;
generator(z);
if(z.dir==0){if(z.custom!=1) {return;} 
	RT_HW_Base.uartBegin(z.uart,z.speed); 
	z.step=0; z.dir++; return;}				//--Инициализация UART;		  
if(z.dir==1){if(RT_HW_Base.uartSerial(z.uart))  {z.ready=1; z.dir=10;}	//--Переход после готовности UART; 
			 else {return;}} 											//--Ожидание готовности UART;
if(z.dir==10) {
	getFromNxt(z);
	if(z.event) {}
	return;}
}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//------Функции блока приема данных из Nextion-----------------------------------------------------
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void RT_HW_NEXT:: getFromNxt(RT_HW_STRUCT_NEXT_DEVICE &z){
if(z.step==0) {					//==check готовности устройства к приему транзакций------------				
 z.head=z.func=z.adr=z.qnt=z.crc=0;	z.step++; return;}		//--clear buff for head & goto next step;
if(z.step==1) {					//==waiting и обработка заголовка (0x3A,func,adr,qnt-----------
 if(RT_HW_Base.uartAvailable(z.uart)<4)	  {return;}			//--waiting head from device;
 z.head=RT_HW_Base.uartRead(z.uart);						//--read code head (0x3A);
 if( z.head!=0x3A) {z.codeErr=90; z.step=0; return;} 		//--exit error code head;
 z.func=RT_HW_Base.uartRead(z.uart);						//--read code func ((0x06 || 0x16 || 0x26);
 if((z.func!=0x06)&&(z.func!=0x16)&&(z.func!=0x26)) {z.codeErr=91; z.step=0; return;} 	//--check code func & exit error;	 
 z.adr=RT_HW_Base.uartRead(z.uart);							//--read adr;  							 
 z.qnt=RT_HW_Base.uartRead(z.uart);							//--read qnt; 
 z.codeErr=0;												//--
      if(z.func==0x06) {z.qntByte=z.qnt;   if((z.adr+z.qnt)> z.lenArrByte) {z.codeErr=92;}}
 else if(z.func==0x16) {z.qntByte=z.qnt*2; if((z.adr+z.qnt)> z.lenArrWord) {z.codeErr=93;}}	
 else if(z.func==0x26) {z.qntByte=z.qnt*4; if((z.adr+z.qnt)> z.lenArrLong) {z.codeErr=94;}}	
 else if(z.qntByte>RT_HW_NEXT_BUFF_REG_SIZE) 							   {z.codeErr=95;};
 //------------------------------------------------------------------------------------------------
//#ifdef RT_HW_NEXT_DEBUG
//{uint8_t arr[25]; 
// arr[0]=z.head;       arr[1]=z.func;       arr[2]=z.adr;        arr[3]=z.qnt;  arr[4]=z.qntByte; 
// arr[5]=z.lenArrByte; arr[6]=z.lenArrWord; arr[7]=z.lenArrLong; arr[8]=RT_HW_NEXT_BUFF_REG_SIZE;
// RT_HW_Base.consoleText(String(F("err:"))); RT_HW_Base.ConsoleV8('U',0,';',z.codeErr);
// RT_HW_Base.consoleText(String(F(" head->:code,func,adr,qnt,qntByte->"))); RT_HW_Base.ConsoleArrV8('H',0,',',5,arr);
// RT_HW_Base.consoleText(String(F(" len->B,W,L,S:"))); RT_HW_Base.ConsoleArrV8('U',2,'E',4,&arr[5]); }
//#endif
//------------------------------------------------------------------------------------------------
 if(z.codeErr!=0) {z.step=0; return;}						//--return if error;
 z.timeGet=millis();	z.step++;}							//--set timer & goto next stage;
if(z.step==2) {					//==waiting и обработка заголовка (0x3A,func,adr-------------------
 if(RT_HW_Base.uartAvailable(z.uart)>=(z.qntByte+4)){z.step++;}		//--waiting head from device; 
 else {if(RT_HW_Base.getPastMs(z.timeGet)>5) 	{z.codeErr=96; z.step=0; return;}}}
if(z.step==3) {					//==read data & check crc;						
 for(uint8_t i=0;i<z.qntByte; i++){z.buff[i]=RT_HW_Base.uartRead(z.uart);}
 z.crc=RT_HW_Base.uartRead(z.uart);  
 for(uint8_t i=0;i<3; i++){if(RT_HW_Base.uartRead(z.uart)!=0xFF) {z.codeErr=96; z.step=0; return;}}
 uint8_t crc;
 crc=z.head; crc+=z.func; crc+=z.adr; crc+=z.qnt;
 for(uint8_t i=0; i<z.qntByte; i++) {crc+=z.buff[i];}
 crc=0xFF-crc;	crc++;
 if(crc!=z.crc)  {z.codeErr=98; z.step=0; return;} 
 for(uint8_t i=0; i<z.qnt;i++){
	if(z.func==0x06) {uint8_t  bf= z.buff[i]; 					     	setValArr(z.num,'B',(z.adr+i),bf);}
	if(z.func==0x16) {uint16_t bf=(z.buff[i*2+1]<<8)+z.buff[i*2]; i+=1; setValArr(z.num,'W',(z.adr+i),bf);}
    if(z.func==0x26) {uint32_t bf=(z.buff[i*4+1]<<8)+z.buff[i*4]; i+=3; setValArr(z.num,'L',(z.adr+i),bf);} }	
//#ifdef RT_HW_NEXT_DEBUG
//{RT_HW_Base.consoleText(String(F("cmd->code,func,adr,qnt, xxxx, crc")));
//uint8_t arr[5]; arr[0]=z.head; arr[1]=z.func; arr[2]=z.adr; arr[3]=z.qnt; RT_HW_Base.ConsoleArrV8('H',0,';',4,arr);
//for(uint8_t i=0; i<z.qntByte; i++){RT_HW_Base.ConsoleV8('H',0,' ',z.buff[i]);} RT_HW_Base.consoleSuff(';');
//RT_HW_Base.ConsoleV8('H',0,'E',z.crc);}   
//RT_HW_Base.consoleText(String(F("arrByte: "))); for(uint8_t i=0; i<5; i++) {RT_HW_Base.ConsoleV8('H',0,' ', getValArr(z.num,'B',i));} RT_HW_Base.consoleCR();
//#endif
z.step=0; 
return;}
//---------------------------------------------------------------------------------------------------    	
}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//------Функции блока отправки данных и инструкций в Nextion----------------------------------------
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void RT_HW_NEXT:: setValID (RT_HW_STRUCT_NEXT_WRITE_VAL &id){				//==init ID для вывода переменной в формате inY=XXXX;
if(id.custom==0){
if(!checkNum(id.num)) {return;}												//--Выход, если недопустимый номер устройства;
id.agoBlink=ptr[id.num]->blink;												//--Синхронизация с тактирующим генератором;
id.dir=0;
id.adr=0;
id.run=1;
id.custom=1;}}; //--END writeSetID() 
void RT_HW_NEXT:: sendVal  (RT_HW_STRUCT_NEXT_WRITE_VAL &id, int32_t val){	//==sending value to Nextion;
if(id.dir==0) {							//==begin проверки общих условий вывода переменной;
 if(id.custom!=1) {return;}									//--check настройки id;
 id.dir=1;}													//--goto  на ожидание события для вывода переменной; 
if(id.dir==1) {							//==check условий на вывод (периодичность && изменение переменной;
 if(id.run==1){id.dir=2; return;}							//--check готовности переменной для вывода;
 if(id.agoBlink==ptr[id.num]->blink) {return;}				//--check на изменение тика от тактового генератора;
 id.agoBlink=ptr[id.num]->blink;							//--reservation нового значения от тактового генератора;
 if(++id.cnt<id.tick) {return;}								//--waiting периода вывода;
 id.cnt=0;													//--reset счетчика тиков;
 if(id.agoVal==val)   {return;}								//--check на изменение переменной;
 id.run=1; id.dir++;}										//--goto на этап вывода переменной;
if(id.dir==2) {							//==begin подготовки к выводу переменных;
 id.agoVal=val; id.dir++;}									//--reservation выводимой переменной; 
if(id.dir==3) { 						//==output переменной в Nextion;
 if(ptr[id.num]->cntPack >= ptr[id.num]->maxPack) {return;} //--check превышения допустимого кол-ва транзакций; 
 if(RT_HW_Base.uartAvailableForWrite(id.num)<20)  {return;}	//--waiting на освобождение буфера записи UART;	
 //--Формирование и отправка сообщения в Nextion;
 ptr[id.num]->cntPack++;									//--Увеличение кол-ва отравленных транзакций;
 RT_HW_Base.uartPrint(ptr[id.num]->uart,String(F("in"))); 			
 RT_HW_Base.uartPrint(ptr[id.num]->uart,String(id.adr));
 RT_HW_Base.uartWrite(ptr[id.num]->uart,0x3D);
 RT_HW_Base.uartPrint(ptr[id.num]->uart,String(id.agoVal));				
 for(uint8_t i=0;i<3;i++){RT_HW_Base.uartWrite(ptr[id.num]->uart,0XFF);}	
 //---------------------------------------------
 id.run=0; id.dir=1; return;}
}; //--END sendVal() 
void RT_HW_NEXT:: sendCmnd (RT_HW_STRUCT_NEXT_WRITE_VAL &id, int32_t val, String cmnd){	//==sending value to Nextion;
if(id.dir==0) {							//==begin проверки общих условий вывода переменной;
 if(id.custom!=1) {return;}									//--check настройки id;
 id.dir=1;}													//--goto  на ожидание события для вывода переменной; 
if(id.dir==1) {							//==check условий на вывод (периодичность && изменение переменной;
 if(id.run==1){id.dir=2; return;}							//--check готовности переменной для вывода;
 if(id.agoBlink==ptr[id.num]->blink) {return;}				//--check на изменение тика от тактового генератора;
 id.agoBlink=ptr[id.num]->blink;							//--reservation нового значения от тактового генератора;
 if(++id.cnt<id.tick) {return;}								//--waiting периода вывода;
 id.cnt=0;													//--reset счетчика тиков;
 if(id.agoVal==val)   {return;}								//--check на изменение переменной;
 id.run=1; id.dir++;}										//--goto на этап вывода переменной;
if(id.dir==2) {							//==begin подготовки к выводу переменных;
 id.agoVal=val; id.dir++;}									//--reservation выводимой переменной; 
if(id.dir==3) { 						//==output переменной в Nextion;
 if(ptr[id.num]->cntPack >= ptr[id.num]->maxPack) {return;} //--check превышения допустимого кол-ва транзакций; 
 if(RT_HW_Base.uartAvailableForWrite(id.num)<20)  {return;}	//--waiting на освобождение буфера записи UART;	
 //--Формирование и отправка сообщения в Nextion;
 ptr[id.num]->cntPack++;									//--Увеличение кол-ва отравленных транзакций;
 RT_HW_Base.uartPrint(ptr[id.num]->uart,cmnd); 			
 RT_HW_Base.uartPrint(ptr[id.num]->uart,String(id.agoVal));				
 for(uint8_t i=0;i<3;i++){RT_HW_Base.uartWrite(ptr[id.num]->uart,0XFF);}	
 //---------------------------------------------
 id.run=0; id.dir=1; return;}
}; //--END sendVal() 
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//		Функции для работы с массивами 		
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
bool 	 RT_HW_NEXT:: checkNum	(uint8_t num){						//==check доступности устройства с номером num;
 if((num==0) || (num>RT_HW_NEXT_MAX_DEVICE)){return 0;} else {return 1;}}
uint32_t RT_HW_NEXT:: getPtrArr (uint8_t num, char mode){			//==getting address pointer array; 
if(checkNum(num)){
if(mode=='B'){return (uint32_t)ptr[num]->ptrArrByte;}
if(mode=='W'){return (uint32_t)ptr[num]->ptrArrWord;}
if(mode=='L'){return (uint32_t)ptr[num]->ptrArrLong;}
if(mode=='Z'){return (uint32_t)ptr[num];}} return (uint32_t)ptr[0]->ptrArrLong;}	
uint8_t  RT_HW_NEXT:: getLenArr (uint8_t num, char mode){ 			//==getting len array;
if(checkNum(num)){
if((num==0) || (num>RT_HW_NEXT_MAX_DEVICE)){return 0;} 	
if(mode=='B'){return ptr[num]->lenArrByte;}
if(mode=='W'){return ptr[num]->lenArrWord;}
if(mode=='L'){return ptr[num]->lenArrLong;}
if(mode=='Z'){return ptr[num]->lenArrLong;}} return 0;}
uint32_t RT_HW_NEXT:: getValArr (uint8_t num, char mode, uint8_t index){ //==getting value from array;
if(checkNum(num)){
if(mode=='B'){if(index>=getLenArr(num,'B')) {return 0;} else {uint8_t  *arr=ptr[num]->ptrArrByte; return arr[index];}}
if(mode=='W'){if(index>=getLenArr(num,'W')) {return 0;} else {uint16_t *arr=ptr[num]->ptrArrWord; return arr[index];}}
if(mode=='L'){if(index>=getLenArr(num,'L')) {return 0;} else {uint32_t *arr=ptr[num]->ptrArrLong; return arr[index];}}} return 0;}
void     RT_HW_NEXT:: setValArr (uint8_t num, char mode, uint8_t index, uint32_t val){ //==setting value to array;
if(checkNum(num)){
if(mode=='B'){if(index>=getLenArr(num,'B')) {return;} else {uint8_t  *arr=ptr[num]->ptrArrByte; arr[index]= (uint8_t)val;}}
if(mode=='W'){if(index>=getLenArr(num,'W')) {return;} else {uint16_t *arr=ptr[num]->ptrArrWord; arr[index]=(uint16_t)val;}}
if(mode=='L'){if(index>=getLenArr(num,'L')) {return;} else {uint32_t *arr=ptr[num]->ptrArrLong; arr[index]=(uint32_t)val;}}}}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
RT_HW_NEXT RT_HW_Next;	//Создание внешнего объекта	
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
